package VO;

public class CuentaVO {

/*Todo los atributos*/
    int id_cta;
    String tfactura;
    String num_cta;
    String descripcion;
    String moneda;

public CuentaVO(){}

    public int getId_cta() {
        return id_cta;
    }

    public void setId_cta(int id_cta) {
        this.id_cta = id_cta;
    }

    public String getTfactura() {
        return tfactura;
    }

    public void setTfactura(String tfactura) {
        this.tfactura = tfactura;
    }

    public String getNum_cta() {
        return num_cta;
    }

    public void setNum_cta(String num_cta) {
        this.num_cta = num_cta;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getMoneda() {
        return moneda;
    }

    public void setMoneda(String moneda) {
        this.moneda = moneda;
    }

/*Todo los codigos get*/
   
    

}
