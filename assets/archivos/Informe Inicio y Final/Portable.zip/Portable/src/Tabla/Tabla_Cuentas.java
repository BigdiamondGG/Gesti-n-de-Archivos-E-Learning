package Tabla;
import DAO.CuentasDAO;
import VO.CuentaVO;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.util.ArrayList;
import javax.swing.JButton;


public class Tabla_Cuentas{
   CuentasDAO dao = null;
    public void visualizar_CuentasIA(JTable tabla){
        
        tabla.setDefaultRenderer(Object.class, new Render());
        DefaultTableModel dt = new DefaultTableModel(){
            public boolean isCellEditable(int row, int column){
                return false;
            }
        };    
        dt.addColumn("CUENTA");
        dt.addColumn("DESCRIPCIÓN");
        dt.addColumn("VALORES");
        dt.addColumn("AGREGAR");
        
        JButton btn_modificar = new JButton("AGREGAR VALOR");
        btn_modificar.setName("m");

        dao = new CuentasDAO();
        CuentaVO vo = new CuentaVO();
        ArrayList<CuentaVO> list = dao.Listar_CuentasIA();

        if(list.size() > 0){
            for(int i=0; i<list.size(); i++){
                Object fila[] = new Object[4];
                vo = list.get(i);
                fila[0] = vo.getNum_cta();
                fila[1] = vo.getDescripcion();
                fila[2] = vo.getMoneda();
                fila[3] = btn_modificar;
                dt.addRow(fila);
            }
            tabla.setModel(dt);
            tabla.setRowHeight(30);
        }
    }public void visualizar_CuentasFactIA(JTable tabla, String num_factura){
        
        tabla.setDefaultRenderer(Object.class, new Render());
        DefaultTableModel dt = new DefaultTableModel(){
            public boolean isCellEditable(int row, int column){
                return false;
            }
        };    
        dt.addColumn("CUENTA");
        dt.addColumn("DESCRIPCIÓN");
        dt.addColumn("VALORES");
        dt.addColumn("AGREGAR");
        
        JButton btn_modificar = new JButton("AGREGAR VALOR");
        btn_modificar.setName("m");

        dao = new CuentasDAO();
        CuentaVO vo = new CuentaVO();
        ArrayList<CuentaVO> list = dao.Listar_CuentasFactIA(num_factura);

        if(list.size() > 0){
            for(int i=0; i<list.size(); i++){
                Object fila[] = new Object[4];
                vo = list.get(i);
                fila[0] = vo.getNum_cta();
                fila[1] = vo.getDescripcion();
                fila[2] = vo.getMoneda();
                fila[3] = btn_modificar;
                dt.addRow(fila);
            }
            tabla.setModel(dt);
            tabla.setRowHeight(30);
        }
    }
      public void visualizar_CuentasID(JTable tabla){
        
        tabla.setDefaultRenderer(Object.class, new Render());
        DefaultTableModel dt = new DefaultTableModel(){
            public boolean isCellEditable(int row, int column){
                return false;
            }
        };    
        dt.addColumn("CUENTA");
        dt.addColumn("DESCRIPCIÓN");
        dt.addColumn("VALORES");
        dt.addColumn("AGREGAR");
        
        JButton btn_modificar = new JButton("AGREGAR VALOR");
        btn_modificar.setName("m");

        dao = new CuentasDAO();
        CuentaVO vo = new CuentaVO();
        ArrayList<CuentaVO> list = dao.Listar_CuentasID();

        if(list.size() > 0){
            for(int i=0; i<list.size(); i++){
                Object fila[] = new Object[4];
                vo = list.get(i);
                fila[0] = vo.getNum_cta();
                fila[1] = vo.getDescripcion();
                fila[2] = vo.getMoneda();
                fila[3] = btn_modificar;
                dt.addRow(fila);
            }
            tabla.setModel(dt);
            tabla.setRowHeight(30);
        }
    }
     public void visualizar_CuentasIP(JTable tabla){
        
        tabla.setDefaultRenderer(Object.class, new Render());
        DefaultTableModel dt = new DefaultTableModel(){
            public boolean isCellEditable(int row, int column){
                return false;
            }
        };    
        dt.addColumn("CUENTA");
        dt.addColumn("DESCRIPCIÓN");
        dt.addColumn("VALORES");
        dt.addColumn("AGREGAR");
        
        JButton btn_modificar = new JButton("AGREGAR VALOR");
        btn_modificar.setName("m");

        dao = new CuentasDAO();
        CuentaVO vo = new CuentaVO();
        ArrayList<CuentaVO> list = dao.Listar_CuentasIP();

        if(list.size() > 0){
            for(int i=0; i<list.size(); i++){
                Object fila[] = new Object[4];
                vo = list.get(i);
                fila[0] = vo.getNum_cta();
                fila[1] = vo.getDescripcion();
                fila[2] = vo.getMoneda();
                fila[3] = btn_modificar;
                dt.addRow(fila);
            }
            tabla.setModel(dt);
            tabla.setRowHeight(30);
        }
    }
       public void visualizar_CuentasIPD(JTable tabla){
        
        tabla.setDefaultRenderer(Object.class, new Render());
        DefaultTableModel dt = new DefaultTableModel(){
            public boolean isCellEditable(int row, int column){
                return false;
            }
        };    
        dt.addColumn("CUENTA");
        dt.addColumn("DESCRIPCIÓN");
        dt.addColumn("VALORES");
        dt.addColumn("AGREGAR");
        
        JButton btn_modificar = new JButton("AGREGAR VALOR");
        btn_modificar.setName("m");

        dao = new CuentasDAO();
        CuentaVO vo = new CuentaVO();
        ArrayList<CuentaVO> list = dao.Listar_CuentasIPD();

        if(list.size() > 0){
            for(int i=0; i<list.size(); i++){
                Object fila[] = new Object[4];
                vo = list.get(i);
                fila[0] = vo.getNum_cta();
                fila[1] = vo.getDescripcion();
                fila[2] = vo.getMoneda();
                fila[3] = btn_modificar;
                dt.addRow(fila);
            }
            tabla.setModel(dt);
            tabla.setRowHeight(30);
        }
    }       public void visualizar_CuentasEA(JTable tabla){
        
        tabla.setDefaultRenderer(Object.class, new Render());
        DefaultTableModel dt = new DefaultTableModel(){
            public boolean isCellEditable(int row, int column){
                return false;
            }
        };    
        dt.addColumn("CUENTA");
        dt.addColumn("DESCRIPCIÓN");
        dt.addColumn("VALORES");
        dt.addColumn("AGREGAR");
        
        JButton btn_modificar = new JButton("AGREGAR VALOR");
        btn_modificar.setName("m");

        dao = new CuentasDAO();
        CuentaVO vo = new CuentaVO();
        ArrayList<CuentaVO> list = dao.Listar_CuentasEA();

        if(list.size() > 0){
            for(int i=0; i<list.size(); i++){
                Object fila[] = new Object[4];
                vo = list.get(i);
                fila[0] = vo.getNum_cta();
                fila[1] = vo.getDescripcion();
                fila[2] = vo.getMoneda();
                fila[3] = btn_modificar;
                dt.addRow(fila);
            }
            tabla.setModel(dt);
            tabla.setRowHeight(30);
        }
    }
}


