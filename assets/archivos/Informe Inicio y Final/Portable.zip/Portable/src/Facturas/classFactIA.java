package Facturas;

public class classFactIA {
    
    String cuenta,descripcion,valores,fecha,total,num_factura,nombre,observaciones, totalletras, tipo_cuenta,num_cuenta;

    public classFactIA(String cuenta, String descripcion, String valores, String fecha, String total, String num_factura, String nombre, String observaciones, String totalletras, String tipo_cuenta, String num_cuenta) {
        this.cuenta = cuenta;
        this.descripcion = descripcion;
        this.valores = valores;
        this.fecha = fecha;
        this.total = total;
        this.num_factura = num_factura;
        this.nombre = nombre;
        this.observaciones = observaciones;
        this.totalletras = totalletras;
        this.tipo_cuenta = tipo_cuenta;
        this.num_cuenta = num_cuenta;
    }

    public String getCuenta() {
        return cuenta;
    }

    public void setCuenta(String cuenta) {
        this.cuenta = cuenta;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getValores() {
        return valores;
    }

    public void setValores(String valores) {
        this.valores = valores;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public String getNum_factura() {
        return num_factura;
    }

    public void setNum_factura(String num_factura) {
        this.num_factura = num_factura;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    public String getTotalletras() {
        return totalletras;
    }

    public void setTotalletras(String totalletras) {
        this.totalletras = totalletras;
    }

    public String getTipo_cuenta() {
        return tipo_cuenta;
    }

    public void setTipo_cuenta(String tipo_cuenta) {
        this.tipo_cuenta = tipo_cuenta;
    }

    public String getNum_cuenta() {
        return num_cuenta;
    }

    public void setNum_cuenta(String num_cuenta) {
        this.num_cuenta = num_cuenta;
    }

   
    
}
