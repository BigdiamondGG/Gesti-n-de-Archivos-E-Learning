package Facturas;

public class classFactIP {
    
    String cuenta,descripcion,valores,fecha,total,num_factura,nombre,observaciones,num_cuenta,totalletras,no_prestamo,ciclo,moneda,fecha_entrega,fecha_finalizacion,plazo,tasa,saldo_prestamo_actl,intereses_acumulados;

    public classFactIP(String cuenta, String descripcion, String valores, String fecha, String total, String num_factura, String nombre, String observaciones, String num_cuenta, String totalletras, String no_prestamo, String ciclo, String moneda, String fecha_entrega, String fecha_finalizacion, String plazo, String tasa, String saldo_prestamo_actl, String intereses_acumulados) {
        this.cuenta = cuenta;
        this.descripcion = descripcion;
        this.valores = valores;
        this.fecha = fecha;
        this.total = total;
        this.num_factura = num_factura;
        this.nombre = nombre;
        this.observaciones = observaciones;
        this.num_cuenta = num_cuenta;
        this.totalletras = totalletras;
        this.no_prestamo = no_prestamo;
        this.ciclo = ciclo;
        this.moneda = moneda;
        this.fecha_entrega = fecha_entrega;
        this.fecha_finalizacion = fecha_finalizacion;
        this.plazo = plazo;
        this.tasa = tasa;
        this.saldo_prestamo_actl = saldo_prestamo_actl;
        this.intereses_acumulados = intereses_acumulados;
    }

    public String getCuenta() {
        return cuenta;
    }

    public void setCuenta(String cuenta) {
        this.cuenta = cuenta;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getValores() {
        return valores;
    }

    public void setValores(String valores) {
        this.valores = valores;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public String getNum_factura() {
        return num_factura;
    }

    public void setNum_factura(String num_factura) {
        this.num_factura = num_factura;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    public String getNum_cuenta() {
        return num_cuenta;
    }

    public void setNum_cuenta(String num_cuenta) {
        this.num_cuenta = num_cuenta;
    }

    public String getTotalletras() {
        return totalletras;
    }

    public void setTotalletras(String totalletras) {
        this.totalletras = totalletras;
    }

    public String getNo_prestamo() {
        return no_prestamo;
    }

    public void setNo_prestamo(String no_prestamo) {
        this.no_prestamo = no_prestamo;
    }

    public String getCiclo() {
        return ciclo;
    }

    public void setCiclo(String ciclo) {
        this.ciclo = ciclo;
    }

    public String getMoneda() {
        return moneda;
    }

    public void setMoneda(String moneda) {
        this.moneda = moneda;
    }

    public String getFecha_entrega() {
        return fecha_entrega;
    }

    public void setFecha_entrega(String fecha_entrega) {
        this.fecha_entrega = fecha_entrega;
    }

    public String getFecha_finalizacion() {
        return fecha_finalizacion;
    }

    public void setFecha_finalizacion(String fecha_finalizacion) {
        this.fecha_finalizacion = fecha_finalizacion;
    }

    public String getPlazo() {
        return plazo;
    }

    public void setPlazo(String plazo) {
        this.plazo = plazo;
    }

    public String getTasa() {
        return tasa;
    }

    public void setTasa(String tasa) {
        this.tasa = tasa;
    }

    public String getSaldo_prestamo_actl() {
        return saldo_prestamo_actl;
    }

    public void setSaldo_prestamo_actl(String saldo_prestamo_actl) {
        this.saldo_prestamo_actl = saldo_prestamo_actl;
    }

    public String getIntereses_acumulados() {
        return intereses_acumulados;
    }

    public void setIntereses_acumulados(String intereses_acumulados) {
        this.intereses_acumulados = intereses_acumulados;
    }

    
   
    
}
