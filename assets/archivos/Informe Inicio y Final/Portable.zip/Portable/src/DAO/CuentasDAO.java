package DAO;

import conexion.Conexion;
import VO.CuentaVO;
import java.sql.*;
import java.util.ArrayList;


/*Metodo listar*/
public class CuentasDAO{

    public ArrayList<CuentaVO> Listar_CuentasIA(){
        ArrayList<CuentaVO> list = new ArrayList<CuentaVO>();
        Connection conec=Conexion.ConnectDB();
        String sql = "select num_cta," +
"               descripcion," +
"               valores from cuentas where tfactura='Ingresos de Ahorro'";
        ResultSet rs = null;
        PreparedStatement ps = null;
        try{
            ps = conec.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                CuentaVO vo = new CuentaVO();
                vo.setNum_cta(rs.getString(1));
                vo.setDescripcion(rs.getString(2));
                vo.setMoneda(rs.getString(3));
                list.add(vo);
            }
        }catch(SQLException ex){
            System.out.println(ex.getMessage());
        }catch(Exception ex){
            System.out.println(ex.getMessage());
        }finally{
            try{
                ps.close();
                rs.close();
            }catch(Exception ex){}
        }
        return list;
    }public ArrayList<CuentaVO> Listar_CuentasFactIA(String Num_Factura){
        ArrayList<CuentaVO> list = new ArrayList<CuentaVO>();
        Connection conec=Conexion.ConnectDB();
        String sql = "select cuenta," +
"               descripcion," +
"               valores from detalles_fact where num_factura='"+Num_Factura+"'";
        ResultSet rs = null;
        PreparedStatement ps = null;
        try{
            ps = conec.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                CuentaVO vo = new CuentaVO();
                vo.setNum_cta(rs.getString(1));
                vo.setDescripcion(rs.getString(2));
                vo.setMoneda(rs.getString(3));
                list.add(vo);
            }
        }catch(SQLException ex){
            System.out.println(ex.getMessage());
        }catch(Exception ex){
            System.out.println(ex.getMessage());
        }finally{
            try{
                ps.close();
                rs.close();
            }catch(Exception ex){}
        }
        return list;
    }
public ArrayList<CuentaVO> Listar_CuentasID(){
        ArrayList<CuentaVO> list = new ArrayList<CuentaVO>();
        Connection conec=Conexion.ConnectDB();
        String sql = "select num_cta," +
"               descripcion," +
"               valores FROM cuentas WHERE tfactura='Ingresos Diversos' ORDER BY FIELD(num_cta,'5400-200-0500') asc";
        ResultSet rs = null;
        PreparedStatement ps = null;
        try{
            ps = conec.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                CuentaVO vo = new CuentaVO();
                vo.setNum_cta(rs.getString(1));
                vo.setDescripcion(rs.getString(2));
                vo.setMoneda(rs.getString(3));
                list.add(vo);
            }
        }catch(SQLException ex){
            System.out.println(ex.getMessage());
        }catch(Exception ex){
            System.out.println(ex.getMessage());
        }finally{
            try{
                ps.close();
                rs.close();
            }catch(Exception ex){}
        }
        return list;
    }
  public ArrayList<CuentaVO> Listar_CuentasIP(){
        ArrayList<CuentaVO> list = new ArrayList<CuentaVO>();
        Connection conec=Conexion.ConnectDB();
        String sql = "select num_cta," +
"               descripcion," +
"               valores FROM cuentas WHERE tfactura='Ingresos de Prestamos'";
        ResultSet rs = null;
        PreparedStatement ps = null;
        try{
            ps = conec.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                CuentaVO vo = new CuentaVO();
                vo.setNum_cta(rs.getString(1));
                vo.setDescripcion(rs.getString(2));
                vo.setMoneda(rs.getString(3));
                list.add(vo);
            }
        }catch(SQLException ex){
            System.out.println(ex.getMessage());
        }catch(Exception ex){
            System.out.println(ex.getMessage());
        }finally{
            try{
                ps.close();
                rs.close();
            }catch(Exception ex){}
        }
        return list;
    }
  public ArrayList<CuentaVO> Listar_CuentasIPD(){
        ArrayList<CuentaVO> list = new ArrayList<CuentaVO>();
        Connection conec=Conexion.ConnectDB();
        String sql = "select num_cta," +
"               descripcion," +
"               valores FROM cuentas WHERE tfactura='Ingresos de Prestamos en Demanda'";
        ResultSet rs = null;
        PreparedStatement ps = null;
        try{
            ps = conec.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                CuentaVO vo = new CuentaVO();
                vo.setNum_cta(rs.getString(1));
                vo.setDescripcion(rs.getString(2));
                vo.setMoneda(rs.getString(3));
                list.add(vo);
            }
        }catch(SQLException ex){
            System.out.println(ex.getMessage());
        }catch(Exception ex){
            System.out.println(ex.getMessage());
        }finally{
            try{
                ps.close();
                rs.close();
            }catch(Exception ex){}
        }
        return list;
    }  public ArrayList<CuentaVO> Listar_CuentasEA(){
        ArrayList<CuentaVO> list = new ArrayList<CuentaVO>();
        Connection conec=Conexion.ConnectDB();
        String sql = "select num_cta," +
"               descripcion," +
"               valores FROM cuentas WHERE tfactura='Egresos de Ahorro'";
        ResultSet rs = null;
        PreparedStatement ps = null;
        try{
            ps = conec.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                CuentaVO vo = new CuentaVO();
                vo.setNum_cta(rs.getString(1));
                vo.setDescripcion(rs.getString(2));
                vo.setMoneda(rs.getString(3));
                list.add(vo);
            }
        }catch(SQLException ex){
            System.out.println(ex.getMessage());
        }catch(Exception ex){
            System.out.println(ex.getMessage());
        }finally{
            try{
                ps.close();
                rs.close();
            }catch(Exception ex){}
        }
        return list;
    }
}
/*Metodo agregar
    public void Agregar_ProductoVO(CuentaVO vo){
        Connection conec=Conexion.ConnectDB();
        String sql = "INSERT INTO producto (codigo, nombre, precio, marca) VALUES(NULL,?,?,?);";
        PreparedStatement ps = null;
        try{
            ps = conec.prepareStatement(sql);
            ps.setString(1, vo.getNombre());
            ps.setDouble(2, vo.getPrecio());
            ps.setString(3, vo.getMarca());
            ps.executeUpdate();
        }catch(SQLException ex){
            System.out.println(ex.getMessage());
        }catch(Exception ex){
            System.out.println(ex.getMessage());
        }finally{
            try{
                ps.close();
            }catch(Exception ex){}
        }
    }*/


/*Metodo Modificar
    public void Modificar_ProductoVO(CuentaVO vo){
        Connection conec=Conexion.ConnectDB();
        String sql = "UPDATE producto SET nombre = ?, precio = ?, marca = ? WHERE codigo = ?;";
        PreparedStatement ps = null;
        try{
            ps = conec.prepareStatement(sql);
            ps.setString(1, vo.getNombre());
            ps.setDouble(2, vo.getPrecio());
            ps.setString(3, vo.getMarca());
            ps.setInt(4, vo.getCodigo());
            ps.executeUpdate();
        }catch(SQLException ex){
            System.out.println(ex.getMessage());
        }catch(Exception ex){
            System.out.println(ex.getMessage());
        }finally{
            try{
                ps.close();
            }catch(Exception ex){}
        }
    }*/


/*Metodo Eliminar
    public void Eliminar_ProductoVO(CuentaVO vo){
        Connection conec=Conexion.ConnectDB();
        String sql = "DELETE FROM producto WHERE codigo = ?;";
        PreparedStatement ps = null;
        try{
            ps = conec.prepareStatement(sql);
            ps.setInt(1, vo.getCodigo());
            ps.executeUpdate();
        }catch(SQLException ex){
            System.out.println(ex.getMessage());
        }catch(Exception ex){
            System.out.println(ex.getMessage());
        }finally{
            try{
                ps.close();
            }catch(Exception ex){}
        }
    }
*/
