/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista;

import Facturas.*;
import DAO.CuentasDAO;
import DAO.Numero_a_Letra;
import conexion.Conexion;
import net.proteanit.sql.DbUtils;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import java.awt.Color;
import java.awt.event.KeyEvent;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import org.edisoncor.gui.button.ButtonAqua;
import Tabla.Tabla_Cuentas;
import java.awt.Component;
import java.awt.Desktop;
import java.awt.Dialog;
import java.awt.FileDialog;
import java.awt.Image;
import java.awt.Toolkit;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.Collections;
import java.util.Comparator;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ButtonModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.table.TableColumnModel;
import jdk.internal.org.jline.utils.Display;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.view.JasperViewer;
import org.codehaus.groovy.tools.shell.Shell;

public final class Sistema extends javax.swing.JFrame {

    Tabla_Cuentas t = new Tabla_Cuentas();
    SimpleDateFormat formatofecha = new SimpleDateFormat("dd/MM/yyyy");
    SimpleDateFormat formatofechaBackUp = new SimpleDateFormat("dd-MM-yyyy HH.mm.ss");
    public static int columna, row;
    Connection con = Conexion.ConnectDB();//Conecta a la cadena de conexión
    Date dato = null;
    ResultSet rs = null;
    PreparedStatement pst = null;
    Date fechaVenta = new Date();
    String fechaActual = new SimpleDateFormat("dd/MM/yyyy").format(fechaVenta);
    String NOCtaIA = null,NombreUsuario="";
    DefaultTableModel modelo = new DefaultTableModel();
    DefaultTableModel tmp = new DefaultTableModel();
    int item;
    double Totalpagar = 0.00;
    DefaultTableModel modelotabla = new DefaultTableModel();
    ButtonAqua boton1 = new ButtonAqua();
    private Component forms;
    public Double timbres = 0.00, burocredito = 0.00,
            avaluopropiedades = 0.00, traspasos = 0.00,
            gestioncobro = 0.00, emisionconstacias = 0.00,
            reposiciontarjetahorro = 0.00, hipotecas = 0.00;

    public Sistema() {
        initComponents();
        CargarDataMetodos();
        this.setIconImage(new ImageIcon(getClass().getResource("/Img/logo.png")).getImage());
        dateFechaIA.setDate(fechaVenta);
        dateFechaID.setDate(fechaVenta);
        dateFechaIP.setDate(fechaVenta);
        dateFechaIPD.setDate(fechaVenta);
        dateFechaEA.setDate(fechaVenta);
        //Color Tabla Ingresos Ahorro
        JTableHeader headerIA = TableCuentaIA.getTableHeader();
        headerIA.setOpaque(false);
        headerIA.setBackground(new Color(4, 154, 85));
        headerIA.setForeground(Color.white);
        headerIA.setReorderingAllowed(false);
        //Color Tabla Ingresos Diversos
        JTableHeader headerID = TableCuentaID.getTableHeader();
        headerID.setOpaque(false);
        headerID.setBackground(new Color(4, 154, 85));
        headerID.setForeground(Color.white);
        headerID.setReorderingAllowed(false);
        //Color Tabla Ingresos Prestamo
        JTableHeader headerIP = TableCuentaIP.getTableHeader();
        headerIP.setOpaque(false);
        headerIP.setBackground(new Color(4, 154, 85));
        headerIP.setForeground(Color.white);
        headerIP.setReorderingAllowed(false);
        //Color Tabla Ingresos Prestamo Demanda
        JTableHeader headerIPD = TableCuentaIPD.getTableHeader();
        headerIPD.setOpaque(false);
        headerIPD.setBackground(new Color(4, 154, 85));
        headerIPD.setForeground(Color.white);
        headerIPD.setReorderingAllowed(false);
        //Color Tabla Egresos Ahorro
        JTableHeader headerEA = TableCuentaEA.getTableHeader();
        headerEA.setOpaque(false);
        headerEA.setBackground(new Color(4, 154, 85));
        headerEA.setForeground(Color.white);
        headerEA.setReorderingAllowed(false);
        //Color Tabla Cuentas
        JTableHeader headerCuenta = TableCuenta.getTableHeader();
        headerCuenta.setOpaque(false);
        headerCuenta.setBackground(new Color(4, 154, 85));
        headerCuenta.setForeground(Color.white);
        headerCuenta.setReorderingAllowed(false);
        //Color Tabla Cuentas
        JTableHeader headerUsuarios = TableUsuarios.getTableHeader();
        headerUsuarios.setOpaque(false);
        headerUsuarios.setBackground(new Color(4, 154, 85));
        headerUsuarios.setForeground(Color.white);
        headerUsuarios.setReorderingAllowed(false);
        //Color Tabla Cuentas
        JTableHeader headerHistorial = TableFacturas.getTableHeader();
        headerHistorial.setOpaque(false);
        headerHistorial.setBackground(new Color(4, 154, 85));
        headerHistorial.setForeground(Color.white);
        headerHistorial.setReorderingAllowed(false);
        this.setLocationRelativeTo(null);
        jTabbedPane1.setSelectedIndex(9);
        txtIdCta.hide();
        txtIdUser.hide();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollBar1 = new javax.swing.JScrollBar();
        buttonGroup1 = new javax.swing.ButtonGroup();
        IPrestamo = new javax.swing.ButtonGroup();
        jScrollBar2 = new javax.swing.JScrollBar();
        IPrestamoD = new javax.swing.ButtonGroup();
        GreoupChkEA = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        tipo = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        LabelNombreUser = new javax.swing.JLabel();
        LabelVendedor1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        pnl_IAhorro = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txtIdIA = new javax.swing.JTextField();
        txtNombreIA = new javax.swing.JTextField();
        btnEliminarventa = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        txtTotalLetrasIA = new javax.swing.JTextField();
        btnGuardarIA = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        LabelTotalIA = new javax.swing.JLabel();
        dateFechaIA = new com.toedter.calendar.JDateChooser();
        jLabel11 = new javax.swing.JLabel();
        jPanel25 = new javax.swing.JPanel();
        jPanel23 = new javax.swing.JPanel();
        jPanel24 = new javax.swing.JPanel();
        IAchkNCtaAE = new javax.swing.JCheckBox();
        IAchkNCtaAPF = new javax.swing.JCheckBox();
        IAchkNCtaAR = new javax.swing.JCheckBox();
        IAchkNCtaAM = new javax.swing.JCheckBox();
        jScrollPane4 = new javax.swing.JScrollPane();
        TableCuentaIA = new javax.swing.JTable();
        jLabel38 = new javax.swing.JLabel();
        IAchkNCtaAN = new javax.swing.JCheckBox();
        jPanel29 = new javax.swing.JPanel();
        txtObservaIA = new javax.swing.JTextField();
        jLabel70 = new javax.swing.JLabel();
        IAchkNCtaAO = new javax.swing.JCheckBox();
        txtNumCuentaIA = new javax.swing.JTextField();
        btnEditarIA = new javax.swing.JButton();
        btnEliminarIA = new javax.swing.JButton();
        pnl_IDiversos = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        txtNumCuentaID = new javax.swing.JTextField();
        txtNombreID = new javax.swing.JTextField();
        btnEliminarID = new javax.swing.JButton();
        jLabel25 = new javax.swing.JLabel();
        txtObservaID = new javax.swing.JTextField();
        btnGuardarID = new javax.swing.JButton();
        jLabel43 = new javax.swing.JLabel();
        LabelTotalID = new javax.swing.JLabel();
        dateFechaID = new com.toedter.calendar.JDateChooser();
        jPanel32 = new javax.swing.JPanel();
        jPanel33 = new javax.swing.JPanel();
        jPanel47 = new javax.swing.JPanel();
        jScrollPane8 = new javax.swing.JScrollPane();
        TableCuentaID = new javax.swing.JTable();
        jLabel45 = new javax.swing.JLabel();
        jLabel46 = new javax.swing.JLabel();
        jPanel34 = new javax.swing.JPanel();
        txtTotalLetrasID = new javax.swing.JTextField();
        jLabel72 = new javax.swing.JLabel();
        txtIdID = new javax.swing.JTextField();
        btnEditarID = new javax.swing.JButton();
        btnDeleteID = new javax.swing.JButton();
        pnl_IPrestamo = new javax.swing.JPanel();
        jLabel33 = new javax.swing.JLabel();
        jLabel60 = new javax.swing.JLabel();
        jLabel66 = new javax.swing.JLabel();
        txtNumCuentaIP = new javax.swing.JTextField();
        txtNombreIP = new javax.swing.JTextField();
        btnEliminarIP = new javax.swing.JButton();
        btnGuardarIP = new javax.swing.JButton();
        dateFechaIP = new com.toedter.calendar.JDateChooser();
        jLabel67 = new javax.swing.JLabel();
        jPanel57 = new javax.swing.JPanel();
        jPanel60 = new javax.swing.JPanel();
        ChkLIP = new javax.swing.JCheckBox();
        Chk$IP = new javax.swing.JCheckBox();
        jScrollPane11 = new javax.swing.JScrollPane();
        TableCuentaIP = new javax.swing.JTable();
        jLabel68 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        jPanel61 = new javax.swing.JPanel();
        txtNPrestamoIP = new javax.swing.JTextField();
        jPanel68 = new javax.swing.JPanel();
        txtCicloIP = new javax.swing.JTextField();
        jLabel69 = new javax.swing.JLabel();
        jLabel83 = new javax.swing.JLabel();
        dateFechaEntregaIP = new com.toedter.calendar.JDateChooser();
        jLabel84 = new javax.swing.JLabel();
        dateFechaIFinslIP = new com.toedter.calendar.JDateChooser();
        jPanel69 = new javax.swing.JPanel();
        txtPlazoIP = new javax.swing.JTextField();
        jLabel85 = new javax.swing.JLabel();
        jPanel73 = new javax.swing.JPanel();
        txtTasaIP = new javax.swing.JTextField();
        jLabel86 = new javax.swing.JLabel();
        jPanel74 = new javax.swing.JPanel();
        jPanel75 = new javax.swing.JPanel();
        jLabel87 = new javax.swing.JLabel();
        txtObservaIP = new javax.swing.JTextField();
        jPanel76 = new javax.swing.JPanel();
        txtintereseAcumuIP = new javax.swing.JTextField();
        jPanel77 = new javax.swing.JPanel();
        txtsaldoActualIP = new javax.swing.JTextField();
        jPanel78 = new javax.swing.JPanel();
        LabelTotalIP = new javax.swing.JLabel();
        jLabel88 = new javax.swing.JLabel();
        jLabel89 = new javax.swing.JLabel();
        jLabel90 = new javax.swing.JLabel();
        jPanel79 = new javax.swing.JPanel();
        txtTotalLetrasIP = new javax.swing.JTextField();
        jLabel91 = new javax.swing.JLabel();
        txtIdIP = new javax.swing.JTextField();
        btnEditarIP = new javax.swing.JButton();
        btnDeleteIP = new javax.swing.JButton();
        pnl_IPrestamoDemanda = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        jLabel49 = new javax.swing.JLabel();
        jLabel54 = new javax.swing.JLabel();
        txtNumCuentaIPD = new javax.swing.JTextField();
        txtNombreIPD = new javax.swing.JTextField();
        btnEliminarIPD = new javax.swing.JButton();
        btnGuardarIPD = new javax.swing.JButton();
        dateFechaIPD = new com.toedter.calendar.JDateChooser();
        jLabel56 = new javax.swing.JLabel();
        jPanel55 = new javax.swing.JPanel();
        jPanel56 = new javax.swing.JPanel();
        ChkLIPD = new javax.swing.JCheckBox();
        Chk$IPD = new javax.swing.JCheckBox();
        jScrollPane10 = new javax.swing.JScrollPane();
        TableCuentaIPD = new javax.swing.JTable();
        jLabel57 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jPanel58 = new javax.swing.JPanel();
        txtNPrestamoIPD = new javax.swing.JTextField();
        jPanel59 = new javax.swing.JPanel();
        txtCicloIPD = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        jLabel58 = new javax.swing.JLabel();
        dateFechaEntregaIPD = new com.toedter.calendar.JDateChooser();
        jLabel59 = new javax.swing.JLabel();
        dateFechaIFinslIPD = new com.toedter.calendar.JDateChooser();
        jPanel62 = new javax.swing.JPanel();
        txtPlazoIPD = new javax.swing.JTextField();
        jLabel61 = new javax.swing.JLabel();
        jPanel63 = new javax.swing.JPanel();
        txtTasaIPD = new javax.swing.JTextField();
        jLabel62 = new javax.swing.JLabel();
        jPanel67 = new javax.swing.JPanel();
        jPanel53 = new javax.swing.JPanel();
        jLabel74 = new javax.swing.JLabel();
        txtObservaIPD = new javax.swing.JTextField();
        jPanel70 = new javax.swing.JPanel();
        txtintereseAcumuIPD = new javax.swing.JTextField();
        jPanel71 = new javax.swing.JPanel();
        txtsaldoActualIPD = new javax.swing.JTextField();
        jPanel72 = new javax.swing.JPanel();
        LabelTotalIPD = new javax.swing.JLabel();
        jLabel75 = new javax.swing.JLabel();
        jLabel76 = new javax.swing.JLabel();
        jLabel77 = new javax.swing.JLabel();
        jPanel36 = new javax.swing.JPanel();
        txtTotalLetrasIPD = new javax.swing.JTextField();
        jLabel78 = new javax.swing.JLabel();
        txtIdIPD = new javax.swing.JTextField();
        btnEditarIPD = new javax.swing.JButton();
        btnDeleteIPD = new javax.swing.JButton();
        pnl_EAhorro = new javax.swing.JPanel();
        jLabel55 = new javax.swing.JLabel();
        jLabel63 = new javax.swing.JLabel();
        jLabel64 = new javax.swing.JLabel();
        txtNumCuentaEA = new javax.swing.JTextField();
        txtNombreEA = new javax.swing.JTextField();
        btnEliminarventa1 = new javax.swing.JButton();
        jLabel65 = new javax.swing.JLabel();
        txtTotalLetrasEA = new javax.swing.JTextField();
        btnGuardarEA = new javax.swing.JButton();
        jLabel79 = new javax.swing.JLabel();
        LabelTotalEA = new javax.swing.JLabel();
        dateFechaEA = new com.toedter.calendar.JDateChooser();
        jLabel80 = new javax.swing.JLabel();
        jPanel37 = new javax.swing.JPanel();
        jPanel38 = new javax.swing.JPanel();
        jPanel46 = new javax.swing.JPanel();
        EAchkNCtaAE = new javax.swing.JCheckBox();
        EAchkNCtaAPF = new javax.swing.JCheckBox();
        EAchkNCtaAR = new javax.swing.JCheckBox();
        EAchkNCtaAM = new javax.swing.JCheckBox();
        jScrollPane12 = new javax.swing.JScrollPane();
        TableCuentaEA = new javax.swing.JTable();
        jLabel81 = new javax.swing.JLabel();
        EAchkNCtaAN = new javax.swing.JCheckBox();
        jPanel54 = new javax.swing.JPanel();
        txtObservaEA = new javax.swing.JTextField();
        jLabel82 = new javax.swing.JLabel();
        EAchkNCtaAO = new javax.swing.JCheckBox();
        txtIdEA = new javax.swing.JTextField();
        btnEditarEA = new javax.swing.JButton();
        btnEliminarEA = new javax.swing.JButton();
        pnl_cuentas = new javax.swing.JPanel();
        jPanel11 = new javax.swing.JPanel();
        jLabel22 = new javax.swing.JLabel();
        txtNumCta = new javax.swing.JTextField();
        jLabel23 = new javax.swing.JLabel();
        txtDescripcion = new javax.swing.JTextField();
        jLabel26 = new javax.swing.JLabel();
        cbxComprobante = new javax.swing.JComboBox<>();
        btnGuardarCta = new javax.swing.JButton();
        btnEditarCta = new javax.swing.JButton();
        btnEliminarCta = new javax.swing.JButton();
        btnNuevoCta = new javax.swing.JButton();
        jPanel30 = new javax.swing.JPanel();
        jPanel31 = new javax.swing.JPanel();
        jPanel39 = new javax.swing.JPanel();
        jLabel40 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        cbxMoneda = new javax.swing.JComboBox<>();
        jPanel20 = new javax.swing.JPanel();
        txtBuscarCuenta = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        cbxBuscarCuenta = new javax.swing.JComboBox<>();
        jScrollPane9 = new javax.swing.JScrollPane();
        TableCuenta = new javax.swing.JTable();
        pnl_usuario = new javax.swing.JPanel();
        jPanel13 = new javax.swing.JPanel();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        txtDominio = new javax.swing.JTextField();
        txtCorreo = new javax.swing.JTextField();
        txtPass = new javax.swing.JPasswordField();
        jLabel36 = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        jLabel37 = new javax.swing.JLabel();
        cbxRol = new javax.swing.JComboBox<>();
        jPanel15 = new javax.swing.JPanel();
        jPanel16 = new javax.swing.JPanel();
        jPanel17 = new javax.swing.JPanel();
        jPanel18 = new javax.swing.JPanel();
        jLabel39 = new javax.swing.JLabel();
        btnGuardarUser = new javax.swing.JButton();
        btnNuevoUser = new javax.swing.JButton();
        btnEliminarUser = new javax.swing.JButton();
        btnEditarUser = new javax.swing.JButton();
        jScrollPane6 = new javax.swing.JScrollPane();
        TableUsuarios = new javax.swing.JTable();
        pnl_historial = new javax.swing.JPanel();
        cbxBuscarFactura = new javax.swing.JComboBox<>();
        jScrollPane5 = new javax.swing.JScrollPane();
        TableFacturas = new javax.swing.JTable();
        jPanel21 = new javax.swing.JPanel();
        txtBuscarFacturas = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        pnl_empresa = new javax.swing.JPanel();
        jLabel32 = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        txtIdConfig = new javax.swing.JTextField();
        jLabel30 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        txtTelefonoConfig = new javax.swing.JTextField();
        txtDireccionConfig = new javax.swing.JTextField();
        jLabel31 = new javax.swing.JLabel();
        txtMensaje = new javax.swing.JTextField();
        btnActualizarConfig = new javax.swing.JButton();
        jLabel27 = new javax.swing.JLabel();
        txtRucConfig = new javax.swing.JTextField();
        jLabel28 = new javax.swing.JLabel();
        txtNombreConfig = new javax.swing.JTextField();
        jPanel41 = new javax.swing.JPanel();
        jPanel42 = new javax.swing.JPanel();
        jPanel43 = new javax.swing.JPanel();
        jPanel44 = new javax.swing.JPanel();
        jPanel45 = new javax.swing.JPanel();
        jLabel21 = new javax.swing.JLabel();
        jPanel40 = new javax.swing.JPanel();
        pnl_IAhorro1 = new javax.swing.JPanel();
        jLabel71 = new javax.swing.JLabel();
        jProgressBar1 = new javax.swing.JProgressBar();
        txtIdCta = new javax.swing.JTextField();
        txtIdUser = new javax.swing.JTextField();
        jMenuBar2 = new javax.swing.JMenuBar();
        mnusisreserva = new javax.swing.JMenu();
        mnuarchivo = new javax.swing.JMenu();
        cutMenuItem = new javax.swing.JMenuItem();
        jMenuItem6 = new javax.swing.JMenuItem();
        jMenuItem7 = new javax.swing.JMenuItem();
        copyMenuItem = new javax.swing.JMenuItem();
        jMenuItem5 = new javax.swing.JMenuItem();
        mnuconsultas = new javax.swing.JMenu();
        mnuConsultas = new javax.swing.JMenu();
        contentMenuItem = new javax.swing.JMenuItem();
        mnuconfiguraciones = new javax.swing.JMenu();
        jmUsuarios = new javax.swing.JMenuItem();
        jMenuItem10 = new javax.swing.JMenuItem();
        jMenuItem1 = new javax.swing.JMenuItem();
        mnuayuda = new javax.swing.JMenu();
        jMenuItem3 = new javax.swing.JMenuItem();
        jMenuItem4 = new javax.swing.JMenuItem();
        mnusalir = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Panel de Adminstración");
        setBackground(new java.awt.Color(255, 255, 255));
        setMinimumSize(new java.awt.Dimension(1356, 700));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(241, 226, 9));

        tipo.setForeground(new java.awt.Color(255, 255, 255));

        jButton1.setText("jButton1");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        LabelNombreUser.setBackground(new java.awt.Color(255, 255, 255));
        LabelNombreUser.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        LabelNombreUser.setForeground(new java.awt.Color(51, 51, 51));
        LabelNombreUser.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        LabelNombreUser.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/teamwork.png"))); // NOI18N
        LabelNombreUser.setText("Administrador");
        LabelNombreUser.setIconTextGap(10);

        LabelVendedor1.setBackground(new java.awt.Color(255, 255, 255));
        LabelVendedor1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        LabelVendedor1.setForeground(new java.awt.Color(51, 51, 51));
        LabelVendedor1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        LabelVendedor1.setText("Bienvenido (a)");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(79, 79, 79)
                .addComponent(tipo)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(71, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addGap(52, 52, 52))
            .addComponent(LabelVendedor1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(LabelNombreUser, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(LabelVendedor1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(LabelNombreUser, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(68, 68, 68)
                .addComponent(tipo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addGap(29, 29, 29))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 200, 140));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/waves.png"))); // NOI18N
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 0, 1160, 140));

        jTabbedPane1.setBackground(new java.awt.Color(255, 255, 255));
        jTabbedPane1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));

        pnl_IAhorro.setBackground(new java.awt.Color(255, 255, 255));
        pnl_IAhorro.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel3.setText("Número de Cuenta:");
        pnl_IAhorro.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, -1, -1));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("Tipo de Cuenta:");
        pnl_IAhorro.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 110, -1, 30));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(51, 51, 51));
        jLabel7.setText("Nombre Completo:");
        pnl_IAhorro.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 170, -1, -1));

        txtIdIA.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtIdIA.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        txtIdIA.setBorder(null);
        txtIdIA.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtIdIAKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtIdIAKeyTyped(evt);
            }
        });
        pnl_IAhorro.add(txtIdIA, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 60, 60, 30));

        txtNombreIA.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtNombreIA.setBorder(null);
        pnl_IAhorro.add(txtNombreIA, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 160, 740, 30));

        btnEliminarventa.setBackground(new java.awt.Color(241, 226, 9));
        btnEliminarventa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/new.png"))); // NOI18N
        btnEliminarventa.setToolTipText("Nueva Factura");
        btnEliminarventa.setBorderPainted(false);
        btnEliminarventa.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnEliminarventa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarventaActionPerformed(evt);
            }
        });
        pnl_IAhorro.add(btnEliminarventa, new org.netbeans.lib.awtextra.AbsoluteConstraints(1277, 400, 60, 50));

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jLabel8.setText("Total en Letras:");
        pnl_IAhorro.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 460, -1, -1));

        txtTotalLetrasIA.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtTotalLetrasIA.setBorder(null);
        txtTotalLetrasIA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTotalLetrasIAActionPerformed(evt);
            }
        });
        txtTotalLetrasIA.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtTotalLetrasIAKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtTotalLetrasIAKeyTyped(evt);
            }
        });
        pnl_IAhorro.add(txtTotalLetrasIA, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 450, 950, 30));

        btnGuardarIA.setBackground(new java.awt.Color(241, 226, 9));
        btnGuardarIA.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/print.png"))); // NOI18N
        btnGuardarIA.setToolTipText("Guardar e Imprimir");
        btnGuardarIA.setBorderPainted(false);
        btnGuardarIA.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnGuardarIA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarIAActionPerformed(evt);
            }
        });
        pnl_IAhorro.add(btnGuardarIA, new org.netbeans.lib.awtextra.AbsoluteConstraints(1210, 400, 60, 50));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/money.png"))); // NOI18N
        jLabel10.setText("Total:");
        pnl_IAhorro.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 400, 90, 40));

        LabelTotalIA.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        LabelTotalIA.setText("0.00");
        pnl_IAhorro.add(LabelTotalIA, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 400, 330, 40));

        dateFechaIA.setBackground(new java.awt.Color(204, 204, 204));
        dateFechaIA.setDateFormatString("dd/MM/yyyy");
        dateFechaIA.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        pnl_IAhorro.add(dateFechaIA, new org.netbeans.lib.awtextra.AbsoluteConstraints(1080, 160, 230, 30));

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel11.setText("Fecha de Pago:");
        pnl_IAhorro.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(950, 170, 120, -1));

        jPanel25.setBackground(new java.awt.Color(4, 154, 85));

        javax.swing.GroupLayout jPanel25Layout = new javax.swing.GroupLayout(jPanel25);
        jPanel25.setLayout(jPanel25Layout);
        jPanel25Layout.setHorizontalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 500, Short.MAX_VALUE)
        );
        jPanel25Layout.setVerticalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 2, Short.MAX_VALUE)
        );

        pnl_IAhorro.add(jPanel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 140, 500, -1));

        jPanel23.setBackground(new java.awt.Color(4, 154, 85));

        javax.swing.GroupLayout jPanel23Layout = new javax.swing.GroupLayout(jPanel23);
        jPanel23.setLayout(jPanel23Layout);
        jPanel23Layout.setHorizontalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 740, Short.MAX_VALUE)
        );
        jPanel23Layout.setVerticalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 2, Short.MAX_VALUE)
        );

        pnl_IAhorro.add(jPanel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 190, 740, 2));

        jPanel24.setBackground(new java.awt.Color(4, 154, 85));

        javax.swing.GroupLayout jPanel24Layout = new javax.swing.GroupLayout(jPanel24);
        jPanel24.setLayout(jPanel24Layout);
        jPanel24Layout.setHorizontalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 950, Short.MAX_VALUE)
        );
        jPanel24Layout.setVerticalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 2, Short.MAX_VALUE)
        );

        pnl_IAhorro.add(jPanel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 480, 950, 2));

        buttonGroup1.add(IAchkNCtaAE);
        IAchkNCtaAE.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        IAchkNCtaAE.setText("A.E.");
        IAchkNCtaAE.setToolTipText("Aportaciones Extraordinaria");
        IAchkNCtaAE.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        IAchkNCtaAE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                IAchkNCtaAEActionPerformed(evt);
            }
        });
        pnl_IAhorro.add(IAchkNCtaAE, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 110, 80, -1));

        buttonGroup1.add(IAchkNCtaAPF);
        IAchkNCtaAPF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        IAchkNCtaAPF.setText("A.P.F.");
        IAchkNCtaAPF.setToolTipText("Ahorro a Plazo Fijo");
        IAchkNCtaAPF.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        IAchkNCtaAPF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                IAchkNCtaAPFActionPerformed(evt);
            }
        });
        pnl_IAhorro.add(IAchkNCtaAPF, new org.netbeans.lib.awtextra.AbsoluteConstraints(1150, 110, 80, -1));

        buttonGroup1.add(IAchkNCtaAR);
        IAchkNCtaAR.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        IAchkNCtaAR.setText("A.R.");
        IAchkNCtaAR.setToolTipText("Ahorro Retirable");
        IAchkNCtaAR.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        IAchkNCtaAR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                IAchkNCtaARActionPerformed(evt);
            }
        });
        pnl_IAhorro.add(IAchkNCtaAR, new org.netbeans.lib.awtextra.AbsoluteConstraints(1240, 110, 70, -1));

        buttonGroup1.add(IAchkNCtaAM);
        IAchkNCtaAM.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        IAchkNCtaAM.setText("A.M.");
        IAchkNCtaAM.setToolTipText("Ahorro de Menores");
        IAchkNCtaAM.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        IAchkNCtaAM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                IAchkNCtaAMActionPerformed(evt);
            }
        });
        pnl_IAhorro.add(IAchkNCtaAM, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 110, 80, -1));

        TableCuentaIA.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "CUENTA", "DESCRIPCIÓN", "VALORES", "Title 4"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, true, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        TableCuentaIA.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        TableCuentaIA.setSelectionBackground(new java.awt.Color(241, 226, 9));
        TableCuentaIA.setSelectionForeground(new java.awt.Color(0, 0, 0));
        TableCuentaIA.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TableCuentaIAMouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(TableCuentaIA);

        pnl_IAhorro.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 210, 1320, 180));

        jLabel38.setFont(new java.awt.Font("Yu Gothic Light", 3, 24)); // NOI18N
        jLabel38.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel38.setText("COMPROBANTE DE INGRESOS DE AHORRO");
        pnl_IAhorro.add(jLabel38, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 30, 1350, 70));

        buttonGroup1.add(IAchkNCtaAN);
        IAchkNCtaAN.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        IAchkNCtaAN.setText("A.N.");
        IAchkNCtaAN.setToolTipText("Ahorro Navideño");
        IAchkNCtaAN.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        IAchkNCtaAN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                IAchkNCtaANActionPerformed(evt);
            }
        });
        pnl_IAhorro.add(IAchkNCtaAN, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 110, 80, 30));

        jPanel29.setBackground(new java.awt.Color(4, 154, 85));

        javax.swing.GroupLayout jPanel29Layout = new javax.swing.GroupLayout(jPanel29);
        jPanel29.setLayout(jPanel29Layout);
        jPanel29Layout.setHorizontalGroup(
            jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1010, Short.MAX_VALUE)
        );
        jPanel29Layout.setVerticalGroup(
            jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 2, Short.MAX_VALUE)
        );

        pnl_IAhorro.add(jPanel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 530, 1010, 2));

        txtObservaIA.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtObservaIA.setBorder(null);
        txtObservaIA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtObservaIAActionPerformed(evt);
            }
        });
        txtObservaIA.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtObservaIAKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtObservaIAKeyTyped(evt);
            }
        });
        pnl_IAhorro.add(txtObservaIA, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 500, 1010, 30));

        jLabel70.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jLabel70.setText("Observaciones:");
        pnl_IAhorro.add(jLabel70, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 510, 130, -1));

        buttonGroup1.add(IAchkNCtaAO);
        IAchkNCtaAO.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        IAchkNCtaAO.setText("A.O.");
        IAchkNCtaAO.setToolTipText("Aportaciones Obligatorias");
        IAchkNCtaAO.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        IAchkNCtaAO.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                IAchkNCtaAOActionPerformed(evt);
            }
        });
        pnl_IAhorro.add(IAchkNCtaAO, new org.netbeans.lib.awtextra.AbsoluteConstraints(1060, 110, 80, -1));

        txtNumCuentaIA.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtNumCuentaIA.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        txtNumCuentaIA.setBorder(null);
        txtNumCuentaIA.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtNumCuentaIAKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtNumCuentaIAKeyTyped(evt);
            }
        });
        pnl_IAhorro.add(txtNumCuentaIA, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 110, 490, 30));

        btnEditarIA.setBackground(new java.awt.Color(241, 226, 9));
        btnEditarIA.setForeground(new java.awt.Color(255, 255, 255));
        btnEditarIA.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/update.png"))); // NOI18N
        btnEditarIA.setToolTipText("Actualizar Factura");
        btnEditarIA.setBorderPainted(false);
        btnEditarIA.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnEditarIA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarIAActionPerformed(evt);
            }
        });
        pnl_IAhorro.add(btnEditarIA, new org.netbeans.lib.awtextra.AbsoluteConstraints(1070, 400, 60, 50));

        btnEliminarIA.setBackground(new java.awt.Color(241, 226, 9));
        btnEliminarIA.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/delete.png"))); // NOI18N
        btnEliminarIA.setToolTipText("Eliminar Factura");
        btnEliminarIA.setBorderPainted(false);
        btnEliminarIA.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnEliminarIA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarIAActionPerformed(evt);
            }
        });
        pnl_IAhorro.add(btnEliminarIA, new org.netbeans.lib.awtextra.AbsoluteConstraints(1140, 400, 60, 50));

        jTabbedPane1.addTab("1", pnl_IAhorro);

        pnl_IDiversos.setBackground(new java.awt.Color(255, 255, 255));
        pnl_IDiversos.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel6.setText("Fecha de Pago:");
        pnl_IDiversos.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(950, 110, -1, -1));

        jLabel24.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel24.setText("Nombre Completo:");
        pnl_IDiversos.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, -1, -1));

        txtNumCuentaID.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtNumCuentaID.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        txtNumCuentaID.setBorder(null);
        txtNumCuentaID.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtNumCuentaIDKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtNumCuentaIDKeyTyped(evt);
            }
        });
        pnl_IDiversos.add(txtNumCuentaID, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 100, 300, 30));

        txtNombreID.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtNombreID.setBorder(null);
        pnl_IDiversos.add(txtNombreID, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 150, 910, 30));

        btnEliminarID.setBackground(new java.awt.Color(241, 226, 9));
        btnEliminarID.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/new.png"))); // NOI18N
        btnEliminarID.setToolTipText("Nueva Factura");
        btnEliminarID.setBorderPainted(false);
        btnEliminarID.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnEliminarID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarIDActionPerformed(evt);
            }
        });
        pnl_IDiversos.add(btnEliminarID, new org.netbeans.lib.awtextra.AbsoluteConstraints(1280, 400, 60, 50));

        jLabel25.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jLabel25.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel25.setText("Observaciones:");
        pnl_IDiversos.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 500, 130, 20));

        txtObservaID.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtObservaID.setBorder(null);
        txtObservaID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtObservaIDActionPerformed(evt);
            }
        });
        txtObservaID.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtObservaIDKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtObservaIDKeyTyped(evt);
            }
        });
        pnl_IDiversos.add(txtObservaID, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 490, 1130, 30));

        btnGuardarID.setBackground(new java.awt.Color(241, 226, 9));
        btnGuardarID.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/print.png"))); // NOI18N
        btnGuardarID.setToolTipText("Guardar e Imprimir");
        btnGuardarID.setBorderPainted(false);
        btnGuardarID.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnGuardarID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarIDActionPerformed(evt);
            }
        });
        pnl_IDiversos.add(btnGuardarID, new org.netbeans.lib.awtextra.AbsoluteConstraints(1210, 400, 60, 50));

        jLabel43.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel43.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel43.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/money.png"))); // NOI18N
        jLabel43.setText("Total:");
        pnl_IDiversos.add(jLabel43, new org.netbeans.lib.awtextra.AbsoluteConstraints(568, 400, 100, 40));

        LabelTotalID.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        LabelTotalID.setText("0.00");
        pnl_IDiversos.add(LabelTotalID, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 400, 160, 40));

        dateFechaID.setBackground(new java.awt.Color(204, 204, 204));
        dateFechaID.setDateFormatString("dd/MM/yyyy");
        dateFechaID.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        pnl_IDiversos.add(dateFechaID, new org.netbeans.lib.awtextra.AbsoluteConstraints(1070, 100, 260, 30));

        jPanel32.setBackground(new java.awt.Color(4, 154, 85));

        javax.swing.GroupLayout jPanel32Layout = new javax.swing.GroupLayout(jPanel32);
        jPanel32.setLayout(jPanel32Layout);
        jPanel32Layout.setHorizontalGroup(
            jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );
        jPanel32Layout.setVerticalGroup(
            jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 2, Short.MAX_VALUE)
        );

        pnl_IDiversos.add(jPanel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 130, 300, -1));

        jPanel33.setBackground(new java.awt.Color(4, 154, 85));

        javax.swing.GroupLayout jPanel33Layout = new javax.swing.GroupLayout(jPanel33);
        jPanel33.setLayout(jPanel33Layout);
        jPanel33Layout.setHorizontalGroup(
            jPanel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 910, Short.MAX_VALUE)
        );
        jPanel33Layout.setVerticalGroup(
            jPanel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 2, Short.MAX_VALUE)
        );

        pnl_IDiversos.add(jPanel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 180, 910, 2));

        jPanel47.setBackground(new java.awt.Color(4, 154, 85));

        javax.swing.GroupLayout jPanel47Layout = new javax.swing.GroupLayout(jPanel47);
        jPanel47.setLayout(jPanel47Layout);
        jPanel47Layout.setHorizontalGroup(
            jPanel47Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1130, Short.MAX_VALUE)
        );
        jPanel47Layout.setVerticalGroup(
            jPanel47Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 2, Short.MAX_VALUE)
        );

        pnl_IDiversos.add(jPanel47, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 520, 1130, 2));

        TableCuentaID.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "CUENTA", "DESCRIPCIÓN", "VALORES", "Title 4"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, true, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        TableCuentaID.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        TableCuentaID.setSelectionBackground(new java.awt.Color(241, 226, 9));
        TableCuentaID.setSelectionForeground(new java.awt.Color(0, 0, 0));
        TableCuentaID.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TableCuentaIDMouseClicked(evt);
            }
        });
        jScrollPane8.setViewportView(TableCuentaID);

        pnl_IDiversos.add(jScrollPane8, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 200, 1320, 190));

        jLabel45.setFont(new java.awt.Font("Yu Gothic Light", 3, 24)); // NOI18N
        jLabel45.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel45.setText("COMPROBANTE DE INGRESOS DIVERSOS");
        pnl_IDiversos.add(jLabel45, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 30, 1350, 70));

        jLabel46.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel46.setText("Num. Cuenta:");
        pnl_IDiversos.add(jLabel46, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, -1, -1));

        jPanel34.setBackground(new java.awt.Color(4, 154, 85));

        javax.swing.GroupLayout jPanel34Layout = new javax.swing.GroupLayout(jPanel34);
        jPanel34.setLayout(jPanel34Layout);
        jPanel34Layout.setHorizontalGroup(
            jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 860, Short.MAX_VALUE)
        );
        jPanel34Layout.setVerticalGroup(
            jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 2, Short.MAX_VALUE)
        );

        pnl_IDiversos.add(jPanel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 470, 860, 2));

        txtTotalLetrasID.setBorder(null);
        txtTotalLetrasID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTotalLetrasIDActionPerformed(evt);
            }
        });
        txtTotalLetrasID.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtTotalLetrasIDKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtTotalLetrasIDKeyTyped(evt);
            }
        });
        pnl_IDiversos.add(txtTotalLetrasID, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 440, 860, 30));

        jLabel72.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jLabel72.setText("Total en Letras:");
        pnl_IDiversos.add(jLabel72, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 450, 130, -1));

        txtIdID.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtIdID.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        txtIdID.setBorder(null);
        txtIdID.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtIdIDKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtIdIDKeyTyped(evt);
            }
        });
        pnl_IDiversos.add(txtIdID, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 60, 60, 30));

        btnEditarID.setBackground(new java.awt.Color(241, 226, 9));
        btnEditarID.setForeground(new java.awt.Color(255, 255, 255));
        btnEditarID.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/update.png"))); // NOI18N
        btnEditarID.setToolTipText("Actualizar Factura");
        btnEditarID.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(102, 204, 255), java.awt.Color.red));
        btnEditarID.setBorderPainted(false);
        btnEditarID.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnEditarID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarIDActionPerformed(evt);
            }
        });
        pnl_IDiversos.add(btnEditarID, new org.netbeans.lib.awtextra.AbsoluteConstraints(1070, 400, 60, 50));

        btnDeleteID.setBackground(new java.awt.Color(241, 226, 9));
        btnDeleteID.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/delete.png"))); // NOI18N
        btnDeleteID.setToolTipText("Eliminar Factura");
        btnDeleteID.setBorderPainted(false);
        btnDeleteID.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnDeleteID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteIDActionPerformed(evt);
            }
        });
        pnl_IDiversos.add(btnDeleteID, new org.netbeans.lib.awtextra.AbsoluteConstraints(1140, 400, 60, 50));

        jTabbedPane1.addTab("1", pnl_IDiversos);

        pnl_IPrestamo.setBackground(new java.awt.Color(255, 255, 255));
        pnl_IPrestamo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel33.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel33.setText("Num de Cuenta:");
        pnl_IPrestamo.add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 90, -1, -1));

        jLabel60.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel60.setText("Moneda:");
        pnl_IPrestamo.add(jLabel60, new org.netbeans.lib.awtextra.AbsoluteConstraints(1150, 90, 70, 30));

        jLabel66.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel66.setForeground(new java.awt.Color(51, 51, 51));
        jLabel66.setText("Nombre Completo:");
        pnl_IPrestamo.add(jLabel66, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 135, 140, 20));

        txtNumCuentaIP.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtNumCuentaIP.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        txtNumCuentaIP.setBorder(null);
        txtNumCuentaIP.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtNumCuentaIPKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtNumCuentaIPKeyTyped(evt);
            }
        });
        pnl_IPrestamo.add(txtNumCuentaIP, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 80, 400, 30));

        txtNombreIP.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtNombreIP.setBorder(null);
        pnl_IPrestamo.add(txtNombreIP, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 130, 860, 30));

        btnEliminarIP.setBackground(new java.awt.Color(241, 226, 9));
        btnEliminarIP.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/new.png"))); // NOI18N
        btnEliminarIP.setToolTipText("Nueva Factura");
        btnEliminarIP.setBorderPainted(false);
        btnEliminarIP.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnEliminarIP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarIPActionPerformed(evt);
            }
        });
        pnl_IPrestamo.add(btnEliminarIP, new org.netbeans.lib.awtextra.AbsoluteConstraints(1280, 360, 60, 50));

        btnGuardarIP.setBackground(new java.awt.Color(241, 226, 9));
        btnGuardarIP.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/print.png"))); // NOI18N
        btnGuardarIP.setToolTipText("Guardar e Imprimir");
        btnGuardarIP.setBorderPainted(false);
        btnGuardarIP.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnGuardarIP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarIPActionPerformed(evt);
            }
        });
        pnl_IPrestamo.add(btnGuardarIP, new org.netbeans.lib.awtextra.AbsoluteConstraints(1210, 360, 60, 50));

        dateFechaIP.setBackground(new java.awt.Color(204, 204, 204));
        dateFechaIP.setDateFormatString("dd/MM/yyyy");
        dateFechaIP.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        pnl_IPrestamo.add(dateFechaIP, new org.netbeans.lib.awtextra.AbsoluteConstraints(1160, 140, 180, 30));

        jLabel67.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel67.setText("Fecha de Pago:");
        pnl_IPrestamo.add(jLabel67, new org.netbeans.lib.awtextra.AbsoluteConstraints(1050, 137, -1, 30));

        jPanel57.setBackground(new java.awt.Color(4, 154, 85));

        javax.swing.GroupLayout jPanel57Layout = new javax.swing.GroupLayout(jPanel57);
        jPanel57.setLayout(jPanel57Layout);
        jPanel57Layout.setHorizontalGroup(
            jPanel57Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel57Layout.setVerticalGroup(
            jPanel57Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        pnl_IPrestamo.add(jPanel57, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 110, 410, 2));

        jPanel60.setBackground(new java.awt.Color(4, 154, 85));

        javax.swing.GroupLayout jPanel60Layout = new javax.swing.GroupLayout(jPanel60);
        jPanel60.setLayout(jPanel60Layout);
        jPanel60Layout.setHorizontalGroup(
            jPanel60Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel60Layout.setVerticalGroup(
            jPanel60Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        pnl_IPrestamo.add(jPanel60, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 160, 860, 2));

        IPrestamo.add(ChkLIP);
        ChkLIP.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        ChkLIP.setText("L.  ");
        ChkLIP.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ChkLIP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ChkLIPActionPerformed(evt);
            }
        });
        pnl_IPrestamo.add(ChkLIP, new org.netbeans.lib.awtextra.AbsoluteConstraints(1220, 90, 50, -1));

        IPrestamo.add(Chk$IP);
        Chk$IP.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        Chk$IP.setText("$   ");
        Chk$IP.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Chk$IP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Chk$IPActionPerformed(evt);
            }
        });
        pnl_IPrestamo.add(Chk$IP, new org.netbeans.lib.awtextra.AbsoluteConstraints(1285, 90, 50, -1));

        TableCuentaIP.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "CUENTA", "DESCRIPCIÓN", "VALORES", "Title 4"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, true, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        TableCuentaIP.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        TableCuentaIP.setSelectionBackground(new java.awt.Color(241, 226, 9));
        TableCuentaIP.setSelectionForeground(new java.awt.Color(0, 0, 0));
        TableCuentaIP.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TableCuentaIPMouseClicked(evt);
            }
        });
        jScrollPane11.setViewportView(TableCuentaIP);

        pnl_IPrestamo.add(jScrollPane11, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 230, 1330, 120));

        jLabel68.setFont(new java.awt.Font("Yu Gothic Light", 3, 24)); // NOI18N
        jLabel68.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel68.setText("COMPROBANTE DE INGRESOS DE PRESTAMOS ");
        pnl_IPrestamo.add(jLabel68, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 20, 1350, 60));

        jLabel41.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel41.setText("No. de Préstamo:");
        pnl_IPrestamo.add(jLabel41, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 90, -1, -1));

        jPanel61.setBackground(new java.awt.Color(4, 154, 85));

        javax.swing.GroupLayout jPanel61Layout = new javax.swing.GroupLayout(jPanel61);
        jPanel61.setLayout(jPanel61Layout);
        jPanel61Layout.setHorizontalGroup(
            jPanel61Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel61Layout.setVerticalGroup(
            jPanel61Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        pnl_IPrestamo.add(jPanel61, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 110, 190, 2));

        txtNPrestamoIP.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtNPrestamoIP.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        txtNPrestamoIP.setBorder(null);
        txtNPrestamoIP.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtNPrestamoIPKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtNPrestamoIPKeyTyped(evt);
            }
        });
        pnl_IPrestamo.add(txtNPrestamoIP, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 80, 190, 30));

        jPanel68.setBackground(new java.awt.Color(4, 154, 85));

        javax.swing.GroupLayout jPanel68Layout = new javax.swing.GroupLayout(jPanel68);
        jPanel68.setLayout(jPanel68Layout);
        jPanel68Layout.setHorizontalGroup(
            jPanel68Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel68Layout.setVerticalGroup(
            jPanel68Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        pnl_IPrestamo.add(jPanel68, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 110, 170, 2));

        txtCicloIP.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtCicloIP.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        txtCicloIP.setBorder(null);
        txtCicloIP.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtCicloIPKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtCicloIPKeyTyped(evt);
            }
        });
        pnl_IPrestamo.add(txtCicloIP, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 80, 170, 30));

        jLabel69.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel69.setText("Ciclo:");
        pnl_IPrestamo.add(jLabel69, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 90, -1, -1));

        jLabel83.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel83.setText("Fecha de Entrega:");
        pnl_IPrestamo.add(jLabel83, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 200, -1, -1));

        dateFechaEntregaIP.setBackground(new java.awt.Color(204, 204, 204));
        dateFechaEntregaIP.setDateFormatString("dd/MM/yyyy");
        dateFechaEntregaIP.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        pnl_IPrestamo.add(dateFechaEntregaIP, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 190, 240, 30));

        jLabel84.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel84.setText("Fecha de Finalización:");
        pnl_IPrestamo.add(jLabel84, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 190, 160, 30));

        dateFechaIFinslIP.setBackground(new java.awt.Color(204, 204, 204));
        dateFechaIFinslIP.setDateFormatString("dd/MM/yyyy");
        dateFechaIFinslIP.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        pnl_IPrestamo.add(dateFechaIFinslIP, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 190, 220, 30));

        jPanel69.setBackground(new java.awt.Color(4, 154, 85));

        javax.swing.GroupLayout jPanel69Layout = new javax.swing.GroupLayout(jPanel69);
        jPanel69.setLayout(jPanel69Layout);
        jPanel69Layout.setHorizontalGroup(
            jPanel69Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel69Layout.setVerticalGroup(
            jPanel69Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        pnl_IPrestamo.add(jPanel69, new org.netbeans.lib.awtextra.AbsoluteConstraints(900, 220, 180, 2));

        txtPlazoIP.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        txtPlazoIP.setBorder(null);
        txtPlazoIP.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtPlazoIPKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtPlazoIPKeyTyped(evt);
            }
        });
        pnl_IPrestamo.add(txtPlazoIP, new org.netbeans.lib.awtextra.AbsoluteConstraints(900, 190, 170, 30));

        jLabel85.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel85.setText("Plazo:");
        pnl_IPrestamo.add(jLabel85, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 190, 50, 30));

        jPanel73.setBackground(new java.awt.Color(4, 154, 85));

        javax.swing.GroupLayout jPanel73Layout = new javax.swing.GroupLayout(jPanel73);
        jPanel73.setLayout(jPanel73Layout);
        jPanel73Layout.setHorizontalGroup(
            jPanel73Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel73Layout.setVerticalGroup(
            jPanel73Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        pnl_IPrestamo.add(jPanel73, new org.netbeans.lib.awtextra.AbsoluteConstraints(1170, 220, 170, 2));

        txtTasaIP.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtTasaIP.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        txtTasaIP.setBorder(null);
        txtTasaIP.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtTasaIPKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtTasaIPKeyTyped(evt);
            }
        });
        pnl_IPrestamo.add(txtTasaIP, new org.netbeans.lib.awtextra.AbsoluteConstraints(1170, 190, 160, 30));

        jLabel86.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel86.setText("Tasa:");
        pnl_IPrestamo.add(jLabel86, new org.netbeans.lib.awtextra.AbsoluteConstraints(1120, 200, -1, -1));

        jPanel74.setBackground(new java.awt.Color(4, 154, 85));

        javax.swing.GroupLayout jPanel74Layout = new javax.swing.GroupLayout(jPanel74);
        jPanel74.setLayout(jPanel74Layout);
        jPanel74Layout.setHorizontalGroup(
            jPanel74Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel74Layout.setVerticalGroup(
            jPanel74Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        pnl_IPrestamo.add(jPanel74, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 380, 110, -1));

        jPanel75.setBackground(new java.awt.Color(4, 154, 85));

        javax.swing.GroupLayout jPanel75Layout = new javax.swing.GroupLayout(jPanel75);
        jPanel75.setLayout(jPanel75Layout);
        jPanel75Layout.setHorizontalGroup(
            jPanel75Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel75Layout.setVerticalGroup(
            jPanel75Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        pnl_IPrestamo.add(jPanel75, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 510, 680, 2));

        jLabel87.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jLabel87.setText("Observaciones:");
        pnl_IPrestamo.add(jLabel87, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 490, 130, -1));

        txtObservaIP.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtObservaIP.setBorder(null);
        txtObservaIP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtObservaIPActionPerformed(evt);
            }
        });
        txtObservaIP.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtObservaIPKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtObservaIPKeyTyped(evt);
            }
        });
        pnl_IPrestamo.add(txtObservaIP, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 480, 680, 30));

        jPanel76.setBackground(new java.awt.Color(4, 154, 85));

        javax.swing.GroupLayout jPanel76Layout = new javax.swing.GroupLayout(jPanel76);
        jPanel76.setLayout(jPanel76Layout);
        jPanel76Layout.setHorizontalGroup(
            jPanel76Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel76Layout.setVerticalGroup(
            jPanel76Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        pnl_IPrestamo.add(jPanel76, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 462, 160, 2));

        txtintereseAcumuIP.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        txtintereseAcumuIP.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        txtintereseAcumuIP.setBorder(null);
        txtintereseAcumuIP.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtintereseAcumuIPKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtintereseAcumuIPKeyTyped(evt);
            }
        });
        pnl_IPrestamo.add(txtintereseAcumuIP, new org.netbeans.lib.awtextra.AbsoluteConstraints(692, 430, 150, 30));

        jPanel77.setBackground(new java.awt.Color(4, 154, 85));

        javax.swing.GroupLayout jPanel77Layout = new javax.swing.GroupLayout(jPanel77);
        jPanel77.setLayout(jPanel77Layout);
        jPanel77Layout.setHorizontalGroup(
            jPanel77Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel77Layout.setVerticalGroup(
            jPanel77Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        pnl_IPrestamo.add(jPanel77, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 422, 160, 2));

        txtsaldoActualIP.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        txtsaldoActualIP.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        txtsaldoActualIP.setBorder(null);
        txtsaldoActualIP.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtsaldoActualIPKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtsaldoActualIPKeyTyped(evt);
            }
        });
        pnl_IPrestamo.add(txtsaldoActualIP, new org.netbeans.lib.awtextra.AbsoluteConstraints(692, 390, 150, 30));

        jPanel78.setBackground(new java.awt.Color(4, 154, 85));

        javax.swing.GroupLayout jPanel78Layout = new javax.swing.GroupLayout(jPanel78);
        jPanel78.setLayout(jPanel78Layout);
        jPanel78Layout.setHorizontalGroup(
            jPanel78Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel78Layout.setVerticalGroup(
            jPanel78Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        pnl_IPrestamo.add(jPanel78, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 382, 160, 2));

        LabelTotalIP.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        LabelTotalIP.setText("0.00");
        pnl_IPrestamo.add(LabelTotalIP, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 350, 160, 30));

        jLabel88.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel88.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel88.setText("Total:");
        jLabel88.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        pnl_IPrestamo.add(jLabel88, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 360, 80, -1));

        jLabel89.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel89.setText("Saldo Actual de Préstamo:");
        pnl_IPrestamo.add(jLabel89, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 400, -1, -1));

        jLabel90.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel90.setText("Intereses Acumulados:");
        pnl_IPrestamo.add(jLabel90, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 440, -1, -1));

        jPanel79.setBackground(new java.awt.Color(4, 154, 85));

        javax.swing.GroupLayout jPanel79Layout = new javax.swing.GroupLayout(jPanel79);
        jPanel79.setLayout(jPanel79Layout);
        jPanel79Layout.setHorizontalGroup(
            jPanel79Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel79Layout.setVerticalGroup(
            jPanel79Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        pnl_IPrestamo.add(jPanel79, new org.netbeans.lib.awtextra.AbsoluteConstraints(990, 510, 350, 2));

        txtTotalLetrasIP.setBorder(null);
        txtTotalLetrasIP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTotalLetrasIPActionPerformed(evt);
            }
        });
        txtTotalLetrasIP.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtTotalLetrasIPKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtTotalLetrasIPKeyTyped(evt);
            }
        });
        pnl_IPrestamo.add(txtTotalLetrasIP, new org.netbeans.lib.awtextra.AbsoluteConstraints(990, 480, 350, 30));

        jLabel91.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jLabel91.setText("Total en Letras:");
        pnl_IPrestamo.add(jLabel91, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 490, 130, -1));

        txtIdIP.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtIdIP.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        txtIdIP.setBorder(null);
        txtIdIP.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtIdIPKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtIdIPKeyTyped(evt);
            }
        });
        pnl_IPrestamo.add(txtIdIP, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 60, 60, 30));

        btnEditarIP.setBackground(new java.awt.Color(241, 226, 9));
        btnEditarIP.setForeground(new java.awt.Color(255, 255, 255));
        btnEditarIP.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/update.png"))); // NOI18N
        btnEditarIP.setToolTipText("Actualizar Factura");
        btnEditarIP.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(102, 204, 255), java.awt.Color.red));
        btnEditarIP.setBorderPainted(false);
        btnEditarIP.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnEditarIP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarIPActionPerformed(evt);
            }
        });
        pnl_IPrestamo.add(btnEditarIP, new org.netbeans.lib.awtextra.AbsoluteConstraints(1070, 360, 60, 50));

        btnDeleteIP.setBackground(new java.awt.Color(241, 226, 9));
        btnDeleteIP.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/delete.png"))); // NOI18N
        btnDeleteIP.setToolTipText("Eliminar Factura");
        btnDeleteIP.setBorderPainted(false);
        btnDeleteIP.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnDeleteIP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteIPActionPerformed(evt);
            }
        });
        pnl_IPrestamo.add(btnDeleteIP, new org.netbeans.lib.awtextra.AbsoluteConstraints(1140, 360, 60, 50));

        jTabbedPane1.addTab("1", pnl_IPrestamo);

        pnl_IPrestamoDemanda.setBackground(new java.awt.Color(255, 255, 255));
        pnl_IPrestamoDemanda.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel18.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel18.setText("Num de Cuenta:");
        pnl_IPrestamoDemanda.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 90, -1, -1));

        jLabel49.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel49.setText("Moneda:");
        pnl_IPrestamoDemanda.add(jLabel49, new org.netbeans.lib.awtextra.AbsoluteConstraints(1150, 90, 70, 30));

        jLabel54.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel54.setForeground(new java.awt.Color(51, 51, 51));
        jLabel54.setText("Nombre Completo:");
        pnl_IPrestamoDemanda.add(jLabel54, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 135, 140, 20));

        txtNumCuentaIPD.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtNumCuentaIPD.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        txtNumCuentaIPD.setBorder(null);
        txtNumCuentaIPD.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtNumCuentaIPDKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtNumCuentaIPDKeyTyped(evt);
            }
        });
        pnl_IPrestamoDemanda.add(txtNumCuentaIPD, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 80, 400, 30));

        txtNombreIPD.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtNombreIPD.setBorder(null);
        pnl_IPrestamoDemanda.add(txtNombreIPD, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 130, 860, 30));

        btnEliminarIPD.setBackground(new java.awt.Color(241, 226, 9));
        btnEliminarIPD.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/new.png"))); // NOI18N
        btnEliminarIPD.setToolTipText("Nueva Factura");
        btnEliminarIPD.setBorderPainted(false);
        btnEliminarIPD.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnEliminarIPD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarIPDActionPerformed(evt);
            }
        });
        pnl_IPrestamoDemanda.add(btnEliminarIPD, new org.netbeans.lib.awtextra.AbsoluteConstraints(1280, 360, 60, 50));

        btnGuardarIPD.setBackground(new java.awt.Color(241, 226, 9));
        btnGuardarIPD.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/print.png"))); // NOI18N
        btnGuardarIPD.setToolTipText("Guardar e Imprimir");
        btnGuardarIPD.setBorderPainted(false);
        btnGuardarIPD.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnGuardarIPD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarIPDActionPerformed(evt);
            }
        });
        pnl_IPrestamoDemanda.add(btnGuardarIPD, new org.netbeans.lib.awtextra.AbsoluteConstraints(1210, 360, 60, 50));

        dateFechaIPD.setBackground(new java.awt.Color(204, 204, 204));
        dateFechaIPD.setDateFormatString("dd/MM/yyyy");
        dateFechaIPD.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        pnl_IPrestamoDemanda.add(dateFechaIPD, new org.netbeans.lib.awtextra.AbsoluteConstraints(1160, 140, 180, 30));

        jLabel56.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel56.setText("Fecha de Pago:");
        pnl_IPrestamoDemanda.add(jLabel56, new org.netbeans.lib.awtextra.AbsoluteConstraints(1050, 137, -1, 30));

        jPanel55.setBackground(new java.awt.Color(4, 154, 85));

        javax.swing.GroupLayout jPanel55Layout = new javax.swing.GroupLayout(jPanel55);
        jPanel55.setLayout(jPanel55Layout);
        jPanel55Layout.setHorizontalGroup(
            jPanel55Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel55Layout.setVerticalGroup(
            jPanel55Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        pnl_IPrestamoDemanda.add(jPanel55, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 110, 410, 2));

        jPanel56.setBackground(new java.awt.Color(4, 154, 85));

        javax.swing.GroupLayout jPanel56Layout = new javax.swing.GroupLayout(jPanel56);
        jPanel56.setLayout(jPanel56Layout);
        jPanel56Layout.setHorizontalGroup(
            jPanel56Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel56Layout.setVerticalGroup(
            jPanel56Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        pnl_IPrestamoDemanda.add(jPanel56, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 160, 860, 2));

        IPrestamoD.add(ChkLIPD);
        ChkLIPD.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        ChkLIPD.setText("L.  ");
        ChkLIPD.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ChkLIPD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ChkLIPDActionPerformed(evt);
            }
        });
        pnl_IPrestamoDemanda.add(ChkLIPD, new org.netbeans.lib.awtextra.AbsoluteConstraints(1220, 90, 50, -1));

        IPrestamoD.add(Chk$IPD);
        Chk$IPD.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        Chk$IPD.setText("$   ");
        Chk$IPD.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Chk$IPD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Chk$IPDActionPerformed(evt);
            }
        });
        pnl_IPrestamoDemanda.add(Chk$IPD, new org.netbeans.lib.awtextra.AbsoluteConstraints(1285, 90, 50, -1));

        TableCuentaIPD.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "CUENTA", "DESCRIPCIÓN", "VALORES", "Title 4"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, true, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        TableCuentaIPD.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        TableCuentaIPD.setSelectionBackground(new java.awt.Color(241, 226, 9));
        TableCuentaIPD.setSelectionForeground(new java.awt.Color(0, 0, 0));
        TableCuentaIPD.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TableCuentaIPDMouseClicked(evt);
            }
        });
        jScrollPane10.setViewportView(TableCuentaIPD);

        pnl_IPrestamoDemanda.add(jScrollPane10, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 230, 1330, 120));

        jLabel57.setFont(new java.awt.Font("Yu Gothic Light", 3, 24)); // NOI18N
        jLabel57.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel57.setText("COMPROBANTE DE INGRESOS DE PRESTAMOS EN DEMANDA");
        pnl_IPrestamoDemanda.add(jLabel57, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 20, 1350, 60));

        jLabel19.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel19.setText("No. de Préstamo:");
        pnl_IPrestamoDemanda.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 90, -1, -1));

        jPanel58.setBackground(new java.awt.Color(4, 154, 85));

        javax.swing.GroupLayout jPanel58Layout = new javax.swing.GroupLayout(jPanel58);
        jPanel58.setLayout(jPanel58Layout);
        jPanel58Layout.setHorizontalGroup(
            jPanel58Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel58Layout.setVerticalGroup(
            jPanel58Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        pnl_IPrestamoDemanda.add(jPanel58, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 110, 190, 2));

        txtNPrestamoIPD.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtNPrestamoIPD.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        txtNPrestamoIPD.setBorder(null);
        txtNPrestamoIPD.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtNPrestamoIPDKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtNPrestamoIPDKeyTyped(evt);
            }
        });
        pnl_IPrestamoDemanda.add(txtNPrestamoIPD, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 80, 190, 30));

        jPanel59.setBackground(new java.awt.Color(4, 154, 85));

        javax.swing.GroupLayout jPanel59Layout = new javax.swing.GroupLayout(jPanel59);
        jPanel59.setLayout(jPanel59Layout);
        jPanel59Layout.setHorizontalGroup(
            jPanel59Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel59Layout.setVerticalGroup(
            jPanel59Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        pnl_IPrestamoDemanda.add(jPanel59, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 110, 170, 2));

        txtCicloIPD.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtCicloIPD.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        txtCicloIPD.setBorder(null);
        txtCicloIPD.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtCicloIPDKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtCicloIPDKeyTyped(evt);
            }
        });
        pnl_IPrestamoDemanda.add(txtCicloIPD, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 80, 170, 30));

        jLabel20.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel20.setText("Ciclo:");
        pnl_IPrestamoDemanda.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 90, -1, -1));

        jLabel58.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel58.setText("Fecha de Entrega:");
        pnl_IPrestamoDemanda.add(jLabel58, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 200, -1, -1));

        dateFechaEntregaIPD.setBackground(new java.awt.Color(204, 204, 204));
        dateFechaEntregaIPD.setDateFormatString("dd/MM/yyyy");
        dateFechaEntregaIPD.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        pnl_IPrestamoDemanda.add(dateFechaEntregaIPD, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 190, 240, 30));

        jLabel59.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel59.setText("Fecha de Finalización:");
        pnl_IPrestamoDemanda.add(jLabel59, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 190, 160, 30));

        dateFechaIFinslIPD.setBackground(new java.awt.Color(204, 204, 204));
        dateFechaIFinslIPD.setDateFormatString("dd/MM/yyyy");
        dateFechaIFinslIPD.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        pnl_IPrestamoDemanda.add(dateFechaIFinslIPD, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 190, 220, 30));

        jPanel62.setBackground(new java.awt.Color(4, 154, 85));

        javax.swing.GroupLayout jPanel62Layout = new javax.swing.GroupLayout(jPanel62);
        jPanel62.setLayout(jPanel62Layout);
        jPanel62Layout.setHorizontalGroup(
            jPanel62Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 180, Short.MAX_VALUE)
        );
        jPanel62Layout.setVerticalGroup(
            jPanel62Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        pnl_IPrestamoDemanda.add(jPanel62, new org.netbeans.lib.awtextra.AbsoluteConstraints(900, 220, 180, 2));

        txtPlazoIPD.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        txtPlazoIPD.setBorder(null);
        txtPlazoIPD.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtPlazoIPDKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtPlazoIPDKeyTyped(evt);
            }
        });
        pnl_IPrestamoDemanda.add(txtPlazoIPD, new org.netbeans.lib.awtextra.AbsoluteConstraints(900, 190, 170, 30));

        jLabel61.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel61.setText("Plazo:");
        pnl_IPrestamoDemanda.add(jLabel61, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 190, 50, 30));

        jPanel63.setBackground(new java.awt.Color(4, 154, 85));

        javax.swing.GroupLayout jPanel63Layout = new javax.swing.GroupLayout(jPanel63);
        jPanel63.setLayout(jPanel63Layout);
        jPanel63Layout.setHorizontalGroup(
            jPanel63Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel63Layout.setVerticalGroup(
            jPanel63Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        pnl_IPrestamoDemanda.add(jPanel63, new org.netbeans.lib.awtextra.AbsoluteConstraints(1170, 220, 170, 2));

        txtTasaIPD.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtTasaIPD.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        txtTasaIPD.setBorder(null);
        txtTasaIPD.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtTasaIPDKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtTasaIPDKeyTyped(evt);
            }
        });
        pnl_IPrestamoDemanda.add(txtTasaIPD, new org.netbeans.lib.awtextra.AbsoluteConstraints(1170, 190, 160, 30));

        jLabel62.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel62.setText("Tasa:");
        pnl_IPrestamoDemanda.add(jLabel62, new org.netbeans.lib.awtextra.AbsoluteConstraints(1120, 200, -1, -1));

        jPanel67.setBackground(new java.awt.Color(4, 154, 85));

        javax.swing.GroupLayout jPanel67Layout = new javax.swing.GroupLayout(jPanel67);
        jPanel67.setLayout(jPanel67Layout);
        jPanel67Layout.setHorizontalGroup(
            jPanel67Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel67Layout.setVerticalGroup(
            jPanel67Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        pnl_IPrestamoDemanda.add(jPanel67, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 380, 110, -1));

        jPanel53.setBackground(new java.awt.Color(4, 154, 85));

        javax.swing.GroupLayout jPanel53Layout = new javax.swing.GroupLayout(jPanel53);
        jPanel53.setLayout(jPanel53Layout);
        jPanel53Layout.setHorizontalGroup(
            jPanel53Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 680, Short.MAX_VALUE)
        );
        jPanel53Layout.setVerticalGroup(
            jPanel53Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 2, Short.MAX_VALUE)
        );

        pnl_IPrestamoDemanda.add(jPanel53, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 510, 680, 2));

        jLabel74.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jLabel74.setText("Observaciones:");
        pnl_IPrestamoDemanda.add(jLabel74, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 490, 130, -1));

        txtObservaIPD.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtObservaIPD.setBorder(null);
        txtObservaIPD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtObservaIPDActionPerformed(evt);
            }
        });
        txtObservaIPD.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtObservaIPDKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtObservaIPDKeyTyped(evt);
            }
        });
        pnl_IPrestamoDemanda.add(txtObservaIPD, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 480, 680, 30));

        jPanel70.setBackground(new java.awt.Color(4, 154, 85));

        javax.swing.GroupLayout jPanel70Layout = new javax.swing.GroupLayout(jPanel70);
        jPanel70.setLayout(jPanel70Layout);
        jPanel70Layout.setHorizontalGroup(
            jPanel70Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 160, Short.MAX_VALUE)
        );
        jPanel70Layout.setVerticalGroup(
            jPanel70Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 2, Short.MAX_VALUE)
        );

        pnl_IPrestamoDemanda.add(jPanel70, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 460, 160, -1));

        txtintereseAcumuIPD.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        txtintereseAcumuIPD.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        txtintereseAcumuIPD.setBorder(null);
        txtintereseAcumuIPD.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtintereseAcumuIPDKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtintereseAcumuIPDKeyTyped(evt);
            }
        });
        pnl_IPrestamoDemanda.add(txtintereseAcumuIPD, new org.netbeans.lib.awtextra.AbsoluteConstraints(692, 430, 150, 30));

        jPanel71.setBackground(new java.awt.Color(4, 154, 85));

        javax.swing.GroupLayout jPanel71Layout = new javax.swing.GroupLayout(jPanel71);
        jPanel71.setLayout(jPanel71Layout);
        jPanel71Layout.setHorizontalGroup(
            jPanel71Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 160, Short.MAX_VALUE)
        );
        jPanel71Layout.setVerticalGroup(
            jPanel71Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 2, Short.MAX_VALUE)
        );

        pnl_IPrestamoDemanda.add(jPanel71, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 420, 160, -1));

        txtsaldoActualIPD.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        txtsaldoActualIPD.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        txtsaldoActualIPD.setBorder(null);
        txtsaldoActualIPD.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtsaldoActualIPDKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtsaldoActualIPDKeyTyped(evt);
            }
        });
        pnl_IPrestamoDemanda.add(txtsaldoActualIPD, new org.netbeans.lib.awtextra.AbsoluteConstraints(692, 390, 150, 30));

        jPanel72.setBackground(new java.awt.Color(4, 154, 85));

        javax.swing.GroupLayout jPanel72Layout = new javax.swing.GroupLayout(jPanel72);
        jPanel72.setLayout(jPanel72Layout);
        jPanel72Layout.setHorizontalGroup(
            jPanel72Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 160, Short.MAX_VALUE)
        );
        jPanel72Layout.setVerticalGroup(
            jPanel72Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 2, Short.MAX_VALUE)
        );

        pnl_IPrestamoDemanda.add(jPanel72, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 380, 160, -1));

        LabelTotalIPD.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        LabelTotalIPD.setText("0.00");
        pnl_IPrestamoDemanda.add(LabelTotalIPD, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 350, 160, 30));

        jLabel75.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel75.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel75.setText("Total:");
        jLabel75.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        pnl_IPrestamoDemanda.add(jLabel75, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 360, 90, -1));

        jLabel76.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel76.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel76.setText("Saldo Vencido de Préstamo:");
        pnl_IPrestamoDemanda.add(jLabel76, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 400, 270, -1));

        jLabel77.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel77.setText("Intereses Acumulados:");
        pnl_IPrestamoDemanda.add(jLabel77, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 440, -1, -1));

        jPanel36.setBackground(new java.awt.Color(4, 154, 85));

        javax.swing.GroupLayout jPanel36Layout = new javax.swing.GroupLayout(jPanel36);
        jPanel36.setLayout(jPanel36Layout);
        jPanel36Layout.setHorizontalGroup(
            jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 350, Short.MAX_VALUE)
        );
        jPanel36Layout.setVerticalGroup(
            jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 2, Short.MAX_VALUE)
        );

        pnl_IPrestamoDemanda.add(jPanel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(990, 510, 350, 2));

        txtTotalLetrasIPD.setBorder(null);
        txtTotalLetrasIPD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTotalLetrasIPDActionPerformed(evt);
            }
        });
        txtTotalLetrasIPD.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtTotalLetrasIPDKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtTotalLetrasIPDKeyTyped(evt);
            }
        });
        pnl_IPrestamoDemanda.add(txtTotalLetrasIPD, new org.netbeans.lib.awtextra.AbsoluteConstraints(990, 480, 350, 30));

        jLabel78.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jLabel78.setText("Total en Letras:");
        pnl_IPrestamoDemanda.add(jLabel78, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 490, 130, -1));

        txtIdIPD.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtIdIPD.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        txtIdIPD.setBorder(null);
        txtIdIPD.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtIdIPDKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtIdIPDKeyTyped(evt);
            }
        });
        pnl_IPrestamoDemanda.add(txtIdIPD, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 60, 60, 30));

        btnEditarIPD.setBackground(new java.awt.Color(241, 226, 9));
        btnEditarIPD.setForeground(new java.awt.Color(255, 255, 255));
        btnEditarIPD.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/update.png"))); // NOI18N
        btnEditarIPD.setToolTipText("Actualizar Factura");
        btnEditarIPD.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(102, 204, 255), java.awt.Color.red));
        btnEditarIPD.setBorderPainted(false);
        btnEditarIPD.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnEditarIPD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarIPDActionPerformed(evt);
            }
        });
        pnl_IPrestamoDemanda.add(btnEditarIPD, new org.netbeans.lib.awtextra.AbsoluteConstraints(1070, 360, 60, 50));

        btnDeleteIPD.setBackground(new java.awt.Color(241, 226, 9));
        btnDeleteIPD.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/delete.png"))); // NOI18N
        btnDeleteIPD.setToolTipText("Eliminar Factura");
        btnDeleteIPD.setBorderPainted(false);
        btnDeleteIPD.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnDeleteIPD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteIPDActionPerformed(evt);
            }
        });
        pnl_IPrestamoDemanda.add(btnDeleteIPD, new org.netbeans.lib.awtextra.AbsoluteConstraints(1140, 360, 60, 50));

        jTabbedPane1.addTab("1", pnl_IPrestamoDemanda);

        pnl_EAhorro.setBackground(new java.awt.Color(255, 255, 255));
        pnl_EAhorro.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel55.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel55.setText("Número de Cuenta:");
        pnl_EAhorro.add(jLabel55, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, -1, -1));

        jLabel63.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel63.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel63.setText("Tipo de Cuenta:");
        pnl_EAhorro.add(jLabel63, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 110, -1, 30));

        jLabel64.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel64.setForeground(new java.awt.Color(51, 51, 51));
        jLabel64.setText("Nombre Completo:");
        pnl_EAhorro.add(jLabel64, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 170, -1, -1));

        txtNumCuentaEA.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtNumCuentaEA.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        txtNumCuentaEA.setBorder(null);
        txtNumCuentaEA.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtNumCuentaEAKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtNumCuentaEAKeyTyped(evt);
            }
        });
        pnl_EAhorro.add(txtNumCuentaEA, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 110, 490, 30));

        txtNombreEA.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtNombreEA.setBorder(null);
        pnl_EAhorro.add(txtNombreEA, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 160, 740, 30));

        btnEliminarventa1.setBackground(new java.awt.Color(241, 226, 9));
        btnEliminarventa1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/new.png"))); // NOI18N
        btnEliminarventa1.setToolTipText("Nueva Factura");
        btnEliminarventa1.setBorderPainted(false);
        btnEliminarventa1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnEliminarventa1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarventa1ActionPerformed(evt);
            }
        });
        pnl_EAhorro.add(btnEliminarventa1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1280, 400, 60, 50));

        jLabel65.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jLabel65.setText("Total en Letras:");
        pnl_EAhorro.add(jLabel65, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 450, -1, -1));

        txtTotalLetrasEA.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtTotalLetrasEA.setBorder(null);
        txtTotalLetrasEA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTotalLetrasEAActionPerformed(evt);
            }
        });
        txtTotalLetrasEA.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtTotalLetrasEAKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtTotalLetrasEAKeyTyped(evt);
            }
        });
        pnl_EAhorro.add(txtTotalLetrasEA, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 440, 870, 30));

        btnGuardarEA.setBackground(new java.awt.Color(241, 226, 9));
        btnGuardarEA.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/print.png"))); // NOI18N
        btnGuardarEA.setToolTipText("Guaradar e Imprimir");
        btnGuardarEA.setBorderPainted(false);
        btnGuardarEA.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnGuardarEA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarEAActionPerformed(evt);
            }
        });
        pnl_EAhorro.add(btnGuardarEA, new org.netbeans.lib.awtextra.AbsoluteConstraints(1210, 400, 60, 50));

        jLabel79.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel79.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel79.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/money.png"))); // NOI18N
        jLabel79.setText("Total:");
        pnl_EAhorro.add(jLabel79, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 400, 90, 40));

        LabelTotalEA.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        LabelTotalEA.setText("0.00");
        pnl_EAhorro.add(LabelTotalEA, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 400, 330, 40));

        dateFechaEA.setBackground(new java.awt.Color(204, 204, 204));
        dateFechaEA.setDateFormatString("dd/MM/yyyy");
        dateFechaEA.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        pnl_EAhorro.add(dateFechaEA, new org.netbeans.lib.awtextra.AbsoluteConstraints(1080, 160, 230, 30));

        jLabel80.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel80.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel80.setText("Fecha de Pago:");
        pnl_EAhorro.add(jLabel80, new org.netbeans.lib.awtextra.AbsoluteConstraints(950, 170, 120, -1));

        jPanel37.setBackground(new java.awt.Color(4, 154, 85));

        javax.swing.GroupLayout jPanel37Layout = new javax.swing.GroupLayout(jPanel37);
        jPanel37.setLayout(jPanel37Layout);
        jPanel37Layout.setHorizontalGroup(
            jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 500, Short.MAX_VALUE)
        );
        jPanel37Layout.setVerticalGroup(
            jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 2, Short.MAX_VALUE)
        );

        pnl_EAhorro.add(jPanel37, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 140, 500, -1));

        jPanel38.setBackground(new java.awt.Color(4, 154, 85));

        javax.swing.GroupLayout jPanel38Layout = new javax.swing.GroupLayout(jPanel38);
        jPanel38.setLayout(jPanel38Layout);
        jPanel38Layout.setHorizontalGroup(
            jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 740, Short.MAX_VALUE)
        );
        jPanel38Layout.setVerticalGroup(
            jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 2, Short.MAX_VALUE)
        );

        pnl_EAhorro.add(jPanel38, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 190, 740, 2));

        jPanel46.setBackground(new java.awt.Color(4, 154, 85));

        javax.swing.GroupLayout jPanel46Layout = new javax.swing.GroupLayout(jPanel46);
        jPanel46.setLayout(jPanel46Layout);
        jPanel46Layout.setHorizontalGroup(
            jPanel46Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 870, Short.MAX_VALUE)
        );
        jPanel46Layout.setVerticalGroup(
            jPanel46Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 2, Short.MAX_VALUE)
        );

        pnl_EAhorro.add(jPanel46, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 470, 870, 2));

        GreoupChkEA.add(EAchkNCtaAE);
        EAchkNCtaAE.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        EAchkNCtaAE.setText("A.E.");
        EAchkNCtaAE.setToolTipText("Aportaciones Extraordinaria");
        EAchkNCtaAE.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        EAchkNCtaAE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EAchkNCtaAEActionPerformed(evt);
            }
        });
        pnl_EAhorro.add(EAchkNCtaAE, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 110, 80, -1));

        GreoupChkEA.add(EAchkNCtaAPF);
        EAchkNCtaAPF.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        EAchkNCtaAPF.setText("A.P.F.");
        EAchkNCtaAPF.setToolTipText("Ahorro a Plazo Fijo");
        EAchkNCtaAPF.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        EAchkNCtaAPF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EAchkNCtaAPFActionPerformed(evt);
            }
        });
        pnl_EAhorro.add(EAchkNCtaAPF, new org.netbeans.lib.awtextra.AbsoluteConstraints(1150, 110, 80, -1));

        GreoupChkEA.add(EAchkNCtaAR);
        EAchkNCtaAR.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        EAchkNCtaAR.setText("A.R.");
        EAchkNCtaAR.setToolTipText("Ahorro Retirable");
        EAchkNCtaAR.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        EAchkNCtaAR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EAchkNCtaARActionPerformed(evt);
            }
        });
        pnl_EAhorro.add(EAchkNCtaAR, new org.netbeans.lib.awtextra.AbsoluteConstraints(1240, 110, 70, -1));

        GreoupChkEA.add(EAchkNCtaAM);
        EAchkNCtaAM.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        EAchkNCtaAM.setText("A.M.");
        EAchkNCtaAM.setToolTipText("Ahorro de Menores");
        EAchkNCtaAM.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        EAchkNCtaAM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EAchkNCtaAMActionPerformed(evt);
            }
        });
        pnl_EAhorro.add(EAchkNCtaAM, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 110, 80, -1));

        TableCuentaEA.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "CUENTA", "DESCRIPCIÓN", "VALORES", "Title 4"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, true, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        TableCuentaEA.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        TableCuentaEA.setSelectionBackground(new java.awt.Color(241, 226, 9));
        TableCuentaEA.setSelectionForeground(new java.awt.Color(0, 0, 0));
        TableCuentaEA.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TableCuentaEAMouseClicked(evt);
            }
        });
        jScrollPane12.setViewportView(TableCuentaEA);

        pnl_EAhorro.add(jScrollPane12, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 210, 1320, 180));

        jLabel81.setFont(new java.awt.Font("Yu Gothic Light", 3, 24)); // NOI18N
        jLabel81.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel81.setText("COMPROBANTE DE EGRESOS DE AHORRO");
        pnl_EAhorro.add(jLabel81, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 30, 1350, 70));

        GreoupChkEA.add(EAchkNCtaAN);
        EAchkNCtaAN.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        EAchkNCtaAN.setText("A.N.");
        EAchkNCtaAN.setToolTipText("Ahorro Navideño");
        EAchkNCtaAN.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        EAchkNCtaAN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EAchkNCtaANActionPerformed(evt);
            }
        });
        pnl_EAhorro.add(EAchkNCtaAN, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 110, 80, 30));

        jPanel54.setBackground(new java.awt.Color(4, 154, 85));

        javax.swing.GroupLayout jPanel54Layout = new javax.swing.GroupLayout(jPanel54);
        jPanel54.setLayout(jPanel54Layout);
        jPanel54Layout.setHorizontalGroup(
            jPanel54Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1010, Short.MAX_VALUE)
        );
        jPanel54Layout.setVerticalGroup(
            jPanel54Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 2, Short.MAX_VALUE)
        );

        pnl_EAhorro.add(jPanel54, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 530, 1010, 2));

        txtObservaEA.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtObservaEA.setBorder(null);
        txtObservaEA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtObservaEAActionPerformed(evt);
            }
        });
        txtObservaEA.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtObservaEAKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtObservaEAKeyTyped(evt);
            }
        });
        pnl_EAhorro.add(txtObservaEA, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 500, 1010, 30));

        jLabel82.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jLabel82.setText("Observaciones:");
        pnl_EAhorro.add(jLabel82, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 510, 130, -1));

        GreoupChkEA.add(EAchkNCtaAO);
        EAchkNCtaAO.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        EAchkNCtaAO.setText("A.O.");
        EAchkNCtaAO.setToolTipText("Aportaciones Obligatorias");
        EAchkNCtaAO.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        EAchkNCtaAO.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EAchkNCtaAOActionPerformed(evt);
            }
        });
        pnl_EAhorro.add(EAchkNCtaAO, new org.netbeans.lib.awtextra.AbsoluteConstraints(1060, 110, 80, -1));

        txtIdEA.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtIdEA.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        txtIdEA.setBorder(null);
        txtIdEA.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtIdEAKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtIdEAKeyTyped(evt);
            }
        });
        pnl_EAhorro.add(txtIdEA, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 60, 60, 30));

        btnEditarEA.setBackground(new java.awt.Color(241, 226, 9));
        btnEditarEA.setForeground(new java.awt.Color(255, 255, 255));
        btnEditarEA.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/update.png"))); // NOI18N
        btnEditarEA.setToolTipText("Actualizar Factura");
        btnEditarEA.setBorderPainted(false);
        btnEditarEA.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnEditarEA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarEAActionPerformed(evt);
            }
        });
        pnl_EAhorro.add(btnEditarEA, new org.netbeans.lib.awtextra.AbsoluteConstraints(1070, 400, 60, 50));

        btnEliminarEA.setBackground(new java.awt.Color(241, 226, 9));
        btnEliminarEA.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/delete.png"))); // NOI18N
        btnEliminarEA.setToolTipText("Eliminar Factura");
        btnEliminarEA.setBorderPainted(false);
        btnEliminarEA.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnEliminarEA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarEAActionPerformed(evt);
            }
        });
        pnl_EAhorro.add(btnEliminarEA, new org.netbeans.lib.awtextra.AbsoluteConstraints(1140, 400, 60, 50));

        jTabbedPane1.addTab("1", pnl_EAhorro);

        pnl_cuentas.setBackground(new java.awt.Color(255, 255, 255));
        pnl_cuentas.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel11.setBackground(new java.awt.Color(255, 255, 255));
        jPanel11.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel22.setFont(new java.awt.Font("Tahoma", 3, 12)); // NOI18N
        jLabel22.setText("Cuenta:");
        jPanel11.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 180, 90, -1));

        txtNumCta.setBorder(null);
        txtNumCta.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtNumCtaKeyTyped(evt);
            }
        });
        jPanel11.add(txtNumCta, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 160, 300, 30));

        jLabel23.setFont(new java.awt.Font("Tahoma", 3, 12)); // NOI18N
        jLabel23.setText("Descripción:");
        jPanel11.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 250, 90, -1));

        txtDescripcion.setBorder(null);
        jPanel11.add(txtDescripcion, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 230, 300, 30));

        jLabel26.setFont(new java.awt.Font("Tahoma", 3, 12)); // NOI18N
        jLabel26.setText("Comprobante:");
        jPanel11.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, 100, -1));

        cbxComprobante.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ingresos de Ahorro", "Ingresos Diversos", "Ingresos de Prestamos", "Ingresos de Prestamos en Demanda", "Egresos de Ahorro", " " }));
        cbxComprobante.setSelectedIndex(-1);
        cbxComprobante.setBorder(null);
        cbxComprobante.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbxComprobanteItemStateChanged(evt);
            }
        });
        cbxComprobante.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbxComprobanteActionPerformed(evt);
            }
        });
        jPanel11.add(cbxComprobante, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 80, 300, 30));

        btnGuardarCta.setBackground(new java.awt.Color(241, 226, 9));
        btnGuardarCta.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/GuardarTodo.png"))); // NOI18N
        btnGuardarCta.setToolTipText("Guardar");
        btnGuardarCta.setBorderPainted(false);
        btnGuardarCta.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnGuardarCta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarCtaActionPerformed(evt);
            }
        });
        jPanel11.add(btnGuardarCta, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 370, 70, 40));

        btnEditarCta.setBackground(new java.awt.Color(241, 226, 9));
        btnEditarCta.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/update.png"))); // NOI18N
        btnEditarCta.setToolTipText("Actualizar");
        btnEditarCta.setBorderPainted(false);
        btnEditarCta.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnEditarCta.setEnabled(false);
        btnEditarCta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarCtaActionPerformed(evt);
            }
        });
        jPanel11.add(btnEditarCta, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 370, 70, 40));

        btnEliminarCta.setBackground(new java.awt.Color(241, 226, 9));
        btnEliminarCta.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/delete.png"))); // NOI18N
        btnEliminarCta.setToolTipText("Eliminar");
        btnEliminarCta.setBorderPainted(false);
        btnEliminarCta.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnEliminarCta.setEnabled(false);
        btnEliminarCta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarCtaActionPerformed(evt);
            }
        });
        jPanel11.add(btnEliminarCta, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 370, 70, 40));

        btnNuevoCta.setBackground(new java.awt.Color(241, 226, 9));
        btnNuevoCta.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/new.png"))); // NOI18N
        btnNuevoCta.setToolTipText("Nueva Cuenta");
        btnNuevoCta.setBorderPainted(false);
        btnNuevoCta.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnNuevoCta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoCtaActionPerformed(evt);
            }
        });
        jPanel11.add(btnNuevoCta, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 370, 70, 40));

        jPanel30.setBackground(new java.awt.Color(4, 154, 85));

        javax.swing.GroupLayout jPanel30Layout = new javax.swing.GroupLayout(jPanel30);
        jPanel30.setLayout(jPanel30Layout);
        jPanel30Layout.setHorizontalGroup(
            jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );
        jPanel30Layout.setVerticalGroup(
            jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 2, Short.MAX_VALUE)
        );

        jPanel11.add(jPanel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 190, 300, 2));

        jPanel31.setBackground(new java.awt.Color(4, 154, 85));

        javax.swing.GroupLayout jPanel31Layout = new javax.swing.GroupLayout(jPanel31);
        jPanel31.setLayout(jPanel31Layout);
        jPanel31Layout.setHorizontalGroup(
            jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );
        jPanel31Layout.setVerticalGroup(
            jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 2, Short.MAX_VALUE)
        );

        jPanel11.add(jPanel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 260, 300, 2));

        jPanel39.setBackground(new java.awt.Color(4, 154, 85));

        jLabel40.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel40.setForeground(new java.awt.Color(255, 255, 255));
        jLabel40.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel40.setText("Nueva Cuenta");

        javax.swing.GroupLayout jPanel39Layout = new javax.swing.GroupLayout(jPanel39);
        jPanel39.setLayout(jPanel39Layout);
        jPanel39Layout.setHorizontalGroup(
            jPanel39Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel40, javax.swing.GroupLayout.DEFAULT_SIZE, 410, Short.MAX_VALUE)
        );
        jPanel39Layout.setVerticalGroup(
            jPanel39Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel39Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel40, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel11.add(jPanel39, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 410, 50));

        jLabel42.setFont(new java.awt.Font("Tahoma", 3, 12)); // NOI18N
        jLabel42.setText("Moneda:");
        jPanel11.add(jLabel42, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 330, 100, -1));

        cbxMoneda.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Lps.", "$ ", "€ ", " " }));
        cbxMoneda.setSelectedIndex(-1);
        cbxMoneda.setBorder(null);
        cbxMoneda.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbxMonedaItemStateChanged(evt);
            }
        });
        cbxMoneda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbxMonedaActionPerformed(evt);
            }
        });
        jPanel11.add(cbxMoneda, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 320, 300, 30));

        pnl_cuentas.add(jPanel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, 410, 420));

        jPanel20.setBackground(new java.awt.Color(4, 154, 85));

        javax.swing.GroupLayout jPanel20Layout = new javax.swing.GroupLayout(jPanel20);
        jPanel20.setLayout(jPanel20Layout);
        jPanel20Layout.setHorizontalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jPanel20Layout.setVerticalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 2, Short.MAX_VALUE)
        );

        pnl_cuentas.add(jPanel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 90, 400, 2));

        txtBuscarCuenta.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtBuscarCuenta.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        txtBuscarCuenta.setBorder(null);
        txtBuscarCuenta.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtBuscarCuentaKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtBuscarCuentaKeyTyped(evt);
            }
        });
        pnl_cuentas.add(txtBuscarCuenta, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 60, 400, 30));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/busqueda-de-trabajo.png"))); // NOI18N
        jLabel5.setText("Buscar:");
        jLabel5.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jLabel5.setIconTextGap(7);
        pnl_cuentas.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 60, 110, -1));

        cbxBuscarCuenta.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        cbxBuscarCuenta.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ingresos de Ahorro", "Ingresos Diversos", "Ingresos de Prestamos", "Ingresos de Prestamos en Demanda", "Egresos de Ahorro", " " }));
        cbxBuscarCuenta.setSelectedIndex(-1);
        cbxBuscarCuenta.setBorder(null);
        cbxBuscarCuenta.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        cbxBuscarCuenta.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbxBuscarCuentaItemStateChanged(evt);
            }
        });
        cbxBuscarCuenta.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cbxBuscarCuentaMouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                cbxBuscarCuentaMousePressed(evt);
            }
        });
        cbxBuscarCuenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbxBuscarCuentaActionPerformed(evt);
            }
        });
        pnl_cuentas.add(cbxBuscarCuenta, new org.netbeans.lib.awtextra.AbsoluteConstraints(950, 60, 280, 30));

        TableCuenta.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "CUENTA", "DESCRIPCIÓN", "VALORES", "Title 4"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, true, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        TableCuenta.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        TableCuenta.setSelectionBackground(new java.awt.Color(241, 226, 9));
        TableCuenta.setSelectionForeground(new java.awt.Color(0, 0, 0));
        TableCuenta.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TableCuentaMouseClicked(evt);
            }
        });
        jScrollPane9.setViewportView(TableCuenta);

        pnl_cuentas.add(jScrollPane9, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 110, 910, 410));

        jTabbedPane1.addTab("4", pnl_cuentas);

        pnl_usuario.setBackground(new java.awt.Color(255, 255, 255));
        pnl_usuario.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel13.setBackground(new java.awt.Color(255, 255, 255));
        jPanel13.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel34.setFont(new java.awt.Font("Times New Roman", 3, 16)); // NOI18N
        jLabel34.setText("Correo Electrónico:");
        jPanel13.add(jLabel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 102, 290, -1));

        jLabel35.setFont(new java.awt.Font("Times New Roman", 3, 16)); // NOI18N
        jLabel35.setText("Password:");
        jPanel13.add(jLabel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 180, 240, -1));

        txtDominio.setEditable(false);
        txtDominio.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtDominio.setText("@lazosdeamistadhn.com ");
        txtDominio.setBorder(null);
        txtDominio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDominioActionPerformed(evt);
            }
        });
        txtDominio.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtDominioKeyTyped(evt);
            }
        });
        jPanel13.add(txtDominio, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 126, 160, 30));

        txtCorreo.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtCorreo.setBorder(null);
        txtCorreo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCorreoActionPerformed(evt);
            }
        });
        txtCorreo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtCorreoKeyTyped(evt);
            }
        });
        jPanel13.add(txtCorreo, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 126, 250, 30));

        txtPass.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtPass.setBorder(null);
        jPanel13.add(txtPass, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 200, 410, 30));

        jLabel36.setFont(new java.awt.Font("Times New Roman", 3, 16)); // NOI18N
        jLabel36.setText("Nombre:");
        jPanel13.add(jLabel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 260, 240, -1));

        txtNombre.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtNombre.setBorder(null);
        jPanel13.add(txtNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 280, 410, 30));

        jLabel37.setFont(new java.awt.Font("Times New Roman", 3, 16)); // NOI18N
        jLabel37.setText("Rol:");
        jPanel13.add(jLabel37, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 330, 210, -1));

        cbxRol.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        cbxRol.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Administrador", "Caja", "Gerencia" }));
        jPanel13.add(cbxRol, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 360, 410, 30));

        jPanel15.setBackground(new java.awt.Color(4, 154, 85));

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 410, Short.MAX_VALUE)
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 2, Short.MAX_VALUE)
        );

        jPanel13.add(jPanel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 156, 410, -1));

        jPanel16.setBackground(new java.awt.Color(4, 154, 85));

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 410, Short.MAX_VALUE)
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 2, Short.MAX_VALUE)
        );

        jPanel13.add(jPanel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 230, 410, 2));

        jPanel17.setBackground(new java.awt.Color(4, 154, 85));

        javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 410, Short.MAX_VALUE)
        );
        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 2, Short.MAX_VALUE)
        );

        jPanel13.add(jPanel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 310, 410, 2));

        jPanel18.setBackground(new java.awt.Color(4, 154, 85));

        jLabel39.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel39.setForeground(new java.awt.Color(255, 255, 255));
        jLabel39.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel39.setText("Nuevo Usuario");

        javax.swing.GroupLayout jPanel18Layout = new javax.swing.GroupLayout(jPanel18);
        jPanel18.setLayout(jPanel18Layout);
        jPanel18Layout.setHorizontalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel39, javax.swing.GroupLayout.DEFAULT_SIZE, 460, Short.MAX_VALUE)
        );
        jPanel18Layout.setVerticalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel18Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel39)
                .addContainerGap(17, Short.MAX_VALUE))
        );

        jPanel13.add(jPanel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 460, 60));

        btnGuardarUser.setBackground(new java.awt.Color(241, 226, 9));
        btnGuardarUser.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/GuardarTodo.png"))); // NOI18N
        btnGuardarUser.setToolTipText("Guardar");
        btnGuardarUser.setBorderPainted(false);
        btnGuardarUser.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnGuardarUser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarUserActionPerformed(evt);
            }
        });
        jPanel13.add(btnGuardarUser, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 410, 70, 40));

        btnNuevoUser.setBackground(new java.awt.Color(241, 226, 9));
        btnNuevoUser.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/new.png"))); // NOI18N
        btnNuevoUser.setToolTipText("Nueva Cuenta");
        btnNuevoUser.setBorderPainted(false);
        btnNuevoUser.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnNuevoUser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoUserActionPerformed(evt);
            }
        });
        jPanel13.add(btnNuevoUser, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 410, 70, 40));

        btnEliminarUser.setBackground(new java.awt.Color(241, 226, 9));
        btnEliminarUser.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/delete.png"))); // NOI18N
        btnEliminarUser.setToolTipText("Eliminar");
        btnEliminarUser.setBorderPainted(false);
        btnEliminarUser.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnEliminarUser.setEnabled(false);
        btnEliminarUser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarUserActionPerformed(evt);
            }
        });
        jPanel13.add(btnEliminarUser, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 410, 70, 40));

        btnEditarUser.setBackground(new java.awt.Color(241, 226, 9));
        btnEditarUser.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/update.png"))); // NOI18N
        btnEditarUser.setToolTipText("Actualizar");
        btnEditarUser.setBorderPainted(false);
        btnEditarUser.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnEditarUser.setEnabled(false);
        btnEditarUser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarUserActionPerformed(evt);
            }
        });
        jPanel13.add(btnEditarUser, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 410, 70, 40));

        pnl_usuario.add(jPanel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 40, 460, 470));

        TableUsuarios.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id", "Nombre", "Correo", "Rol"
            }
        ));
        TableUsuarios.setRowHeight(20);
        TableUsuarios.setSelectionBackground(new java.awt.Color(241, 226, 9));
        TableUsuarios.setSelectionForeground(new java.awt.Color(0, 0, 0));
        TableUsuarios.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TableUsuariosMouseClicked(evt);
            }
        });
        jScrollPane6.setViewportView(TableUsuarios);

        pnl_usuario.add(jScrollPane6, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 40, 840, 470));

        jTabbedPane1.addTab("7", pnl_usuario);

        pnl_historial.setBackground(new java.awt.Color(255, 255, 255));
        pnl_historial.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        cbxBuscarFactura.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        cbxBuscarFactura.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ingresos de Ahorro", "Ingresos Diversos", "Ingresos de Prestamos", "Ingresos de Prestamos en Demanda", "Egresos de Ahorro" }));
        cbxBuscarFactura.setBorder(null);
        cbxBuscarFactura.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        cbxBuscarFactura.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbxBuscarFacturaItemStateChanged(evt);
            }
        });
        cbxBuscarFactura.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cbxBuscarFacturaMouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                cbxBuscarFacturaMousePressed(evt);
            }
        });
        cbxBuscarFactura.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbxBuscarFacturaActionPerformed(evt);
            }
        });
        pnl_historial.add(cbxBuscarFactura, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 60, 350, 30));

        TableFacturas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "CUENTA", "DESCRIPCIÓN", "VALORES", "Title 4"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, true, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        TableFacturas.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        TableFacturas.setSelectionBackground(new java.awt.Color(241, 226, 9));
        TableFacturas.setSelectionForeground(new java.awt.Color(0, 0, 0));
        TableFacturas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TableFacturasMouseClicked(evt);
            }
        });
        jScrollPane5.setViewportView(TableFacturas);

        pnl_historial.add(jScrollPane5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, 1330, 410));

        jPanel21.setBackground(new java.awt.Color(4, 154, 85));

        javax.swing.GroupLayout jPanel21Layout = new javax.swing.GroupLayout(jPanel21);
        jPanel21.setLayout(jPanel21Layout);
        jPanel21Layout.setHorizontalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 640, Short.MAX_VALUE)
        );
        jPanel21Layout.setVerticalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 2, Short.MAX_VALUE)
        );

        pnl_historial.add(jPanel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 90, 640, 2));

        txtBuscarFacturas.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtBuscarFacturas.setBorder(null);
        txtBuscarFacturas.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtBuscarFacturasKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtBuscarFacturasKeyTyped(evt);
            }
        });
        pnl_historial.add(txtBuscarFacturas, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 60, 640, 30));

        jLabel12.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/busqueda-de-trabajo.png"))); // NOI18N
        jLabel12.setText("Buscar:");
        jLabel12.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jLabel12.setIconTextGap(7);
        pnl_historial.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 110, -1));

        jTabbedPane1.addTab("5", pnl_historial);

        pnl_empresa.setBackground(new java.awt.Color(255, 255, 255));
        pnl_empresa.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel32.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel32.setText("DATOS DE LA EMPRESA");
        pnl_empresa.add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 40, -1, -1));

        jPanel8.setBackground(new java.awt.Color(204, 204, 204));
        jPanel8.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel8.add(txtIdConfig, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 290, 24, -1));

        jLabel30.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        jLabel30.setText("Dirección");
        jPanel8.add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, -1, -1));

        jLabel29.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        jLabel29.setText("Teléfono");
        jPanel8.add(jLabel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 120, -1, -1));

        txtTelefonoConfig.setBackground(new java.awt.Color(204, 204, 204));
        txtTelefonoConfig.setBorder(null);
        jPanel8.add(txtTelefonoConfig, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 150, 218, 30));

        txtDireccionConfig.setBackground(new java.awt.Color(204, 204, 204));
        txtDireccionConfig.setBorder(null);
        jPanel8.add(txtDireccionConfig, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 150, 147, 30));

        jLabel31.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        jLabel31.setText("Mensaje");
        jPanel8.add(jLabel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 200, -1, -1));

        txtMensaje.setBackground(new java.awt.Color(204, 204, 204));
        txtMensaje.setBorder(null);
        jPanel8.add(txtMensaje, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 230, 400, 30));

        btnActualizarConfig.setBackground(new java.awt.Color(0, 110, 255));
        btnActualizarConfig.setFont(new java.awt.Font("Times New Roman", 1, 13)); // NOI18N
        btnActualizarConfig.setForeground(new java.awt.Color(255, 255, 255));
        btnActualizarConfig.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/update.png"))); // NOI18N
        btnActualizarConfig.setText("ACTUALIZAR");
        btnActualizarConfig.setBorder(null);
        btnActualizarConfig.setFocusable(false);
        btnActualizarConfig.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarConfigActionPerformed(evt);
            }
        });
        jPanel8.add(btnActualizarConfig, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 290, 180, 35));

        jLabel27.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        jLabel27.setText("Ruc");
        jPanel8.add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, -1, -1));

        txtRucConfig.setBackground(new java.awt.Color(204, 204, 204));
        txtRucConfig.setBorder(null);
        jPanel8.add(txtRucConfig, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 147, 30));

        jLabel28.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        jLabel28.setText("Nombre");
        jPanel8.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 30, -1, -1));

        txtNombreConfig.setBackground(new java.awt.Color(204, 204, 204));
        txtNombreConfig.setBorder(null);
        jPanel8.add(txtNombreConfig, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 60, 220, 30));

        jPanel41.setBackground(new java.awt.Color(0, 110, 255));

        javax.swing.GroupLayout jPanel41Layout = new javax.swing.GroupLayout(jPanel41);
        jPanel41.setLayout(jPanel41Layout);
        jPanel41Layout.setHorizontalGroup(
            jPanel41Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 147, Short.MAX_VALUE)
        );
        jPanel41Layout.setVerticalGroup(
            jPanel41Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 2, Short.MAX_VALUE)
        );

        jPanel8.add(jPanel41, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, 147, 2));

        jPanel42.setBackground(new java.awt.Color(0, 110, 255));

        javax.swing.GroupLayout jPanel42Layout = new javax.swing.GroupLayout(jPanel42);
        jPanel42.setLayout(jPanel42Layout);
        jPanel42Layout.setHorizontalGroup(
            jPanel42Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 147, Short.MAX_VALUE)
        );
        jPanel42Layout.setVerticalGroup(
            jPanel42Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 2, Short.MAX_VALUE)
        );

        jPanel8.add(jPanel42, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 180, 147, 2));

        jPanel43.setBackground(new java.awt.Color(0, 110, 255));

        javax.swing.GroupLayout jPanel43Layout = new javax.swing.GroupLayout(jPanel43);
        jPanel43.setLayout(jPanel43Layout);
        jPanel43Layout.setHorizontalGroup(
            jPanel43Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jPanel43Layout.setVerticalGroup(
            jPanel43Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 2, Short.MAX_VALUE)
        );

        jPanel8.add(jPanel43, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 260, 400, 2));

        jPanel44.setBackground(new java.awt.Color(0, 110, 255));

        javax.swing.GroupLayout jPanel44Layout = new javax.swing.GroupLayout(jPanel44);
        jPanel44.setLayout(jPanel44Layout);
        jPanel44Layout.setHorizontalGroup(
            jPanel44Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 220, Short.MAX_VALUE)
        );
        jPanel44Layout.setVerticalGroup(
            jPanel44Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 2, Short.MAX_VALUE)
        );

        jPanel8.add(jPanel44, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 90, 220, 2));

        jPanel45.setBackground(new java.awt.Color(0, 110, 255));

        javax.swing.GroupLayout jPanel45Layout = new javax.swing.GroupLayout(jPanel45);
        jPanel45.setLayout(jPanel45Layout);
        jPanel45Layout.setHorizontalGroup(
            jPanel45Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 220, Short.MAX_VALUE)
        );
        jPanel45Layout.setVerticalGroup(
            jPanel45Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 2, Short.MAX_VALUE)
        );

        jPanel8.add(jPanel45, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 180, 220, 2));

        pnl_empresa.add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, 420, 340));

        jLabel21.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/empresa.png"))); // NOI18N
        pnl_empresa.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 120, 410, 290));

        javax.swing.GroupLayout jPanel40Layout = new javax.swing.GroupLayout(jPanel40);
        jPanel40.setLayout(jPanel40Layout);
        jPanel40Layout.setHorizontalGroup(
            jPanel40Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel40Layout.setVerticalGroup(
            jPanel40Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );

        pnl_empresa.add(jPanel40, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, -1, 10));

        jTabbedPane1.addTab("6", pnl_empresa);

        pnl_IAhorro1.setBackground(new java.awt.Color(249, 255, 253));
        pnl_IAhorro1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel71.setBackground(new java.awt.Color(255, 255, 255));
        jLabel71.setForeground(new java.awt.Color(255, 255, 255));
        jLabel71.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel71.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/logo.jpg"))); // NOI18N
        pnl_IAhorro1.add(jLabel71, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 20, 790, 530));

        jTabbedPane1.addTab("1", pnl_IAhorro1);

        getContentPane().add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 95, 1360, 570));
        getContentPane().add(jProgressBar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 20, -1, -1));
        getContentPane().add(txtIdCta, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 130, 20, -1));
        getContentPane().add(txtIdUser, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 130, 20, -1));

        jMenuBar2.setBackground(new java.awt.Color(255, 255, 255));
        jMenuBar2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jMenuBar2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        mnusisreserva.setBackground(new java.awt.Color(238, 228, 21));
        mnusisreserva.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/home.png"))); // NOI18N
        mnusisreserva.setMnemonic('f');
        mnusisreserva.setText("Inicio");
        mnusisreserva.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mnusisreservaMouseClicked(evt);
            }
        });
        jMenuBar2.add(mnusisreserva);

        mnuarchivo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/recibo.png"))); // NOI18N
        mnuarchivo.setMnemonic('e');
        mnuarchivo.setText("Facturas");
        mnuarchivo.setToolTipText("");

        cutMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_A, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        cutMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/ahorro.png"))); // NOI18N
        cutMenuItem.setMnemonic('t');
        cutMenuItem.setText("Ingresos de Ahorros");
        cutMenuItem.setToolTipText("");
        cutMenuItem.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        cutMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cutMenuItemActionPerformed(evt);
            }
        });
        mnuarchivo.add(cutMenuItem);

        jMenuItem6.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_D, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        jMenuItem6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/ingresos.png"))); // NOI18N
        jMenuItem6.setText("Ingresos Diversos");
        jMenuItem6.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jMenuItem6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem6ActionPerformed(evt);
            }
        });
        mnuarchivo.add(jMenuItem6);

        jMenuItem7.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_E, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        jMenuItem7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/banca-en-linea.png"))); // NOI18N
        jMenuItem7.setText("Egresos de Ahorro");
        jMenuItem7.setToolTipText("");
        jMenuItem7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jMenuItem7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem7ActionPerformed(evt);
            }
        });
        mnuarchivo.add(jMenuItem7);

        copyMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_I, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        copyMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/socios.png"))); // NOI18N
        copyMenuItem.setMnemonic('y');
        copyMenuItem.setText("Ingresos de Prestamos");
        copyMenuItem.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        copyMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                copyMenuItemActionPerformed(evt);
            }
        });
        mnuarchivo.add(copyMenuItem);

        jMenuItem5.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_P, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        jMenuItem5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/transaccion.png"))); // NOI18N
        jMenuItem5.setText("Ingresos de Prestamos en Demanda");
        jMenuItem5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jMenuItem5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem5ActionPerformed(evt);
            }
        });
        mnuarchivo.add(jMenuItem5);

        jMenuBar2.add(mnuarchivo);

        mnuconsultas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/bill.png"))); // NOI18N
        mnuconsultas.setText("Cuentas");
        mnuconsultas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mnuconsultasMouseClicked(evt);
            }
        });
        jMenuBar2.add(mnuconsultas);

        mnuConsultas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/beneficio-bruto.png"))); // NOI18N
        mnuConsultas.setMnemonic('h');
        mnuConsultas.setText("Consultas");
        mnuConsultas.setToolTipText("");

        contentMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_R, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        contentMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/lista.png"))); // NOI18N
        contentMenuItem.setMnemonic('c');
        contentMenuItem.setText("Listado de Facturas");
        contentMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                contentMenuItemActionPerformed(evt);
            }
        });
        mnuConsultas.add(contentMenuItem);

        jMenuBar2.add(mnuConsultas);

        mnuconfiguraciones.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/settings.png"))); // NOI18N
        mnuconfiguraciones.setText("Configuraciones");

        jmUsuarios.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_U, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        jmUsuarios.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/teamwork.png"))); // NOI18N
        jmUsuarios.setText("Usuarios y Accesos");
        jmUsuarios.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jmUsuarios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmUsuariosActionPerformed(evt);
            }
        });
        mnuconfiguraciones.add(jmUsuarios);

        jMenuItem10.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_R, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        jMenuItem10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/data-transfer.png"))); // NOI18N
        jMenuItem10.setText("Respaldo BD");
        jMenuItem10.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jMenuItem10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem10ActionPerformed(evt);
            }
        });
        mnuconfiguraciones.add(jMenuItem10);

        jMenuItem1.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_H, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        jMenuItem1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/folder.png"))); // NOI18N
        jMenuItem1.setText("Historial de Facturas");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        mnuconfiguraciones.add(jMenuItem1);

        jMenuBar2.add(mnuconfiguraciones);

        mnuayuda.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/support.png"))); // NOI18N
        mnuayuda.setText("Ayuda");

        jMenuItem3.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_A, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        jMenuItem3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/informacion.png"))); // NOI18N
        jMenuItem3.setText("Acerca de...");
        mnuayuda.add(jMenuItem3);

        jMenuItem4.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_H, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        jMenuItem4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/auriculares.png"))); // NOI18N
        jMenuItem4.setText("Ayuda");
        jMenuItem4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem4ActionPerformed(evt);
            }
        });
        mnuayuda.add(jMenuItem4);

        jMenuBar2.add(mnuayuda);

        mnusalir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/logout.png"))); // NOI18N
        mnusalir.setText("Cerrar Sesión");
        mnusalir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mnusalirMouseClicked(evt);
            }
        });
        jMenuBar2.add(mnusalir);

        setJMenuBar(jMenuBar2);

        pack();
    }// </editor-fold>//GEN-END:initComponents
    public void limpiarDataCuentas() {
        this.cbxComprobante.setSelectedIndex(-1);
        this.txtNumCta.setText(null);
        this.txtDescripcion.setText(null);
        this.cbxMoneda.setSelectedItem(-1);
    }

    public Image IconImageReport() {
        Image retValue = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("Img/coop.png"));
        return retValue;
    }

    public String print_bill(String TipoFact) throws IOException {

        if (TipoFact == "1") {
            classFactIA Fact;// Instaciamos la clase 
            List<classFactIA> lista = new ArrayList<>(); //Creamos una lista de empleados con ArrayList para obtener cada empleado
            for (int i = 0; i < TableCuentaIA.getRowCount(); i++) { // Iterena cada fila de la tabla
                Fact = new classFactIA(TableCuentaIA.getValueAt(i, 0).toString(), TableCuentaIA.getValueAt(i, 1).toString(), //Tomamos de la tabla el valor de cada columna y creamos un objeto 
                        TableCuentaIA.getValueAt(i, 2).toString(), formatofecha.format(dateFechaIA.getDate()),
                        LabelTotalIA.getText(), MaxID_IA(), txtNombreIA.getText(), txtObservaIA.getText(), txtTotalLetrasIA.getText(),
                        SelectNOCtaIA(), txtNumCuentaIA.getText());
                lista.add(Fact); //Agregamos el objeto empleado a la lista
            }
            JasperReport reporte; // Instaciamos el objeto reporte
             String path = "src\\Facturas\\rpt_IgresosA.jasper"; //Ponemos la localizacion del reporte creado
            try {
                reporte = (JasperReport) JRLoader.loadObjectFromFile(path); //Se carga el reporte de su localizacion
                JasperPrint jprint = JasperFillManager.fillReport(reporte, null, new JRBeanCollectionDataSource(lista)); //Agregamos los parametros para llenar el reporte
                Date Ahora = new Date();
                File FileFact = new File("Facturas\\FacturaIA de "+txtNombreIA.getText()+"-"+ formatofechaBackUp.format(Ahora) + ".pdf");
                FileWriter fw = new FileWriter(FileFact);
                String rutaDestino = FileFact.toString();
                //Exporta el informe a PDF
                JasperExportManager.exportReportToPdfFile(jprint, rutaDestino);
                Desktop desktop = Desktop.getDesktop();
                if(FileFact.exists())
                desktop.open(FileFact);
               // viewer.setVisible(true); //Se vizualiza el reporte
            } catch (JRException ex) {
               JOptionPane.showMessageDialog(this, "el error es:"+ex, "INGRESOS DE AHORROS", JOptionPane.INFORMATION_MESSAGE);
            }
        } else if (TipoFact == "2") {
            classFactID FactID;// Instaciamos la clase 
            List<classFactID> lista = new ArrayList<>(); //Creamos una lista de empleados con ArrayList para obtener cada empleado
            for (int i = 0; i < TableCuentaID.getRowCount(); i++) { // Iterena cada fila de la tabla
                FactID = new classFactID(TableCuentaID.getValueAt(i, 0).toString(), TableCuentaID.getValueAt(i, 1).toString(), //Tomamos de la tabla el valor de cada columna y creamos un objeto 
                        TableCuentaID.getValueAt(i, 2).toString(), formatofecha.format(dateFechaID.getDate()),
                        LabelTotalID.getText(), MaxID_ID(), txtNombreID.getText(), txtObservaID.getText(), txtTotalLetrasID.getText(), txtNumCuentaID.getText());
                lista.add(FactID); //Agregamos el objeto empleado a la lista
            }
            JasperReport reporte; // Instaciamos el objeto reporte
            String path = "src\\Facturas\\rpt_IgresosD.jasper"; //Ponemos la localizacion del reporte creado
            try {
                reporte = (JasperReport) JRLoader.loadObjectFromFile(path); //Se carga el reporte de su localizacion
                JasperPrint jprint = JasperFillManager.fillReport(reporte, null, new JRBeanCollectionDataSource(lista)); //Agregamos los parametros para llenar el reporte
                Date Ahora = new Date();
                File FileFact = new File("Facturas\\FacturaID de "+txtNombreID.getText()+"-"+ formatofechaBackUp.format(Ahora) + ".pdf");
                FileWriter fw = new FileWriter(FileFact);
                String rutaDestino = FileFact.toString();
                //Exporta el informe a PDF
                JasperExportManager.exportReportToPdfFile(jprint, rutaDestino);
                Desktop desktop = Desktop.getDesktop();
                if(FileFact.exists())
                desktop.open(FileFact);
            } catch (JRException ex) {
                JOptionPane.showMessageDialog(this, "el error es:"+ex, "INGRESOS DIVERSOS", JOptionPane.INFORMATION_MESSAGE);
            }
        } else if (TipoFact == "3") {
            classFactIP FactIP;// Instaciamos la clase 
            List<classFactIP> lista = new ArrayList<>(); //Creamos una lista de empleados con ArrayList para obtener cada empleado
            for (int i = 0; i < TableCuentaIP.getRowCount(); i++) { // Iterena cada fila de la tabla
                FactIP = new classFactIP(TableCuentaIP.getValueAt(i, 0).toString(), TableCuentaIP.getValueAt(i, 1).toString(), //Tomamos de la tabla el valor de cada columna y creamos un objeto 
                        TableCuentaIP.getValueAt(i, 2).toString(), formatofecha.format(dateFechaIP.getDate()),
                        LabelTotalIP.getText(), MaxID_IP(), txtNombreIP.getText(), txtObservaIP.getText(), txtNumCuentaIP.getText(), txtTotalLetrasIP.getText(),
                        txtNPrestamoIP.getText(), txtCicloIP.getText(), SelectMonedaIP(), formatofecha.format(dateFechaEntregaIP.getDate()),
                        formatofecha.format(dateFechaIFinslIP.getDate()), txtPlazoIP.getText(), txtTasaIP.getText(), txtsaldoActualIP.getText(), txtintereseAcumuIP.getText());
                lista.add(FactIP); //Agregamos el objeto empleado a la lista
            }
            JasperReport reporte; // Instaciamos el objeto reporte
            String path = "src\\Facturas\\rpt_IgresosP.jasper"; //Ponemos la localizacion del reporte creado
            try {
                reporte = (JasperReport) JRLoader.loadObjectFromFile(path); //Se carga el reporte de su localizacion
                JasperPrint jprint = JasperFillManager.fillReport(reporte, null, new JRBeanCollectionDataSource(lista)); //Agregamos los parametros para llenar el reporte
                Date Ahora = new Date();
                File FileFact = new File("Facturas\\FacturaIP de "+txtNombreIP.getText()+"-"+ formatofechaBackUp.format(Ahora) + ".pdf");
                FileWriter fw = new FileWriter(FileFact);
                String rutaDestino = FileFact.toString();
                //Exporta el informe a PDF
                JasperExportManager.exportReportToPdfFile(jprint, rutaDestino);
                Desktop desktop = Desktop.getDesktop();
                if(FileFact.exists())
                desktop.open(FileFact);
            } catch (JRException ex) {
                JOptionPane.showMessageDialog(this, "el error es:"+ex, "INGRESOS DE PRESTAMOS", JOptionPane.INFORMATION_MESSAGE);
            }
        } else if (TipoFact == "4") {
            classFactIP FactIPD;// Instaciamos la clase 
            List<classFactIP> lista = new ArrayList<>(); //Creamos una lista de empleados con ArrayList para obtener cada empleado
            for (int i = 0; i < TableCuentaIPD.getRowCount(); i++) { // Iterena cada fila de la tabla
                FactIPD = new classFactIP(TableCuentaIPD.getValueAt(i, 0).toString(), TableCuentaIPD.getValueAt(i, 1).toString(), //Tomamos de la tabla el valor de cada columna y creamos un objeto 
                        TableCuentaIPD.getValueAt(i, 2).toString(), formatofecha.format(dateFechaIPD.getDate()),
                        LabelTotalIPD.getText(), MaxID_IP(), txtNombreIPD.getText(), txtObservaIPD.getText(), txtNumCuentaIPD.getText(), txtTotalLetrasIPD.getText(),
                        txtNPrestamoIPD.getText(), txtCicloIPD.getText(), SelectMonedaIP(), formatofecha.format(dateFechaEntregaIPD.getDate()),
                        formatofecha.format(dateFechaIFinslIPD.getDate()), txtPlazoIPD.getText(), txtTasaIPD.getText(), txtsaldoActualIPD.getText(), txtintereseAcumuIPD.getText());
                lista.add(FactIPD); //Agregamos el objeto empleado a la lista
            }
            JasperReport reporte; // Instaciamos el objeto reporte
            String path = "src\\Facturas\\rpt_IgresosPD.jasper"; //Ponemos la localizacion del reporte creado
            try {
                reporte = (JasperReport) JRLoader.loadObjectFromFile(path); //Se carga el reporte de su localizacion
                JasperPrint jprint = JasperFillManager.fillReport(reporte, null, new JRBeanCollectionDataSource(lista)); //Agregamos los parametros para llenar el reporte
                Date Ahora = new Date();
                File FileFact = new File("Facturas\\FacturaIPD de "+txtNombreIPD.getText()+"-"+ formatofechaBackUp.format(Ahora) + ".pdf");
                FileWriter fw = new FileWriter(FileFact);
                String rutaDestino = FileFact.toString();
                //Exporta el informe a PDF
                JasperExportManager.exportReportToPdfFile(jprint, rutaDestino);
                Desktop desktop = Desktop.getDesktop();
                if(FileFact.exists())
                desktop.open(FileFact);
            } catch (JRException ex) {
                JOptionPane.showMessageDialog(this, "el error es:"+ex, "INGRESOS DE PRESTAMOS EN DEMANDA", JOptionPane.INFORMATION_MESSAGE);
            }
        } else if (TipoFact == "5") {
            classFactIA Fact;// Instaciamos la clase 
            List<classFactIA> lista = new ArrayList<>(); //Creamos una lista de empleados con ArrayList para obtener cada empleado
            for (int i = 0; i < TableCuentaEA.getRowCount(); i++) { // Iterena cada fila de la tabla
                Fact = new classFactIA(TableCuentaEA.getValueAt(i, 0).toString(), TableCuentaEA.getValueAt(i, 1).toString(), //Tomamos de la tabla el valor de cada columna y creamos un objeto 
                        TableCuentaEA.getValueAt(i, 2).toString(), formatofecha.format(dateFechaEA.getDate()),
                        LabelTotalEA.getText(), MaxID_EA(), txtNombreEA.getText(), txtObservaEA.getText(), txtTotalLetrasEA.getText(),
                        SelectNOCtaEA(), txtNumCuentaEA.getText());
                lista.add(Fact); //Agregamos el objeto empleado a la lista
            }
            JasperReport reporte; // Instaciamos el objeto reporte
            String path = "src\\Facturas\\rpt_EgresosA.jasper"; //Ponemos la localizacion del reporte creado
            try {
                reporte = (JasperReport) JRLoader.loadObjectFromFile(path); //Se carga el reporte de su localizacion
                JasperPrint jprint = JasperFillManager.fillReport(reporte, null, new JRBeanCollectionDataSource(lista)); //Agregamos los parametros para llenar el reporte
                Date Ahora = new Date();
                File FileFact = new File("Facturas\\FacturaEA de "+txtNombreEA.getText()+"-"+ formatofechaBackUp.format(Ahora) + ".pdf");
                FileWriter fw = new FileWriter(FileFact);
                String rutaDestino = FileFact.toString();
                //Exporta el informe a PDF
                JasperExportManager.exportReportToPdfFile(jprint, rutaDestino);
                Desktop desktop = Desktop.getDesktop();
                if(FileFact.exists())
                desktop.open(FileFact);
            } catch (JRException ex) {
                JOptionPane.showMessageDialog(this, "el error es:"+ex, "EGRESOS DE AHORRO", JOptionPane.INFORMATION_MESSAGE);
            }
        }
        return TipoFact;

    }

    void CargarDataMetodos() {
        obtener_Cuentas();
        obtener_Usuarios();
        t.visualizar_CuentasIA(TableCuentaIA);
        t.visualizar_CuentasID(TableCuentaID);
        t.visualizar_CuentasIP(TableCuentaIP);
        t.visualizar_CuentasIPD(TableCuentaIPD);
        t.visualizar_CuentasEA(TableCuentaEA);
        txtIdIA.hide();
        txtIdID.hide();
        txtIdIP.hide();
        txtIdIPD.hide();
        txtIdEA.hide();
        btnEditarID.hide();btnDeleteID.hide();
        btnEditarIA.hide();btnEliminarIA.hide();
        btnEditarIP.hide();btnDeleteIP.hide();
        btnEditarIPD.hide();btnDeleteIPD.hide();
        btnEditarEA.hide();btnEliminarEA.hide();
        int indiceUltimaFila = TableCuentaID.getRowCount() - 1;
        String Cuenta = TableCuentaID.getValueAt(indiceUltimaFila, 0).toString();
        if ("5400-200-0500".equals(Cuenta)) {
            //CtaCSA();
            addCtaTableID();
        }
    }

    public String SelectNOCtaIA() {
        if (IAchkNCtaAPF.isSelected()) {//1
            NOCtaIA = "A.P.F.";
        } else if (IAchkNCtaAR.isSelected()) {//2
            NOCtaIA = "A.R.";
        } else if (IAchkNCtaAM.isSelected()) {//3
            NOCtaIA = "A.M.";
        } else if (IAchkNCtaAE.isSelected()) {//4
            NOCtaIA = "A.E.";
        } else if (IAchkNCtaAN.isSelected()) {//5
            NOCtaIA = "A.N.";
        } else if (IAchkNCtaAO.isSelected()) {//6
            NOCtaIA = "A.O.";
        }
        return NOCtaIA;
    }

    public String SelectMonedaIP() {
        if (ChkLIP.isSelected()) {//1
            NOCtaIA = "Lempira";
        } else if (Chk$IP.isSelected()) {//2
            NOCtaIA = "Dólar";
        }
        return NOCtaIA;
    }

    public String SelectMonedaIPD() {
        if (ChkLIPD.isSelected()) {//1
            NOCtaIA = "Lempira";
        } else if (Chk$IPD.isSelected()) {//2
            NOCtaIA = "Dólar";
        }
        return NOCtaIA;
    }

    public String SelectNOCtaEA() {
        if (EAchkNCtaAPF.isSelected()) {//1
            NOCtaIA = "A.P.F.";
        } else if (EAchkNCtaAR.isSelected()) {//2
            NOCtaIA = "A.R.";
        } else if (EAchkNCtaAM.isSelected()) {//3
            NOCtaIA = "A.M.";
        } else if (EAchkNCtaAE.isSelected()) {//4
            NOCtaIA = "A.E.";
        } else if (EAchkNCtaAN.isSelected()) {//5
            NOCtaIA = "A.N.";
        } else if (EAchkNCtaAO.isSelected()) {//6
            NOCtaIA = "A.O.";
        }
        return NOCtaIA;
    }
    public void obtener_DetallesFact() {
        int i = TableFacturas.getSelectedRow();
        if(cbxBuscarFactura.getSelectedItem().equals("Ingresos de Ahorro")){
            t.visualizar_CuentasFactIA(TableCuentaIA,TableFacturas.getValueAt(i, 0).toString());
         }else if(cbxBuscarFactura.getSelectedItem().equals("Ingresos Diversos")){
            TableCuentaID.setModel(DbUtils.resultSetToTableModel(rs));
            TableCuentaID.setRowHeight(30); }
        }
    public void obtener_Cuentas() {
        String sql = "select id_cta as 'ID CUENTA', tfactura as 'COMPROBANTE',"
                + "                num_cta as 'CUENTA',"
                + "               descripcion as 'DESCRIPCIÓN',"
                + "               moneda as 'MONEDA' from cuentas";
        try {
            pst = con.prepareStatement(sql);
            rs = pst.executeQuery();
            TableCuenta.setModel(DbUtils.resultSetToTableModel(rs));
            TableCuenta.setRowHeight(30);
            //TableCuenta.removeColumn(TableCuenta.getColumnModel().getColumn(0));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);

        }
    }public void obtener_Usuarios() {
        String sql = "select id as 'ID USUARIO', nombre as 'NOMBRE',"
                + "                correo as 'CORREO',"
                + "               pass as 'CONTRASEÑA',"
                + "               rol as 'ROL' from usuarios";
        try {
            pst = con.prepareStatement(sql);
            rs = pst.executeQuery();
            TableUsuarios.setModel(DbUtils.resultSetToTableModel(rs));
            TableUsuarios.setRowHeight(30);
            //TableCuenta.removeColumn(TableCuenta.getColumnModel().getColumn(0));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);

        }
    }

    public void EliminarFilasVaciasIA(String nombre) {
        DefaultTableModel modelo1 = (DefaultTableModel) TableCuentaIA.getModel();
        ArrayList<Integer> list = new ArrayList<>();
        for (int f = 0; f < modelo1.getRowCount(); f++) {
            for (int c = 0; c < modelo1.getColumnCount(); c++) {
                if (modelo1.getValueAt(f, c).equals(nombre)) {
                    list.add(f);
                } else {
                }
            }
        }
        imprimeTblCtaIA(list);
    }

    public void imprimeTblCtaIA(ArrayList lista) {
        DefaultTableModel modelo1 = (DefaultTableModel) TableCuentaIA.getModel();
        for (int i = 0; i < lista.size(); i++) {
            Comparator<Integer> comparador = Collections.reverseOrder();
            Collections.sort(lista, comparador);
            modelo1.removeRow((int) lista.get(i));
            //System.out.println(lista.get(i)); // Aqui por si ocupan ver, el orden en que se pasa los numeros...
        }
    }

    public void EliminarFilasVaciasID(String nombre) {
        DefaultTableModel modelo1 = (DefaultTableModel) TableCuentaID.getModel();
        ArrayList<Integer> list = new ArrayList<>();
        for (int f = 0; f < modelo1.getRowCount(); f++) {
            for (int c = 0; c < modelo1.getColumnCount(); c++) {
                if (modelo1.getValueAt(f, c).equals(nombre)) {
                    list.add(f);
                } else {
                }
            }
        }
        imprimeTblCtaID(list);
    }

    public void imprimeTblCtaID(ArrayList lista) {
        DefaultTableModel modelo1 = (DefaultTableModel) TableCuentaID.getModel();
        for (int i = 0; i < lista.size(); i++) {
            Comparator<Integer> comparador = Collections.reverseOrder();
            Collections.sort(lista, comparador);
            modelo1.removeRow((int) lista.get(i));
            //System.out.println(lista.get(i)); // Aqui por si ocupan ver, el orden en que se pasa los numeros...
        }
    }

    public void EliminarFilasVaciasIP(String nombre) {
        DefaultTableModel modelo1 = (DefaultTableModel) TableCuentaIP.getModel();
        ArrayList<Integer> list = new ArrayList<>();
        for (int f = 0; f < modelo1.getRowCount(); f++) {
            for (int c = 0; c < modelo1.getColumnCount(); c++) {
                if (modelo1.getValueAt(f, c).equals(nombre)) {
                    list.add(f);
                } else {
                }
            }
        }
        imprimeTblCtaIP(list);
    }

    public void imprimeTblCtaIP(ArrayList lista) {
        DefaultTableModel modelo1 = (DefaultTableModel) TableCuentaIP.getModel();
        for (int i = 0; i < lista.size(); i++) {
            Comparator<Integer> comparador = Collections.reverseOrder();
            Collections.sort(lista, comparador);
            modelo1.removeRow((int) lista.get(i));
            //System.out.println(lista.get(i)); // Aqui por si ocupan ver, el orden en que se pasa los numeros...
        }
    }

    public void EliminarFilasVaciasIPD(String nombre) {
        DefaultTableModel modelo1 = (DefaultTableModel) TableCuentaIPD.getModel();
        ArrayList<Integer> list = new ArrayList<>();
        for (int f = 0; f < modelo1.getRowCount(); f++) {
            for (int c = 0; c < modelo1.getColumnCount(); c++) {
                if (modelo1.getValueAt(f, c).equals(nombre)) {
                    list.add(f);
                } else {
                }
            }
        }
        imprimeTblCtaIPD(list);
    }

    public void imprimeTblCtaIPD(ArrayList lista) {
        DefaultTableModel modelo1 = (DefaultTableModel) TableCuentaIPD.getModel();
        for (int i = 0; i < lista.size(); i++) {
            Comparator<Integer> comparador = Collections.reverseOrder();
            Collections.sort(lista, comparador);
            modelo1.removeRow((int) lista.get(i));
            //System.out.println(lista.get(i)); // Aqui por si ocupan ver, el orden en que se pasa los numeros...
        }
    }

    public void EliminarFilasVaciasEA(String nombre) {
        DefaultTableModel modelo1 = (DefaultTableModel) TableCuentaEA.getModel();
        ArrayList<Integer> list = new ArrayList<>();
        for (int f = 0; f < modelo1.getRowCount(); f++) {
            for (int c = 0; c < modelo1.getColumnCount(); c++) {
                if (modelo1.getValueAt(f, c).equals(nombre)) {
                    list.add(f);
                } else {
                }
            }
        }
        imprimeTblCtaEA(list);
    }

    public void imprimeTblCtaEA(ArrayList lista) {
        DefaultTableModel modelo1 = (DefaultTableModel) TableCuentaEA.getModel();
        for (int i = 0; i < lista.size(); i++) {
            Comparator<Integer> comparador = Collections.reverseOrder();
            Collections.sort(lista, comparador);
            modelo1.removeRow((int) lista.get(i));
            //System.out.println(lista.get(i)); // Aqui por si ocupan ver, el orden en que se pasa los numeros...
        }
    }

    private void TotalIgresosAhorro() {
        Totalpagar = 0.00;
        int numFila = TableCuentaIA.getRowCount();
        for (int i = 0; i < numFila; i++) {
            double cal = Double.parseDouble(String.valueOf(TableCuentaIA.getModel().getValueAt(i, 2)));
            Totalpagar = Totalpagar + cal;
        }
        LabelTotalIA.setText(String.format("%.2f", Totalpagar));
    }

    private void TotalIgresosDiverso() {
        Totalpagar = 0.00;
        int numFila = TableCuentaID.getRowCount() - 8;
        for (int i = 0; i < numFila; i++) {
            double cal = Double.parseDouble(String.valueOf(TableCuentaID.getModel().getValueAt(i, 2)));
            Totalpagar = Totalpagar + cal;
        }
        LabelTotalID.setText(String.format("%.2f", Totalpagar));
    }

    void subcuentasID() {
        int indiceUltimaFila = TableCuentaID.getRowCount() - 8;
        int filaCtaCSA = TableCuentaID.getRowCount() - 9;
        Double total = 0.00;
        for (int i = indiceUltimaFila; i < TableCuentaID.getRowCount(); i++) {
            total += Double.parseDouble(TableCuentaID.getValueAt(i, 2).toString());
            TableCuentaID.setValueAt(String.format("%.2f", total), filaCtaCSA, 2);
            //TotalIgresosDiverso();
        }
    }

    private void TotalIgresosPrestamo() {
        Totalpagar = 0.00;
        int numFila = TableCuentaIP.getRowCount();
        for (int i = 0; i < numFila; i++) {
            double cal = Double.parseDouble(String.valueOf(TableCuentaIP.getModel().getValueAt(i, 2)));
            Totalpagar = Totalpagar + cal;
        }
        LabelTotalIP.setText(String.format("%.2f", Totalpagar));
    }

    private void TotalIgresosPrestamoD() {
        Totalpagar = 0.00;
        int numFila = TableCuentaIPD.getRowCount();
        for (int i = 0; i < numFila; i++) {
            double cal = Double.parseDouble(String.valueOf(TableCuentaIPD.getModel().getValueAt(i, 2)));
            Totalpagar = Totalpagar + cal;
        }
        LabelTotalIPD.setText(String.format("%.2f", Totalpagar));
    }

    private void TotalEgresosA() {
        Totalpagar = 0.00;
        int numFila = TableCuentaEA.getRowCount();
        for (int i = 0; i < numFila; i++) {
            double cal = Double.parseDouble(String.valueOf(TableCuentaEA.getModel().getValueAt(i, 2)));
            Totalpagar = Totalpagar + cal;
        }
        LabelTotalEA.setText(String.format("%.2f", Totalpagar));
    }
    private void txtCorreoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCorreoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCorreoActionPerformed

    private void btnActualizarConfigActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarConfigActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_btnActualizarConfigActionPerformed

    private void btnNuevoCtaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoCtaActionPerformed
        // TODO add your handling code here:
        LimpiarCuentas();
        btnEditarCta.setEnabled(false);
        btnEliminarCta.setEnabled(false);
        btnGuardarCta.setEnabled(true);
    }//GEN-LAST:event_btnNuevoCtaActionPerformed

    private void btnEliminarCtaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarCtaActionPerformed
        // TODO add your handling code here:
        try {
            int P = JOptionPane.showConfirmDialog(null, " Seguro que quiere borrarlo ?", "Confirmación", JOptionPane.YES_NO_OPTION);
            if (P == 0) {
                con = Conexion.ConnectDB();

                String sql = "delete from cuentas where id_cta='" + txtIdCta.getText() + "'";
                pst = con.prepareStatement(sql);
                pst.execute();
                JOptionPane.showMessageDialog(this, "Borrado Exitosamente", "Registro de Cuentas", JOptionPane.INFORMATION_MESSAGE);
                CargarDataMetodos();
                limpiarDataCuentas();
                btnEditarCta.setEnabled(false);
                btnEliminarCta.setEnabled(false);
                btnGuardarCta.setEnabled(true);
            }
        } catch (SQLException e) {

        }
    }//GEN-LAST:event_btnEliminarCtaActionPerformed

    private void btnEditarCtaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarCtaActionPerformed
        try {
            con = Conexion.ConnectDB();
            String sql = "update cuentas set tfactura='" + cbxComprobante.getSelectedItem()
                    + "',num_cta='" + txtNumCta.getText()
                    + "',descripcion='" + txtDescripcion.getText()
                    + "',moneda='" + cbxMoneda.getSelectedItem()
                    + "' where id_cta='" + txtIdCta.getText() + "'";
            pst = con.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(this, "Cuenta Actualizada", "Registro de Cuentas", JOptionPane.INFORMATION_MESSAGE);
            CargarDataMetodos();
            limpiarDataCuentas();

        } catch (SQLException e) {

        }
    }//GEN-LAST:event_btnEditarCtaActionPerformed

    private void btnGuardarCtaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarCtaActionPerformed
        try {
            con = Conexion.ConnectDB();
            if ((txtNumCta.getText().equals("")) || (txtDescripcion.getText().equals("")) || (cbxComprobante.getSelectedItem().equals(""))) {
                JOptionPane.showMessageDialog(this, "Falta Ingreso de algunos Datos", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String sql = "insert into cuentas(tfactura,"
                    + "num_cta,"
                    + "descripcion,"
                    + "moneda) values ('"
                    + cbxComprobante.getSelectedItem() + "','"
                    + txtNumCta.getText() + "','"
                    + txtDescripcion.getText() + "','"
                    + cbxMoneda.getSelectedItem() + "')";
            pst = con.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(this, "Registrado con éxito", "Registro de Cuentas", JOptionPane.INFORMATION_MESSAGE);
            limpiarDataCuentas();
            CargarDataMetodos();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, e);
        }
    }//GEN-LAST:event_btnGuardarCtaActionPerformed

    private void cbxComprobanteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbxComprobanteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbxComprobanteActionPerformed

    private void cbxComprobanteItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbxComprobanteItemStateChanged
        // TODO add your handling code here:

    }//GEN-LAST:event_cbxComprobanteItemStateChanged
    public String MaxID_IA() {
        String sql = null;
        try {
            con = Conexion.ConnectDB();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select MAX(num_factura)from list_fact_ia");

            while (rs.next()) {
                sql = (rs.getString(1));
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return sql;
    }

    public String MaxID_ID() {
        String sql = null;
        try {
            con = Conexion.ConnectDB();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select MAX(num_factura)from list_fact_id");

            while (rs.next()) {
                sql = (rs.getString(1));
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return sql;
    }

    public String MaxID_IP() {
        String sql = null;
        try {
            con = Conexion.ConnectDB();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select MAX(num_factura)from list_fact_ip");

            while (rs.next()) {
                sql = (rs.getString(1));
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return sql;
    }

    public String MaxID_EA() {
        String sql = null;
        try {
            con = Conexion.ConnectDB();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select MAX(num_factura)from list_fact_ea");

            while (rs.next()) {
                sql = (rs.getString(1));
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return sql;
    }
    private void btnGuardarIAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarIAActionPerformed
        // TODO add your handling code here:

        if ("".equals(txtIdIA.getText())) {
            try {
                con = Conexion.ConnectDB();
                if ((txtNumCuentaIA.getText().equals("")) || (txtNombreIA.getText().equals("")) || (LabelTotalIA.getText().equals("0.00")) || (buttonGroup1.getSelection() == null) || (txtNumCuentaIA.getText().length() < limite) || dateFechaIA.getDate() == null) {
                    JOptionPane.showMessageDialog(this, "Falta Ingreso de algunos Datos O Numero de Cuenta Incorrecto Incorrecta", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                String sql = "insert into list_fact_ia(fecha,"
                        + "num_cuenta,"
                        + "tipo_cuenta,"
                        + "nombre,"
                        + "total,"
                        + "observaciones) values ('"
                        + formatofecha.format(dateFechaIA.getDate()) + "','"
                        + txtNumCuentaIA.getText() + "','"
                        + SelectNOCtaIA() + "','"
                        + txtNombreIA.getText() + "','"
                        + LabelTotalIA.getText() + "','"
                        + txtObservaIA.getText() + "')";
                pst = con.prepareStatement(sql);
                pst.execute();

                for (int i = 0; i < TableCuentaIA.getRowCount(); i++) {
                    String Cuenta = TableCuentaIA.getValueAt(i, 0).toString();
                    String descripcion = TableCuentaIA.getValueAt(i, 1).toString();
                    String valores = TableCuentaIA.getValueAt(i, 2).toString();
                    String sqlId = "insert into detalles_fact(num_factura,"
                            + "tfactura,"
                            + "cuenta,"
                            + "descripcion,"
                            + "valores) values ('"
                            + MaxID_IA() + "','"
                            + "Ingresos de Ahorro" + "','"
                            + Cuenta + "','"
                            + descripcion + "','"
                            + valores + "')";
                    pst = con.prepareStatement(sqlId);
                    pst.execute();
                }

                JOptionPane.showMessageDialog(this, "Registrado con éxito", "INGRESOS DE AHORROS", JOptionPane.INFORMATION_MESSAGE);
                EliminarFilasVaciasIA("0.00");
                try {
                    print_bill("1");
                } catch (IOException ex) {
                    Logger.getLogger(Sistema.class.getName()).log(Level.SEVERE, null, ex);
                }
                //CargarDataMetodos();
                txtIdIA.setText(MaxID_IA());

            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, e);
            }
        } else {
            try {
                JOptionPane.showMessageDialog(this, "Esta Factura ya esta Guardada puede Imprimir la Factura de Nuevo", "INGRESOS DE AHORROS", JOptionPane.INFORMATION_MESSAGE);
                print_bill("1");
                btnGuardarIA.setEnabled(false);
            } catch (IOException ex) {
                Logger.getLogger(Sistema.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_btnGuardarIAActionPerformed

    private void txtTotalLetrasIAKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTotalLetrasIAKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTotalLetrasIAKeyTyped

    private void txtTotalLetrasIAKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTotalLetrasIAKeyPressed
        // TODO add your handling code here:
        /* if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            if (!"".equals(txtRucVenta.getText())) {
                int dni = Integer.parseInt(txtRucVenta.getText());
                cl = client.Buscarcliente(dni);
                if (cl.getNombre() != null) {
                    txtNombreClienteventa.setText("" + cl.getNombre());
                    txtIdCV.setText("" + cl.getId());
                } else {
                    txtRucVenta.setText("");
                    JOptionPane.showMessageDialog(null, "El cliente no existe");
                }
            }
        }*/
    }//GEN-LAST:event_txtTotalLetrasIAKeyPressed

    private void btnEliminarventaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarventaActionPerformed
        // TODO add your handling code here:
        CargarDataMetodos();
        TotalPagar();
        btnEditarIA.hide();
        btnEliminarIA.hide();
        txtNumCuentaIA.requestFocus();
        txtIdIA.setText("");
        txtNumCuentaIA.setText("");
        txtNombreIA.setText("");
        buttonGroup1.clearSelection();
        txtTotalLetrasIA.setText("");
        txtObservaIA.setText("");
        btnGuardarIA.setEnabled(true);
    }//GEN-LAST:event_btnEliminarventaActionPerformed

    private void txtIdIAKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtIdIAKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIdIAKeyTyped

    private void txtIdIAKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtIdIAKeyPressed
        // TODO add your handling code here:
        /* if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            if (!"".equals(txtCodigoVenta.getText())) {
                String cod = txtCodigoVenta.getText();
                cta = ctaDao.BuscarPro(cod);
                if (cta.getNombre() != null) {
                    txtIdPro.setText("" + cta.getId());
                    txtDescripcionVenta.setText("" + cta.getNombre());
                    txtPrecioVenta.setText("" + cta.getPrecio());
                    txtStockDisponible.setText("" + cta.getStock());
                    txtCantidadVenta.requestFocus();
                } else {
                    LimparVenta();
                    txtCodigoVenta.requestFocus();
                }
            } else {
                JOptionPane.showMessageDialog(null, "Ingrese el codigo del productos");
                txtCodigoVenta.requestFocus();
            }
        }*/
    }//GEN-LAST:event_txtIdIAKeyPressed

    private void txtTotalLetrasIAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTotalLetrasIAActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTotalLetrasIAActionPerformed

    private void IAchkNCtaAEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_IAchkNCtaAEActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_IAchkNCtaAEActionPerformed

    private void IAchkNCtaAPFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_IAchkNCtaAPFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_IAchkNCtaAPFActionPerformed

    private void IAchkNCtaARActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_IAchkNCtaARActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_IAchkNCtaARActionPerformed

    private void IAchkNCtaAMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_IAchkNCtaAMActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_IAchkNCtaAMActionPerformed

    private void cbxMonedaItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbxMonedaItemStateChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_cbxMonedaItemStateChanged

    private void cbxMonedaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbxMonedaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbxMonedaActionPerformed

    private void TableCuentaIAMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TableCuentaIAMouseClicked
        int column = TableCuentaIA.getColumnModel().getColumnIndexAtX(evt.getX());
        int row = evt.getY() / TableCuentaIA.getRowHeight();

        if (row < TableCuentaIA.getRowCount() && row >= 0 && column < TableCuentaIA.getColumnCount() && column >= 0) {
            Object value = TableCuentaIA.getValueAt(row, column);
            DefaultTableModel tm = (DefaultTableModel) TableCuentaIA.getModel();
            if (value instanceof JButton) {
                ((JButton) value).doClick();
                JButton boton = (JButton) value;

                if (boton.getName().equals("m")) {
                    Double cantDatos;
                    cantDatos = Double.parseDouble(JOptionPane.showInputDialog(null, "Digite el valor", "Valores", JOptionPane.INFORMATION_MESSAGE));
                    int fila = 0;
                    fila = TableCuentaIA.getSelectedRow();
                    if (cantDatos != null) {
                        TableCuentaIA.setValueAt(String.format("%.2f", cantDatos), fila, 2);
                    } else {
                        cantDatos = 0.00;
                        TableCuentaIA.setValueAt(cantDatos, fila, 2);
                    }
                    TotalIgresosAhorro();
                    Numero_a_Letra d = new Numero_a_Letra();
                    String letras = d.Convertir(LabelTotalIA.getText(), true);
                    txtTotalLetrasIA.setText(letras);
                }
            }

        }     // TODO add your handling code here:
    }//GEN-LAST:event_TableCuentaIAMouseClicked

    private void txtBuscarCuentaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscarCuentaKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtBuscarCuentaKeyPressed

    private void txtBuscarCuentaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscarCuentaKeyTyped
        // TODO add your handling code here:
        String sql = "select id_cta as ID, tfactura as 'COMPROBANTE',"
                + "                num_cta as 'CUENTA',"
                + "               descripcion as 'DESCRIPCIÓN',"
                + "               moneda as 'MONEDA' from cuentas where tfactura LIKE '%" + txtBuscarCuenta.getText()
                + "%' or num_cta LIKE '%" + txtBuscarCuenta.getText()
                + "%' or descripcion LIKE '%" + txtBuscarCuenta.getText()
                + "%'";

        try {
            pst = con.prepareStatement(sql);
            rs = pst.executeQuery();
            TableCuenta.setModel(DbUtils.resultSetToTableModel(rs));
            TableCuenta.setRowHeight(30);
            //TableCuenta.removeColumn(TableCuenta.getColumnModel().getColumn(0));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);

        }

    }//GEN-LAST:event_txtBuscarCuentaKeyTyped

    private void cbxBuscarCuentaItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbxBuscarCuentaItemStateChanged
        // TODO add your handling code here:
        String sql = "select id_cta as ID, tfactura as 'COMPROBANTE',"
                + "                num_cta as 'CUENTA',"
                + "               descripcion as 'DESCRIPCIÓN',"
                + "               moneda as 'MONEDA' from cuentas where tfactura = '" + cbxBuscarCuenta.getSelectedItem() + "' ";

        try {
            pst = con.prepareStatement(sql);
            rs = pst.executeQuery();
            TableCuenta.setModel(DbUtils.resultSetToTableModel(rs));
            TableCuenta.setRowHeight(30);

            //TableCuenta.removeColumn(TableCuenta.getColumnModel().getColumn(0));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);

        }
    }//GEN-LAST:event_cbxBuscarCuentaItemStateChanged

    private void cbxBuscarCuentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbxBuscarCuentaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbxBuscarCuentaActionPerformed

    private void cbxBuscarCuentaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cbxBuscarCuentaMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_cbxBuscarCuentaMouseClicked

    private void cbxBuscarCuentaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cbxBuscarCuentaMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbxBuscarCuentaMousePressed

    private void txtNumCuentaIDKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNumCuentaIDKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNumCuentaIDKeyPressed

    private void txtNumCuentaIDKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNumCuentaIDKeyTyped
        // TODO add your handling code here:
        char car = evt.getKeyChar();
        if ((car < '0' || car > '9')) {
            evt.consume();
        }
        if (txtNumCuentaID.getText().length() == limite) {
            evt.consume();
        }
    }//GEN-LAST:event_txtNumCuentaIDKeyTyped

    private void btnEliminarIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarIDActionPerformed
        // TODO add your handling code here:
        CargarDataMetodos();
        TotalIgresosDiverso();
        txtNumCuentaID.requestFocus();
        txtIdID.setText("");
        txtNumCuentaID.setText("");
        txtNombreID.setText("");
        txtTotalLetrasID.setText("");
        txtObservaID.setText("");
        btnGuardarID.setEnabled(true);
    }//GEN-LAST:event_btnEliminarIDActionPerformed

    private void txtObservaIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtObservaIDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtObservaIDActionPerformed

    private void txtObservaIDKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtObservaIDKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtObservaIDKeyPressed

    private void txtObservaIDKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtObservaIDKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txtObservaIDKeyTyped

    private void btnGuardarIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarIDActionPerformed
        // TODO add your handling code here:
        if ("".equals(txtIdID.getText())) {
            try {
                con = Conexion.ConnectDB();
                if ((txtNumCuentaID.getText().equals("")) || (txtNombreID.getText().equals("")) || (LabelTotalID.getText().equals("0.00")) || (txtNumCuentaID.getText().length() < limite)) {
                    JOptionPane.showMessageDialog(this, "Falta Ingreso de algunos Datos O Numero de Cuenta Incorrecto Incorrecta", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                String sql = "insert into list_fact_id(fecha,"
                        + "num_cuenta,"
                        + "nombre,"
                        + "total,"
                        + "observaciones) values ('"
                        + formatofecha.format(dateFechaID.getDate()) + "','"
                        + txtNumCuentaID.getText() + "','"
                        + txtNombreID.getText() + "','"
                        + LabelTotalID.getText() + "','"
                        + txtObservaID.getText() + "')";
                pst = con.prepareStatement(sql);
                pst.execute();

                for (int i = 0; i < TableCuentaID.getRowCount(); i++) {
                    String Cuenta = TableCuentaID.getValueAt(i, 0).toString();
                    String descripcion = TableCuentaID.getValueAt(i, 1).toString();
                    String valores = TableCuentaID.getValueAt(i, 2).toString();
                    String sqlId = "insert into detalles_fact(num_factura,"
                            + "tfactura,"
                            + "cuenta,"
                            + "descripcion,"
                            + "valores) values ('"
                            + MaxID_ID() + "','"
                            + "Ingresos Diversos" + "','"
                            + Cuenta + "','"
                            + descripcion + "','"
                            + valores + "')";
                    pst = con.prepareStatement(sqlId);
                    pst.execute();
                }
                JOptionPane.showMessageDialog(this, "Registrado con éxito", "INGRESOS DIVERSOS", JOptionPane.INFORMATION_MESSAGE);
                EliminarFilasVaciasID("0.00");
                try {
                    print_bill("2");
                } catch (IOException ex) {
                    Logger.getLogger(Sistema.class.getName()).log(Level.SEVERE, null, ex);
                }
                //CargarDataMetodos();
                txtIdID.setText(MaxID_ID());
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, e);
            }
        } else {
            try {
                JOptionPane.showMessageDialog(this, "Esta Factura ya esta Guardada puede Imprimir la Factura de Nuevo", "INGRESOS DIVERSOS", JOptionPane.INFORMATION_MESSAGE);
                print_bill("2");
                btnGuardarID.setEnabled(false);
            } catch (IOException ex) {
                Logger.getLogger(Sistema.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_btnGuardarIDActionPerformed

    private void TableCuentaIDMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TableCuentaIDMouseClicked
        // TODO add your handling code here:
        int column = TableCuentaID.getColumnModel().getColumnIndexAtX(evt.getX());
        int row = evt.getY() / TableCuentaID.getRowHeight();

        if (row < TableCuentaID.getRowCount() && row >= 0 && column < TableCuentaID.getColumnCount() && column >= 0) {
            Object value = TableCuentaID.getValueAt(row, column);
            DefaultTableModel tm = (DefaultTableModel) TableCuentaID.getModel();
            if (value instanceof JButton) {
                ((JButton) value).doClick();
                JButton boton = (JButton) value;
                if (boton.getName().equals("m")) {

                    int fila = 0;
                    fila = TableCuentaID.getSelectedRow();
                    String Cuenta = TableCuentaID.getValueAt(fila, 0).toString();
                    if ("5400-200-0500".equals(Cuenta)) {
                        JOptionPane.showMessageDialog(this, "Ingrese el valor de las Subcuentas", "Registro de Ingresos Diversos", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        Double cantDatos;
                        cantDatos = Double.parseDouble(JOptionPane.showInputDialog(null, "Digite el valor", "Valores", JOptionPane.INFORMATION_MESSAGE));
                        if (cantDatos != null) {
                            TableCuentaID.setValueAt(String.format("%.2f", cantDatos), fila, 2);
                            subcuentasID();
                        } else {
                            cantDatos = 0.00;
                            TableCuentaID.setValueAt(cantDatos, fila, 2);
                        }
                    }
                    //TableCuentaIA.setValueAt(cantDatos,fila,2);
                    TotalIgresosDiverso();
                    Numero_a_Letra d = new Numero_a_Letra();
                    String letras = d.Convertir(LabelTotalID.getText(), true);
                    txtTotalLetrasID.setText(letras);
                }
            }

        }
    }//GEN-LAST:event_TableCuentaIDMouseClicked

    private void txtNumCuentaIPDKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNumCuentaIPDKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNumCuentaIPDKeyPressed

    private void txtNumCuentaIPDKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNumCuentaIPDKeyTyped
        // TODO add your handling code here:
        char car = evt.getKeyChar();
        if ((car < '0' || car > '9')) {
            evt.consume();
        }
        if (txtNumCuentaIPD.getText().length() == limite) {
            evt.consume();
        }
    }//GEN-LAST:event_txtNumCuentaIPDKeyTyped

    private void btnEliminarIPDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarIPDActionPerformed
        // TODO add your handling code here:
        CargarDataMetodos();
        TotalIgresosPrestamoD();
        txtNumCuentaIPD.requestFocus();
        txtIdIPD.setText("");
        txtNumCuentaIPD.setText("");
        txtNombreIPD.setText("");
        IPrestamoD.clearSelection();
        txtTotalLetrasIPD.setText("");
        txtObservaIPD.setText("");
        txtNPrestamoIPD.setText("");
        txtCicloIPD.setText("");
        txtPlazoIPD.setText("");
        txtTasaIPD.setText("");
        dateFechaEntregaIPD.setCalendar(null);
        dateFechaIFinslIPD.setCalendar(null);
        txtsaldoActualIPD.setText("");
        txtintereseAcumuIPD.setText("");
        btnGuardarIPD.setEnabled(true);
    }//GEN-LAST:event_btnEliminarIPDActionPerformed

    private void btnGuardarIPDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarIPDActionPerformed
        // TODO add your handling code here:
        if ("".equals(txtIdIPD.getText())) {
            try {
                con = Conexion.ConnectDB();
                if ((txtNumCuentaIPD.getText().equals("")) || (txtNombreIPD.getText().equals("")) || (LabelTotalIPD.getText().equals("0.00"))
                        || (IPrestamoD.getSelection() == null) || (txtNumCuentaIPD.getText().length() < limite) || (txtNPrestamoIPD.getText().equals(""))
                        || (txtCicloIPD.getText().equals("")) || (txtPlazoIPD.getText().equals("")) || (txtTasaIPD.getText().equals(""))
                        || dateFechaEntregaIPD.getDate() == null || dateFechaIFinslIPD.getDate() == null || dateFechaIPD.getDate() == null) {
                    JOptionPane.showMessageDialog(this, "Falta Ingreso de algunos Datos O Numero de Cuenta Incorrecto Incorrecta", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                String sql = "insert into list_fact_ip(tipo_fact,fecha,"
                        + "num_cuenta,"
                        + "no_prestamo,"
                        + "ciclo,"
                        + "moneda,"
                        + "nombre,"
                        + "fecha_entrega,"
                        + "fecha_finalizacion,"
                        + "plazo,"
                        + "tasa,"
                        + "total,"
                        + "saldo_prestamo_actl_o_venc,"
                        + "intereses_acumulados,"
                        + "observaciones) values ('"
                        + "1" + "','"
                        + formatofecha.format(dateFechaIPD.getDate()) + "','"
                        + txtNumCuentaIPD.getText() + "','"
                        + txtNPrestamoIPD.getText() + "','"
                        + txtCicloIPD.getText() + "','"
                        + SelectMonedaIPD() + "','"
                        + txtNombreIPD.getText() + "','"
                        + formatofecha.format(dateFechaEntregaIPD.getDate()) + "','"
                        + formatofecha.format(dateFechaIFinslIPD.getDate()) + "','"
                        + txtPlazoIPD.getText() + "','"
                        + txtTasaIPD.getText() + "','"
                        + LabelTotalIPD.getText() + "','"
                        + txtsaldoActualIPD.getText() + "','"
                        + txtintereseAcumuIPD.getText() + "','"
                        + txtObservaIPD.getText() + "')";
                pst = con.prepareStatement(sql);
                pst.execute();

                for (int i = 0; i < TableCuentaIPD.getRowCount(); i++) {
                    String Cuenta = TableCuentaIPD.getValueAt(i, 0).toString();
                    String descripcion = TableCuentaIPD.getValueAt(i, 1).toString();
                    String valores = TableCuentaIPD.getValueAt(i, 2).toString();
                    String sqlId = "insert into detalles_fact(num_factura,"
                            + "tfactura,"
                            + "cuenta,"
                            + "descripcion,"
                            + "valores) values ('"
                            + MaxID_IP() + "','"
                            + "Ingresos de Prestamos en Demanda" + "','"
                            + Cuenta + "','"
                            + descripcion + "','"
                            + valores + "')";
                    pst = con.prepareStatement(sqlId);
                    pst.execute();
                }

                JOptionPane.showMessageDialog(this, "Registrado con éxito", "INGRESOS DE PRESTAMOS EN DEMANDA", JOptionPane.INFORMATION_MESSAGE);
                EliminarFilasVaciasIPD("0.00");
                try {
                    print_bill("4");
                } catch (IOException ex) {
                    Logger.getLogger(Sistema.class.getName()).log(Level.SEVERE, null, ex);
                }
                txtIdIPD.setText(MaxID_IP());

            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, e);
            }
        } else {
            try {
                JOptionPane.showMessageDialog(this, "Esta Factura ya esta Guardada puede Imprimir la Factura de Nuevo", "INGRESOS DE PRESTAMOS EN DEMANDA", JOptionPane.INFORMATION_MESSAGE);
                print_bill("4");
                btnGuardarIP.setEnabled(false);
            } catch (IOException ex) {
                Logger.getLogger(Sistema.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_btnGuardarIPDActionPerformed

    private void ChkLIPDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ChkLIPDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ChkLIPDActionPerformed

    private void Chk$IPDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Chk$IPDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Chk$IPDActionPerformed

    private void TableCuentaIPDMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TableCuentaIPDMouseClicked
        // TODO add your handling code here:
        int column = TableCuentaIPD.getColumnModel().getColumnIndexAtX(evt.getX());
        int row = evt.getY() / TableCuentaIPD.getRowHeight();

        if (row < TableCuentaIPD.getRowCount() && row >= 0 && column < TableCuentaIPD.getColumnCount() && column >= 0) {
            Object value = TableCuentaIPD.getValueAt(row, column);
            DefaultTableModel tm = (DefaultTableModel) TableCuentaIPD.getModel();
            if (value instanceof JButton) {
                ((JButton) value).doClick();
                JButton boton = (JButton) value;

                if (boton.getName().equals("m")) {
                    Double cantDatos;
                    cantDatos = Double.parseDouble(JOptionPane.showInputDialog(null, "Digite el valor", "Valores", JOptionPane.INFORMATION_MESSAGE));
                    int fila = 0;
                    fila = TableCuentaIPD.getSelectedRow();
                    if (cantDatos != null) {
                        TableCuentaIPD.setValueAt(String.format("%.2f", cantDatos), fila, 2);
                    } else {
                        cantDatos = 0.00;
                        TableCuentaIPD.setValueAt(cantDatos, fila, 2);
                    }
                    TotalIgresosPrestamoD();
                    Numero_a_Letra d = new Numero_a_Letra();
                    String letras = d.Convertir(LabelTotalIPD.getText(), true);
                    txtTotalLetrasIPD.setText(letras);
                }
            }

        }
    }//GEN-LAST:event_TableCuentaIPDMouseClicked

    private void txtNPrestamoIPDKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNPrestamoIPDKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNPrestamoIPDKeyPressed

    private void txtNPrestamoIPDKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNPrestamoIPDKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNPrestamoIPDKeyTyped

    private void txtCicloIPDKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCicloIPDKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCicloIPDKeyPressed

    private void txtCicloIPDKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCicloIPDKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCicloIPDKeyTyped

    private void txtPlazoIPDKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtPlazoIPDKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPlazoIPDKeyPressed

    private void txtPlazoIPDKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtPlazoIPDKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPlazoIPDKeyTyped

    private void txtTasaIPDKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTasaIPDKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTasaIPDKeyPressed

    private void txtTasaIPDKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTasaIPDKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTasaIPDKeyTyped

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_jButton1ActionPerformed

    private void IAchkNCtaANActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_IAchkNCtaANActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_IAchkNCtaANActionPerformed

    private void txtObservaIAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtObservaIAActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtObservaIAActionPerformed

    private void txtObservaIAKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtObservaIAKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtObservaIAKeyPressed

    private void txtObservaIAKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtObservaIAKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txtObservaIAKeyTyped

    private void cutMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cutMenuItemActionPerformed
        jTabbedPane1.setSelectedIndex(0);
    }//GEN-LAST:event_cutMenuItemActionPerformed

    private void copyMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_copyMenuItemActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(2);

    }//GEN-LAST:event_copyMenuItemActionPerformed

    private void contentMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_contentMenuItemActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(7);
        String sql = "select * from list_fact_ia";

        try {
            pst = con.prepareStatement(sql);
            rs = pst.executeQuery();
            TableFacturas.setModel(DbUtils.resultSetToTableModel(rs));
            TableFacturas.setRowHeight(30);

            //TableCuenta.removeColumn(TableCuenta.getColumnModel().getColumn(0));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);

        }
    }//GEN-LAST:event_contentMenuItemActionPerformed

    private void jmUsuariosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmUsuariosActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(6);
    }//GEN-LAST:event_jmUsuariosActionPerformed

    private void jMenuItem4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem4ActionPerformed

    private void jMenuItem6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem6ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(1);
    }//GEN-LAST:event_jMenuItem6ActionPerformed

    private void jMenuItem7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem7ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(4);
    }//GEN-LAST:event_jMenuItem7ActionPerformed

    private void jMenuItem5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem5ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(3);
    }//GEN-LAST:event_jMenuItem5ActionPerformed

    private void mnusisreservaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mnusisreservaMouseClicked
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(9);
    }//GEN-LAST:event_mnusisreservaMouseClicked

    private void txtTotalLetrasIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTotalLetrasIDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTotalLetrasIDActionPerformed

    private void txtTotalLetrasIDKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTotalLetrasIDKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTotalLetrasIDKeyPressed

    private void txtTotalLetrasIDKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTotalLetrasIDKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTotalLetrasIDKeyTyped

    private void txtObservaIPDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtObservaIPDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtObservaIPDActionPerformed

    private void txtObservaIPDKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtObservaIPDKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtObservaIPDKeyPressed

    private void txtObservaIPDKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtObservaIPDKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txtObservaIPDKeyTyped

    private void txtintereseAcumuIPDKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtintereseAcumuIPDKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtintereseAcumuIPDKeyPressed

    private void txtintereseAcumuIPDKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtintereseAcumuIPDKeyTyped
        // TODO add your handling code here:
        char caracter = evt.getKeyChar();
        if (((caracter < '0') || (caracter > '9'))
                && (caracter != KeyEvent.VK_BACK_SPACE)
                && (caracter != '.' || txtintereseAcumuIPD.getText().contains("."))) {
            evt.consume();
        }
    }//GEN-LAST:event_txtintereseAcumuIPDKeyTyped

    private void txtsaldoActualIPDKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtsaldoActualIPDKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtsaldoActualIPDKeyPressed

    private void txtsaldoActualIPDKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtsaldoActualIPDKeyTyped
        // TODO add your handling code here:
        char caracter = evt.getKeyChar();
        if (((caracter < '0') || (caracter > '9'))
                && (caracter != KeyEvent.VK_BACK_SPACE)
                && (caracter != '.' || txtsaldoActualIPD.getText().contains("."))) {
            evt.consume();
        }
    }//GEN-LAST:event_txtsaldoActualIPDKeyTyped

    private void txtTotalLetrasIPDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTotalLetrasIPDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTotalLetrasIPDActionPerformed

    private void txtTotalLetrasIPDKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTotalLetrasIPDKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTotalLetrasIPDKeyPressed

    private void txtTotalLetrasIPDKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTotalLetrasIPDKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTotalLetrasIPDKeyTyped

    private void IAchkNCtaAOActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_IAchkNCtaAOActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_IAchkNCtaAOActionPerformed

    private void txtNumCuentaEAKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNumCuentaEAKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNumCuentaEAKeyPressed

    private void txtNumCuentaEAKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNumCuentaEAKeyTyped
        // TODO add your handling code here:
        char car = evt.getKeyChar();
        if ((car < '0' || car > '9')) {
            evt.consume();
        }
        if (txtNumCuentaEA.getText().length() == limite) {
            evt.consume();
        }
    }//GEN-LAST:event_txtNumCuentaEAKeyTyped

    private void btnEliminarventa1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarventa1ActionPerformed
        // TODO add your handling code here:
        CargarDataMetodos();
        TotalPagar();
        txtNumCuentaEA.requestFocus();
        txtIdEA.setText("");
        txtNumCuentaEA.setText("");
        txtNombreEA.setText("");
        GreoupChkEA.clearSelection();
        txtTotalLetrasEA.setText("");
        txtObservaEA.setText("");
        btnGuardarEA.setEnabled(true);
    }//GEN-LAST:event_btnEliminarventa1ActionPerformed

    private void txtTotalLetrasEAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTotalLetrasEAActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTotalLetrasEAActionPerformed

    private void txtTotalLetrasEAKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTotalLetrasEAKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTotalLetrasEAKeyPressed

    private void txtTotalLetrasEAKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTotalLetrasEAKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTotalLetrasEAKeyTyped

    private void btnGuardarEAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarEAActionPerformed
        // TODO add your handling code here:

        if ("".equals(txtIdEA.getText())) {
            try {
                con = Conexion.ConnectDB();
                if ((txtNumCuentaEA.getText().equals("")) || (txtNombreEA.getText().equals("")) || (LabelTotalEA.getText().equals("0.00")) || (GreoupChkEA.getSelection() == null) || (txtNumCuentaEA.getText().length() < limite) || dateFechaEA.getDate() == null) {
                    JOptionPane.showMessageDialog(this, "Falta Ingreso de algunos Datos O Numero de Cuenta Incorrecto Incorrecta", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                String sql = "insert into list_fact_EA(fecha,"
                        + "num_cuenta,"
                        + "tipo_cuenta,"
                        + "nombre,"
                        + "total,"
                        + "observaciones) values ('"
                        + formatofecha.format(dateFechaEA.getDate()) + "','"
                        + txtNumCuentaEA.getText() + "','"
                        + SelectNOCtaEA() + "','"
                        + txtNombreEA.getText() + "','"
                        + LabelTotalEA.getText() + "','"
                        + txtObservaEA.getText() + "')";
                pst = con.prepareStatement(sql);
                pst.execute();

                for (int i = 0; i < TableCuentaEA.getRowCount(); i++) {
                    String Cuenta = TableCuentaEA.getValueAt(i, 0).toString();
                    String descripcion = TableCuentaEA.getValueAt(i, 1).toString();
                    String valores = TableCuentaEA.getValueAt(i, 2).toString();
                    String sqlId = "insert into detalles_fact(num_factura,"
                            + "tfactura,"
                            + "cuenta,"
                            + "descripcion,"
                            + "valores) values ('"
                            + MaxID_EA() + "','"
                            + "Ingresos de Ahorro" + "','"
                            + Cuenta + "','"
                            + descripcion + "','"
                            + valores + "')";
                    pst = con.prepareStatement(sqlId);
                    pst.execute();
                }

                JOptionPane.showMessageDialog(this, "Registrado con éxito", "EGRESOS DE AHORROS", JOptionPane.INFORMATION_MESSAGE);
                EliminarFilasVaciasEA("0.00");
                try {
                    print_bill("5");
                } catch (IOException ex) {
                    Logger.getLogger(Sistema.class.getName()).log(Level.SEVERE, null, ex);
                }
                //CargarDataMetodos();
                txtIdEA.setText(MaxID_EA());

            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, e);
            }
        } else {
            try {
                JOptionPane.showMessageDialog(this, "Esta Factura ya esta Guardada puede Imprimir la Factura de Nuevo", "EGRESOS DE AHORROS", JOptionPane.INFORMATION_MESSAGE);
                print_bill("5");
                btnGuardarEA.setEnabled(false);
            } catch (IOException ex) {
                Logger.getLogger(Sistema.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_btnGuardarEAActionPerformed

    private void EAchkNCtaAEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EAchkNCtaAEActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_EAchkNCtaAEActionPerformed

    private void EAchkNCtaAPFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EAchkNCtaAPFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_EAchkNCtaAPFActionPerformed

    private void EAchkNCtaARActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EAchkNCtaARActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_EAchkNCtaARActionPerformed

    private void EAchkNCtaAMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EAchkNCtaAMActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_EAchkNCtaAMActionPerformed

    private void TableCuentaEAMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TableCuentaEAMouseClicked
        // TODO add your handling code here:
        int column = TableCuentaEA.getColumnModel().getColumnIndexAtX(evt.getX());
        int row = evt.getY() / TableCuentaEA.getRowHeight();

        if (row < TableCuentaEA.getRowCount() && row >= 0 && column < TableCuentaEA.getColumnCount() && column >= 0) {
            Object value = TableCuentaEA.getValueAt(row, column);
            DefaultTableModel tm = (DefaultTableModel) TableCuentaEA.getModel();
            if (value instanceof JButton) {
                ((JButton) value).doClick();
                JButton boton = (JButton) value;

                if (boton.getName().equals("m")) {
                    Double cantDatos;
                    cantDatos = Double.parseDouble(JOptionPane.showInputDialog(null, "Digite el valor", "Valores", JOptionPane.INFORMATION_MESSAGE));
                    int fila = 0;
                    fila = TableCuentaEA.getSelectedRow();
                    if (cantDatos != null) {
                        TableCuentaEA.setValueAt(String.format("%.2f", cantDatos), fila, 2);
                    } else {
                        cantDatos = 0.00;
                        TableCuentaEA.setValueAt(cantDatos, fila, 2);
                    }
                    TotalEgresosA();
                    Numero_a_Letra d = new Numero_a_Letra();
                    String letras = d.Convertir(LabelTotalEA.getText(), true);
                    txtTotalLetrasEA.setText(letras);
                }
            }

        }
    }//GEN-LAST:event_TableCuentaEAMouseClicked

    private void EAchkNCtaANActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EAchkNCtaANActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_EAchkNCtaANActionPerformed

    private void txtObservaEAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtObservaEAActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtObservaEAActionPerformed

    private void txtObservaEAKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtObservaEAKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtObservaEAKeyPressed

    private void txtObservaEAKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtObservaEAKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txtObservaEAKeyTyped

    private void EAchkNCtaAOActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EAchkNCtaAOActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_EAchkNCtaAOActionPerformed

    private void txtNumCuentaIAKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNumCuentaIAKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNumCuentaIAKeyPressed
    int limite = 13;
    private void txtNumCuentaIAKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNumCuentaIAKeyTyped
        // TODO add your handling code here:
        char car = evt.getKeyChar();
        if ((car < '0' || car > '9')) {
            evt.consume();
        }
        if (txtNumCuentaIA.getText().length() == limite) {
            evt.consume();
        }
    }//GEN-LAST:event_txtNumCuentaIAKeyTyped

    private void txtIdIDKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtIdIDKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIdIDKeyPressed

    private void txtIdIDKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtIdIDKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIdIDKeyTyped

    private void txtNumCuentaIPKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNumCuentaIPKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNumCuentaIPKeyPressed

    private void txtNumCuentaIPKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNumCuentaIPKeyTyped
        // TODO add your handling code here:
        char car = evt.getKeyChar();
        if ((car < '0' || car > '9')) {
            evt.consume();
        }
        if (txtNumCuentaIP.getText().length() == limite) {
            evt.consume();
        }
    }//GEN-LAST:event_txtNumCuentaIPKeyTyped

    private void btnEliminarIPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarIPActionPerformed
        // TODO add your handling code here:
        CargarDataMetodos();
        TotalIgresosPrestamo();
        txtNumCuentaIP.requestFocus();
        txtIdIP.setText("");
        txtNumCuentaIP.setText("");
        txtNombreIP.setText("");
        IPrestamo.clearSelection();
        txtTotalLetrasIP.setText("");
        txtObservaIP.setText("");
        txtNPrestamoIP.setText("");
        txtCicloIP.setText("");
        txtPlazoIP.setText("");
        txtTasaIP.setText("");
        dateFechaEntregaIP.setCalendar(null);
        dateFechaIFinslIP.setCalendar(null);
        txtsaldoActualIP.setText("");
        txtintereseAcumuIP.setText("");
        btnGuardarIP.setEnabled(true);
    }//GEN-LAST:event_btnEliminarIPActionPerformed

    private void btnGuardarIPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarIPActionPerformed
        // TODO add your handling code here:
        if ("".equals(txtIdIP.getText())) {
            try {
                con = Conexion.ConnectDB();
                if ((txtNumCuentaIP.getText().equals("")) || (txtNombreIP.getText().equals("")) || (LabelTotalIP.getText().equals("0.00"))
                        || (IPrestamo.getSelection() == null) || (txtNumCuentaIP.getText().length() < limite) || (txtNPrestamoIP.getText().equals(""))
                        || (txtCicloIP.getText().equals("")) || (txtPlazoIP.getText().equals("")) || (txtTasaIP.getText().equals(""))
                        || dateFechaEntregaIP.getDate() == null || dateFechaIFinslIP.getDate() == null || dateFechaIP.getDate() == null) {
                    JOptionPane.showMessageDialog(this, "Falta Ingreso de algunos Datos O Numero de Cuenta Incorrecto Incorrecta", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                String sql = "insert into list_fact_ip(tipo_fact,fecha,"
                        + "num_cuenta,"
                        + "no_prestamo,"
                        + "ciclo,"
                        + "moneda,"
                        + "nombre,"
                        + "fecha_entrega,"
                        + "fecha_finalizacion,"
                        + "plazo,"
                        + "tasa,"
                        + "total,"
                        + "saldo_prestamo_actl_o_venc,"
                        + "intereses_acumulados,"
                        + "observaciones) values ('"
                        + "0" + "','"
                        + formatofecha.format(dateFechaIP.getDate()) + "','"
                        + txtNumCuentaIP.getText() + "','"
                        + txtNPrestamoIP.getText() + "','"
                        + txtCicloIP.getText() + "','"
                        + SelectMonedaIP() + "','"
                        + txtNombreIP.getText() + "','"
                        + formatofecha.format(dateFechaEntregaIP.getDate()) + "','"
                        + formatofecha.format(dateFechaIFinslIP.getDate()) + "','"
                        + txtPlazoIP.getText() + "','"
                        + txtTasaIP.getText() + "','"
                        + LabelTotalIP.getText() + "','"
                        + txtsaldoActualIP.getText() + "','"
                        + txtintereseAcumuIP.getText() + "','"
                        + txtObservaIP.getText() + "')";
                pst = con.prepareStatement(sql);
                pst.execute();

                for (int i = 0; i < TableCuentaIP.getRowCount(); i++) {
                    String Cuenta = TableCuentaIP.getValueAt(i, 0).toString();
                    String descripcion = TableCuentaIP.getValueAt(i, 1).toString();
                    String valores = TableCuentaIP.getValueAt(i, 2).toString();
                    String sqlId = "insert into detalles_fact(num_factura,"
                            + "tfactura,"
                            + "cuenta,"
                            + "descripcion,"
                            + "valores) values ('"
                            + MaxID_IP() + "','"
                            + "Ingresos de Prestamos" + "','"
                            + Cuenta + "','"
                            + descripcion + "','"
                            + valores + "')";
                    pst = con.prepareStatement(sqlId);
                    pst.execute();
                }

                JOptionPane.showMessageDialog(this, "Registrado con éxito", "INGRESOS DE PRESTAMO", JOptionPane.INFORMATION_MESSAGE);
                EliminarFilasVaciasIP("0.00");
                try {
                    print_bill("3");
                } catch (IOException ex) {
                    Logger.getLogger(Sistema.class.getName()).log(Level.SEVERE, null, ex);
                }
                //CargarDataMetodos();
                txtIdIP.setText(MaxID_IP());

            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, e);
            }
        } else {
            try {
                JOptionPane.showMessageDialog(this, "Esta Factura ya esta Guardada puede Imprimir la Factura de Nuevo", "INGRESOS DE PRESTAMO", JOptionPane.INFORMATION_MESSAGE);
                print_bill("3");
                btnGuardarIP.setEnabled(false);
            } catch (IOException ex) {
                Logger.getLogger(Sistema.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_btnGuardarIPActionPerformed

    private void ChkLIPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ChkLIPActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ChkLIPActionPerformed

    private void Chk$IPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Chk$IPActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Chk$IPActionPerformed

    private void TableCuentaIPMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TableCuentaIPMouseClicked
        // TODO add your handling code here:
        int column = TableCuentaIP.getColumnModel().getColumnIndexAtX(evt.getX());
        int row = evt.getY() / TableCuentaIP.getRowHeight();

        if (row < TableCuentaIP.getRowCount() && row >= 0 && column < TableCuentaIP.getColumnCount() && column >= 0) {
            Object value = TableCuentaIP.getValueAt(row, column);
            DefaultTableModel tm = (DefaultTableModel) TableCuentaIP.getModel();
            if (value instanceof JButton) {
                ((JButton) value).doClick();
                JButton boton = (JButton) value;

                if (boton.getName().equals("m")) {
                    Double cantDatos;
                    cantDatos = Double.parseDouble(JOptionPane.showInputDialog(null, "Digite el valor", "Valores", JOptionPane.INFORMATION_MESSAGE));
                    int fila = 0;
                    fila = TableCuentaIP.getSelectedRow();
                    if (cantDatos != null) {
                        TableCuentaIP.setValueAt(String.format("%.2f", cantDatos), fila, 2);
                    } else {
                        cantDatos = 0.00;
                        TableCuentaIP.setValueAt(cantDatos, fila, 2);
                    }
                    TotalIgresosPrestamo();
                    Numero_a_Letra d = new Numero_a_Letra();
                    String letras = d.Convertir(LabelTotalIP.getText(), true);
                    txtTotalLetrasIP.setText(letras);
                }
            }

        }
    }//GEN-LAST:event_TableCuentaIPMouseClicked

    private void txtNPrestamoIPKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNPrestamoIPKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNPrestamoIPKeyPressed

    private void txtNPrestamoIPKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNPrestamoIPKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNPrestamoIPKeyTyped

    private void txtCicloIPKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCicloIPKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCicloIPKeyPressed

    private void txtCicloIPKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCicloIPKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCicloIPKeyTyped

    private void txtPlazoIPKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtPlazoIPKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPlazoIPKeyPressed

    private void txtPlazoIPKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtPlazoIPKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPlazoIPKeyTyped

    private void txtTasaIPKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTasaIPKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTasaIPKeyPressed

    private void txtTasaIPKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTasaIPKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTasaIPKeyTyped

    private void txtObservaIPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtObservaIPActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtObservaIPActionPerformed

    private void txtObservaIPKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtObservaIPKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtObservaIPKeyPressed

    private void txtObservaIPKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtObservaIPKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txtObservaIPKeyTyped

    private void txtintereseAcumuIPKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtintereseAcumuIPKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtintereseAcumuIPKeyPressed

    private void txtintereseAcumuIPKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtintereseAcumuIPKeyTyped
        // TODO add your handling code here:char caracter = evt.getKeyChar();
        char caracter = evt.getKeyChar();
        if (((caracter < '0') || (caracter > '9'))
                && (caracter != KeyEvent.VK_BACK_SPACE)
                && (caracter != '.' || txtintereseAcumuIP.getText().contains("."))) {
            evt.consume();
        }

    }//GEN-LAST:event_txtintereseAcumuIPKeyTyped

    private void txtsaldoActualIPKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtsaldoActualIPKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtsaldoActualIPKeyPressed

    private void txtsaldoActualIPKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtsaldoActualIPKeyTyped
        // TODO add your handling code here:
        char caracter = evt.getKeyChar();
        if (((caracter < '0') || (caracter > '9'))
                && (caracter != KeyEvent.VK_BACK_SPACE)
                && (caracter != '.' || txtsaldoActualIP.getText().contains("."))) {
            evt.consume();
        }
    }//GEN-LAST:event_txtsaldoActualIPKeyTyped

    private void txtTotalLetrasIPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTotalLetrasIPActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTotalLetrasIPActionPerformed

    private void txtTotalLetrasIPKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTotalLetrasIPKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTotalLetrasIPKeyPressed

    private void txtTotalLetrasIPKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTotalLetrasIPKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTotalLetrasIPKeyTyped

    private void txtIdIPKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtIdIPKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIdIPKeyPressed

    private void txtIdIPKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtIdIPKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIdIPKeyTyped

    private void txtIdIPDKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtIdIPDKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIdIPDKeyPressed

    private void txtIdIPDKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtIdIPDKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIdIPDKeyTyped

    private void txtNumCtaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNumCtaKeyTyped
        // TODO add your handling code here:
        char caracter = evt.getKeyChar();
        if (((caracter < '0') || (caracter > '9'))
                && (caracter != KeyEvent.VK_BACK_SPACE)
                && (caracter != '-')) {
            evt.consume();
        }

    }//GEN-LAST:event_txtNumCtaKeyTyped
    void GenerarBackupMySQL() {
        try {
            Runtime runtime = Runtime.getRuntime();
            Date Ahora = new Date();
            File backupFile = new File("backup_coop_lazosdeamistad_" + formatofechaBackUp.format(Ahora) + ".sql");
            FileWriter fw = new FileWriter(backupFile);
            Process child = runtime.exec("C:\\Program Files\\MariaDB 10.4\\bin\\mysqldump --password=JC_22 --user=JCoop --databases coop_lazosdeamistad");
            
            InputStreamReader irs = new InputStreamReader(child.getInputStream());
            BufferedReader br = new BufferedReader(irs);

            String line;
            while ((line = br.readLine()) != null) {
                fw.write(line + "\n");
            }
            fw.close();
            irs.close();
            br.close();

            JOptionPane.showMessageDialog(null, "Respaldo de Base de Datos Generado!", "Verificar", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Genere el respaldo en el Servidor!", "ERROR", JOptionPane.ERROR_MESSAGE);
        }

    }
    private void jMenuItem10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem10ActionPerformed
        // TODO add your handling code here:
        GenerarBackupMySQL();
        

    }//GEN-LAST:event_jMenuItem10ActionPerformed

    private void txtIdEAKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtIdEAKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIdEAKeyPressed

    private void txtIdEAKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtIdEAKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIdEAKeyTyped

    private void mnuconsultasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mnuconsultasMouseClicked
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(5);
    }//GEN-LAST:event_mnuconsultasMouseClicked

    private void cbxBuscarFacturaItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbxBuscarFacturaItemStateChanged
        // TODO add your handling code here:
        if (cbxBuscarFactura.getSelectedItem().equals("Ingresos de Ahorro")) {
            String sql = "select * from list_fact_ia";

            try {
                pst = con.prepareStatement(sql);
                rs = pst.executeQuery();
                TableFacturas.setModel(DbUtils.resultSetToTableModel(rs));
                TableFacturas.setRowHeight(30);

                //TableCuenta.removeColumn(TableCuenta.getColumnModel().getColumn(0));
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);

            }
        } else if (cbxBuscarFactura.getSelectedItem().equals("Ingresos Diversos")) {
            String sql = "select * from list_fact_id";

            try {
                pst = con.prepareStatement(sql);
                rs = pst.executeQuery();
                TableFacturas.setModel(DbUtils.resultSetToTableModel(rs));
                TableFacturas.setRowHeight(30);

                //TableCuenta.removeColumn(TableCuenta.getColumnModel().getColumn(0));
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);

            }
        } else if (cbxBuscarFactura.getSelectedItem().equals("Ingresos de Prestamos")) {
            String sql = "select num_factura,num_cuenta,nombre,fecha,no_prestamo,ciclo,moneda,fecha_entrega,fecha_finalizacion,"
                    + "plazo,tasa,total,saldo_prestamo_actl_o_venc as 'Saldo Actual',intereses_acumulados,observaciones from list_fact_ip where tipo_fact=0";

            try {
                pst = con.prepareStatement(sql);
                rs = pst.executeQuery();
                TableFacturas.setModel(DbUtils.resultSetToTableModel(rs));
                TableFacturas.setRowHeight(30);

                //TableCuenta.removeColumn(TableCuenta.getColumnModel().getColumn(0));
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);

            }
        } else if (cbxBuscarFactura.getSelectedItem().equals("Ingresos de Prestamos en Demanda")) {
            String sql = "select num_factura,num_cuenta,nombre,fecha,no_prestamo,ciclo,moneda,fecha_entrega,fecha_finalizacion,"
                    + "plazo,tasa,total,saldo_prestamo_actl_o_venc as 'Saldo Actual',intereses_acumulados,observaciones from list_fact_ip where tipo_fact=1";

            try {
                pst = con.prepareStatement(sql);
                rs = pst.executeQuery();
                TableFacturas.setModel(DbUtils.resultSetToTableModel(rs));
                TableFacturas.setRowHeight(30);

                //TableCuenta.removeColumn(TableCuenta.getColumnModel().getColumn(0));
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);

            }
        } else if (cbxBuscarFactura.getSelectedItem().equals("Egresos de Ahorro")) {
            String sql = "select * from list_fact_ea";

            try {
                pst = con.prepareStatement(sql);
                rs = pst.executeQuery();
                TableFacturas.setModel(DbUtils.resultSetToTableModel(rs));
                TableFacturas.setRowHeight(30);

                //TableCuenta.removeColumn(TableCuenta.getColumnModel().getColumn(0));
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);

            }
        }

    }//GEN-LAST:event_cbxBuscarFacturaItemStateChanged

    private void cbxBuscarFacturaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cbxBuscarFacturaMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_cbxBuscarFacturaMouseClicked

    private void cbxBuscarFacturaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cbxBuscarFacturaMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbxBuscarFacturaMousePressed

    private void cbxBuscarFacturaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbxBuscarFacturaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbxBuscarFacturaActionPerformed
    private String ChkTipoCuentaIA(String tipo) {
        if ("A.P.F.".equals(tipo)) {//1
            IAchkNCtaAPF.setSelected(true);
        } else if ("A.R.".equals(tipo)) {//2
            IAchkNCtaAR.setSelected(true);
        } else if ("A.M.".equals(tipo)) {//3
            IAchkNCtaAM.setSelected(true);
        } else if ("A.E.".equals(tipo)) {//4
            IAchkNCtaAE.setSelected(true);
        } else if ("A.N.".equals(tipo)) {//5
            IAchkNCtaAN.setSelected(true);
        } else if ("A.O.".equals(tipo)) {//6
            IAchkNCtaAO.setSelected(true);
        }
        return tipo;
    }
    private void TableFacturasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TableFacturasMouseClicked
        // TODO add your handling code here:
        obtener_DetallesFact();
        if(cbxBuscarFactura.getSelectedItem().equals("Ingresos de Ahorro")){
            int i = TableFacturas.getSelectedRow();
            txtIdIA.setText(TableFacturas.getValueAt(i, 0).toString());
            dateFechaIA.setDateFormatString(TableFacturas.getValueAt(i, 1).toString());
            txtNumCuentaIA.setText(TableFacturas.getValueAt(i, 2).toString());
            ChkTipoCuentaIA(TableFacturas.getValueAt(i, 3).toString());
            txtNombreIA.setText(TableFacturas.getValueAt(i, 4).toString());
            LabelTotalIA.setText(TableFacturas.getValueAt(i, 5).toString());
            txtObservaIA.setText(TableFacturas.getValueAt(i, 6).toString());
            btnEditarIA.setVisible(true);
            btnGuardarIA.setEnabled(false);
            jTabbedPane1.setSelectedIndex(0);
        }else if(cbxBuscarFactura.getSelectedItem().equals("Ingresos Diversos")){
            int i = TableFacturas.getSelectedRow();
            txtIdID.setText(TableFacturas.getValueAt(i, 0).toString());
            dateFechaID.setDateFormatString(TableFacturas.getValueAt(i, 1).toString());
            txtNumCuentaID.setText(TableFacturas.getValueAt(i, 2).toString());
            //ChkTipoCuentaIA(TableFacturas.getValueAt(i, 3).toString());
            txtNombreID.setText(TableFacturas.getValueAt(i, 3).toString());
            LabelTotalID.setText(TableFacturas.getValueAt(i, 4).toString());
            txtObservaID.setText(TableFacturas.getValueAt(i, 5).toString());
            btnEditarID.setVisible(true);
            btnGuardarID.setEnabled(false);
            jTabbedPane1.setSelectedIndex(1);}

    }//GEN-LAST:event_TableFacturasMouseClicked

    private void TableCuentaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TableCuentaMouseClicked
        // TODO add your handling code here:
        btnEditarCta.setEnabled(true);
        btnEliminarCta.setEnabled(true);
        btnGuardarCta.setEnabled(false);
        int fila = TableCuenta.rowAtPoint(evt.getPoint());
        txtIdCta.setText(TableCuenta.getValueAt(fila, 0).toString());
        cbxComprobante.setSelectedItem(TableCuenta.getValueAt(fila, 1).toString());
        txtNumCta.setText(TableCuenta.getValueAt(fila, 2).toString());
        txtDescripcion.setText(TableCuenta.getValueAt(fila, 3).toString());
        cbxMoneda.setSelectedItem(TableCuenta.getValueAt(fila, 4).toString());
    }//GEN-LAST:event_TableCuentaMouseClicked

    private void txtBuscarFacturasKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscarFacturasKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtBuscarFacturasKeyPressed

    private void txtBuscarFacturasKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscarFacturasKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txtBuscarFacturasKeyTyped

    private void btnEditarIAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarIAActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnEditarIAActionPerformed

    private void btnEliminarIAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarIAActionPerformed

    }//GEN-LAST:event_btnEliminarIAActionPerformed

    private void mnusalirMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mnusalirMouseClicked
        // TODO add your handling code here:
        Login l = new Login();
        l.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_mnusalirMouseClicked

    private void btnEditarIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarIDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnEditarIDActionPerformed

    private void btnDeleteIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteIDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnDeleteIDActionPerformed

    private void btnEditarIPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarIPActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnEditarIPActionPerformed

    private void btnDeleteIPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteIPActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnDeleteIPActionPerformed

    private void btnEditarIPDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarIPDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnEditarIPDActionPerformed

    private void btnDeleteIPDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteIPDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnDeleteIPDActionPerformed

    private void btnEditarEAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarEAActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnEditarEAActionPerformed

    private void btnEliminarEAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarEAActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnEliminarEAActionPerformed

    private void btnGuardarUserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarUserActionPerformed
        // TODO add your handling code here:
        try {
            con = Conexion.ConnectDB();
            if ((txtCorreo.getText().equals("")) || (txtPass.getText().equals("")) || (txtNombre.getText().equals(""))) {
                JOptionPane.showMessageDialog(this, "Falta Ingreso de algunos Datos", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String sql = "insert into usuarios(correo,"
                    + "pass,"
                    + "nombre,"
                    + "rol) values ('"
                    + txtCorreo.getText()+txtDominio.getText() + "','"
                    + txtPass.getText() + "','"
                    + txtNombre.getText() + "','"
                    + cbxRol.getSelectedItem() + "')";
            pst = con.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(this, "Registrado con éxito", "Registro de Ususuarios", JOptionPane.INFORMATION_MESSAGE);
            limpiarDataCuentas();
            CargarDataMetodos();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, e);
        }
    }//GEN-LAST:event_btnGuardarUserActionPerformed

    private void btnNuevoUserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoUserActionPerformed
        // TODO add your handling code here:
        txtDominio.setVisible(true);
        txtCorreo.setText("");
        cbxRol.setSelectedItem(null);
        txtPass.setText("");
        txtNombre.setText("");
        btnEditarUser.setEnabled(false);
        btnEliminarUser.setEnabled(false);
        btnGuardarUser.setEnabled(true);
    }//GEN-LAST:event_btnNuevoUserActionPerformed

    private void btnEliminarUserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarUserActionPerformed
        // TODO add your handling code here:
        try {
            int P = JOptionPane.showConfirmDialog(null, " Seguro que quiere borrarlo ?", "Confirmación", JOptionPane.YES_NO_OPTION);
            if (P == 0) {
                con = Conexion.ConnectDB();

                String sql = "delete from usuarios where id='" + txtIdUser.getText() + "'";
                pst = con.prepareStatement(sql);
                pst.execute();
                JOptionPane.showMessageDialog(this, "Borrado Exitosamente", "Registro de Usuarios", JOptionPane.INFORMATION_MESSAGE);
                CargarDataMetodos();
                limpiarDataCuentas();
                btnEditarUser.setEnabled(false);
                btnEliminarUser.setEnabled(false);
                btnGuardarUser.setEnabled(true);
            }
        } catch (SQLException e) {

        }
    }//GEN-LAST:event_btnEliminarUserActionPerformed

    private void btnEditarUserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarUserActionPerformed
        // TODO add your handling code here:
        try {
            con = Conexion.ConnectDB();
            String sql = "update usuarios set nombre='" + txtNombre.getText()
                    + "',correo='" + txtCorreo.getText()
                    + "',pass='" + txtPass.getText()
                    + "',rol='" + cbxRol.getSelectedItem()
                    + "' where id='" + txtIdUser.getText() + "'";
            pst = con.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(this, "Usuario Actualizado", "Registro de Usuarios", JOptionPane.INFORMATION_MESSAGE);
            CargarDataMetodos();
            limpiarDataCuentas();

        } catch (SQLException e) {

        }
    }//GEN-LAST:event_btnEditarUserActionPerformed

    private void TableUsuariosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TableUsuariosMouseClicked
        // TODO add your handling code here:
        txtDominio.hide();
        btnEditarUser.setEnabled(true);
        btnEliminarUser.setEnabled(true);
        btnGuardarUser.setEnabled(false);
        int fila = TableUsuarios.rowAtPoint(evt.getPoint());
        txtIdUser.setText(TableUsuarios.getValueAt(fila, 0).toString());
        txtNombre.setText(TableUsuarios.getValueAt(fila, 1).toString());
        txtCorreo.setText(TableUsuarios.getValueAt(fila, 2).toString());
        txtPass.setText(TableUsuarios.getValueAt(fila, 3).toString());
        cbxRol.setSelectedItem(TableUsuarios.getValueAt(fila, 4).toString());
    }//GEN-LAST:event_TableUsuariosMouseClicked

    private void txtCorreoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCorreoKeyTyped
        // TODO add your handling code here:
        
    }//GEN-LAST:event_txtCorreoKeyTyped

    private void txtDominioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDominioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDominioActionPerformed

    private void txtDominioKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtDominioKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDominioKeyTyped

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        try {
            // TODO add your handling code here:
            Process p = new ProcessBuilder("explorer.exe","\"Facturas\\\"").start();
        } catch (IOException ex) {
            Logger.getLogger(Sistema.class.getName()).log(Level.SEVERE, null, ex);
        }
//        JFileChooser jf = new JFileChooser("Facturas\\");
//        jf.showOpenDialog(this);
    }//GEN-LAST:event_jMenuItem1ActionPerformed
    String[] ValorctaCSA = new String[8];
    String[] ctaCSA = new String[8];

    void addCtaTableID() {
        ValorctaCSA[0] = "0.00";
        ValorctaCSA[1] = "0.00";
        ValorctaCSA[2] = "0.00";
        ValorctaCSA[3] = "0.00";
        ValorctaCSA[4] = "0.00";
        ValorctaCSA[5] = "0.00";
        ValorctaCSA[6] = "0.00";
        ValorctaCSA[7] = "0.00";
        //////
        ctaCSA[0] = "Timbres";
        ctaCSA[1] = "Buró de Crédito";
        ctaCSA[2] = "Avalúo de Propiedades";
        ctaCSA[3] = "Traspasos";
        ctaCSA[4] = "Gestión de Cobro";
        ctaCSA[5] = "Emisión de Constancias";
        ctaCSA[6] = "Reposición de Tarjeta de Ahorro";
        ctaCSA[7] = "Hipotecas";
        DefaultTableModel modelo = (DefaultTableModel) TableCuentaID.getModel();
        Object[] columna = new Object[6];
        JButton btn_modificar = new JButton("AGREGAR VALOR");
        btn_modificar.setName("m");
        for (int i = 0; i < 8; i++) {
            columna[0] = "";
            columna[1] = ctaCSA[i];
            columna[2] = ValorctaCSA[i];
            columna[3] = btn_modificar;
            modelo.addRow(columna);
            TableCuentaID.setModel(modelo);
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Sistema.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Sistema.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Sistema.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Sistema.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Sistema().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBox Chk$IP;
    private javax.swing.JCheckBox Chk$IPD;
    private javax.swing.JCheckBox ChkLIP;
    private javax.swing.JCheckBox ChkLIPD;
    private javax.swing.JCheckBox EAchkNCtaAE;
    private javax.swing.JCheckBox EAchkNCtaAM;
    private javax.swing.JCheckBox EAchkNCtaAN;
    private javax.swing.JCheckBox EAchkNCtaAO;
    private javax.swing.JCheckBox EAchkNCtaAPF;
    private javax.swing.JCheckBox EAchkNCtaAR;
    private javax.swing.ButtonGroup GreoupChkEA;
    private javax.swing.JCheckBox IAchkNCtaAE;
    private javax.swing.JCheckBox IAchkNCtaAM;
    private javax.swing.JCheckBox IAchkNCtaAN;
    private javax.swing.JCheckBox IAchkNCtaAO;
    private javax.swing.JCheckBox IAchkNCtaAPF;
    private javax.swing.JCheckBox IAchkNCtaAR;
    private javax.swing.ButtonGroup IPrestamo;
    private javax.swing.ButtonGroup IPrestamoD;
    public javax.swing.JLabel LabelNombreUser;
    private javax.swing.JLabel LabelTotalEA;
    private javax.swing.JLabel LabelTotalIA;
    private javax.swing.JLabel LabelTotalID;
    private javax.swing.JLabel LabelTotalIP;
    private javax.swing.JLabel LabelTotalIPD;
    private javax.swing.JLabel LabelVendedor1;
    private javax.swing.JTable TableCuenta;
    private javax.swing.JTable TableCuentaEA;
    private javax.swing.JTable TableCuentaIA;
    private javax.swing.JTable TableCuentaID;
    private javax.swing.JTable TableCuentaIP;
    private javax.swing.JTable TableCuentaIPD;
    private javax.swing.JTable TableFacturas;
    private javax.swing.JTable TableUsuarios;
    private javax.swing.JButton btnActualizarConfig;
    private javax.swing.JButton btnDeleteID;
    private javax.swing.JButton btnDeleteIP;
    private javax.swing.JButton btnDeleteIPD;
    private javax.swing.JButton btnEditarCta;
    private javax.swing.JButton btnEditarEA;
    private javax.swing.JButton btnEditarIA;
    private javax.swing.JButton btnEditarID;
    private javax.swing.JButton btnEditarIP;
    private javax.swing.JButton btnEditarIPD;
    private javax.swing.JButton btnEditarUser;
    private javax.swing.JButton btnEliminarCta;
    private javax.swing.JButton btnEliminarEA;
    private javax.swing.JButton btnEliminarIA;
    private javax.swing.JButton btnEliminarID;
    private javax.swing.JButton btnEliminarIP;
    private javax.swing.JButton btnEliminarIPD;
    private javax.swing.JButton btnEliminarUser;
    private javax.swing.JButton btnEliminarventa;
    private javax.swing.JButton btnEliminarventa1;
    private javax.swing.JButton btnGuardarCta;
    private javax.swing.JButton btnGuardarEA;
    private javax.swing.JButton btnGuardarIA;
    private javax.swing.JButton btnGuardarID;
    private javax.swing.JButton btnGuardarIP;
    private javax.swing.JButton btnGuardarIPD;
    private javax.swing.JButton btnGuardarUser;
    private javax.swing.JButton btnNuevoCta;
    private javax.swing.JButton btnNuevoUser;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JComboBox<Object> cbxBuscarCuenta;
    private javax.swing.JComboBox<Object> cbxBuscarFactura;
    private javax.swing.JComboBox<Object> cbxComprobante;
    private javax.swing.JComboBox<Object> cbxMoneda;
    private javax.swing.JComboBox<String> cbxRol;
    private javax.swing.JMenuItem contentMenuItem;
    private javax.swing.JMenuItem copyMenuItem;
    private javax.swing.JMenuItem cutMenuItem;
    private com.toedter.calendar.JDateChooser dateFechaEA;
    private com.toedter.calendar.JDateChooser dateFechaEntregaIP;
    private com.toedter.calendar.JDateChooser dateFechaEntregaIPD;
    private com.toedter.calendar.JDateChooser dateFechaIA;
    private com.toedter.calendar.JDateChooser dateFechaID;
    private com.toedter.calendar.JDateChooser dateFechaIFinslIP;
    private com.toedter.calendar.JDateChooser dateFechaIFinslIPD;
    private com.toedter.calendar.JDateChooser dateFechaIP;
    private com.toedter.calendar.JDateChooser dateFechaIPD;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel65;
    private javax.swing.JLabel jLabel66;
    private javax.swing.JLabel jLabel67;
    private javax.swing.JLabel jLabel68;
    private javax.swing.JLabel jLabel69;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel70;
    private javax.swing.JLabel jLabel71;
    private javax.swing.JLabel jLabel72;
    private javax.swing.JLabel jLabel74;
    private javax.swing.JLabel jLabel75;
    private javax.swing.JLabel jLabel76;
    private javax.swing.JLabel jLabel77;
    private javax.swing.JLabel jLabel78;
    private javax.swing.JLabel jLabel79;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel80;
    private javax.swing.JLabel jLabel81;
    private javax.swing.JLabel jLabel82;
    private javax.swing.JLabel jLabel83;
    private javax.swing.JLabel jLabel84;
    private javax.swing.JLabel jLabel85;
    private javax.swing.JLabel jLabel86;
    private javax.swing.JLabel jLabel87;
    private javax.swing.JLabel jLabel88;
    private javax.swing.JLabel jLabel89;
    private javax.swing.JLabel jLabel90;
    private javax.swing.JLabel jLabel91;
    private javax.swing.JMenuBar jMenuBar2;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem10;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JMenuItem jMenuItem4;
    private javax.swing.JMenuItem jMenuItem5;
    private javax.swing.JMenuItem jMenuItem6;
    private javax.swing.JMenuItem jMenuItem7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel29;
    private javax.swing.JPanel jPanel30;
    private javax.swing.JPanel jPanel31;
    private javax.swing.JPanel jPanel32;
    private javax.swing.JPanel jPanel33;
    private javax.swing.JPanel jPanel34;
    private javax.swing.JPanel jPanel36;
    private javax.swing.JPanel jPanel37;
    private javax.swing.JPanel jPanel38;
    private javax.swing.JPanel jPanel39;
    private javax.swing.JPanel jPanel40;
    private javax.swing.JPanel jPanel41;
    private javax.swing.JPanel jPanel42;
    private javax.swing.JPanel jPanel43;
    private javax.swing.JPanel jPanel44;
    private javax.swing.JPanel jPanel45;
    private javax.swing.JPanel jPanel46;
    private javax.swing.JPanel jPanel47;
    private javax.swing.JPanel jPanel53;
    private javax.swing.JPanel jPanel54;
    private javax.swing.JPanel jPanel55;
    private javax.swing.JPanel jPanel56;
    private javax.swing.JPanel jPanel57;
    private javax.swing.JPanel jPanel58;
    private javax.swing.JPanel jPanel59;
    private javax.swing.JPanel jPanel60;
    private javax.swing.JPanel jPanel61;
    private javax.swing.JPanel jPanel62;
    private javax.swing.JPanel jPanel63;
    private javax.swing.JPanel jPanel67;
    private javax.swing.JPanel jPanel68;
    private javax.swing.JPanel jPanel69;
    private javax.swing.JPanel jPanel70;
    private javax.swing.JPanel jPanel71;
    private javax.swing.JPanel jPanel72;
    private javax.swing.JPanel jPanel73;
    private javax.swing.JPanel jPanel74;
    private javax.swing.JPanel jPanel75;
    private javax.swing.JPanel jPanel76;
    private javax.swing.JPanel jPanel77;
    private javax.swing.JPanel jPanel78;
    private javax.swing.JPanel jPanel79;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JProgressBar jProgressBar1;
    private javax.swing.JScrollBar jScrollBar1;
    private javax.swing.JScrollBar jScrollBar2;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane11;
    private javax.swing.JScrollPane jScrollPane12;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JTabbedPane jTabbedPane1;
    public javax.swing.JMenuItem jmUsuarios;
    public javax.swing.JMenu mnuConsultas;
    public static javax.swing.JMenu mnuarchivo;
    private javax.swing.JMenu mnuayuda;
    public static javax.swing.JMenu mnuconfiguraciones;
    private javax.swing.JMenu mnuconsultas;
    private javax.swing.JMenu mnusalir;
    private javax.swing.JMenu mnusisreserva;
    private javax.swing.JPanel pnl_EAhorro;
    private javax.swing.JPanel pnl_IAhorro;
    private javax.swing.JPanel pnl_IAhorro1;
    private javax.swing.JPanel pnl_IDiversos;
    private javax.swing.JPanel pnl_IPrestamo;
    private javax.swing.JPanel pnl_IPrestamoDemanda;
    private javax.swing.JPanel pnl_cuentas;
    private javax.swing.JPanel pnl_empresa;
    private javax.swing.JPanel pnl_historial;
    private javax.swing.JPanel pnl_usuario;
    private javax.swing.JLabel tipo;
    private javax.swing.JTextField txtBuscarCuenta;
    private javax.swing.JTextField txtBuscarFacturas;
    private javax.swing.JTextField txtCicloIP;
    private javax.swing.JTextField txtCicloIPD;
    private javax.swing.JTextField txtCorreo;
    private javax.swing.JTextField txtDescripcion;
    private javax.swing.JTextField txtDireccionConfig;
    private javax.swing.JTextField txtDominio;
    private javax.swing.JTextField txtIdConfig;
    private javax.swing.JTextField txtIdCta;
    private javax.swing.JTextField txtIdEA;
    private javax.swing.JTextField txtIdIA;
    private javax.swing.JTextField txtIdID;
    private javax.swing.JTextField txtIdIP;
    private javax.swing.JTextField txtIdIPD;
    private javax.swing.JTextField txtIdUser;
    private javax.swing.JTextField txtMensaje;
    private javax.swing.JTextField txtNPrestamoIP;
    private javax.swing.JTextField txtNPrestamoIPD;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtNombreConfig;
    private javax.swing.JTextField txtNombreEA;
    private javax.swing.JTextField txtNombreIA;
    private javax.swing.JTextField txtNombreID;
    private javax.swing.JTextField txtNombreIP;
    private javax.swing.JTextField txtNombreIPD;
    private javax.swing.JTextField txtNumCta;
    private javax.swing.JTextField txtNumCuentaEA;
    private javax.swing.JTextField txtNumCuentaIA;
    private javax.swing.JTextField txtNumCuentaID;
    private javax.swing.JTextField txtNumCuentaIP;
    private javax.swing.JTextField txtNumCuentaIPD;
    private javax.swing.JTextField txtObservaEA;
    private javax.swing.JTextField txtObservaIA;
    private javax.swing.JTextField txtObservaID;
    private javax.swing.JTextField txtObservaIP;
    private javax.swing.JTextField txtObservaIPD;
    private javax.swing.JPasswordField txtPass;
    private javax.swing.JTextField txtPlazoIP;
    private javax.swing.JTextField txtPlazoIPD;
    private javax.swing.JTextField txtRucConfig;
    private javax.swing.JTextField txtTasaIP;
    private javax.swing.JTextField txtTasaIPD;
    private javax.swing.JTextField txtTelefonoConfig;
    private javax.swing.JTextField txtTotalLetrasEA;
    private javax.swing.JTextField txtTotalLetrasIA;
    private javax.swing.JTextField txtTotalLetrasID;
    private javax.swing.JTextField txtTotalLetrasIP;
    private javax.swing.JTextField txtTotalLetrasIPD;
    private javax.swing.JTextField txtintereseAcumuIP;
    private javax.swing.JTextField txtintereseAcumuIPD;
    private javax.swing.JTextField txtsaldoActualIP;
    private javax.swing.JTextField txtsaldoActualIPD;
    // End of variables declaration//GEN-END:variables

    private void LimpiarCuentas() {
        txtNumCta.setText("");
        cbxComprobante.setSelectedItem(null);
        txtDescripcion.setText("");
        cbxMoneda.setSelectedItem(null);
    }

    private void LimpiarIngresosAhorro() {
        txtIdIA.setText("");
        txtNombreIA.setText("");
        cbxComprobante.setSelectedItem(null);
        txtDescripcion.setText("");
        cbxMoneda.setSelectedItem(null);
    }

    private void TotalPagar() {
        Totalpagar = 0.00;
        int numFila = TableCuentaIA.getRowCount();
        for (int i = 0; i < numFila; i++) {
            double cal = Double.parseDouble(String.valueOf(TableCuentaIA.getModel().getValueAt(i, 2)));
            Totalpagar = Totalpagar + cal;
        }
        LabelTotalIA.setText(String.format("%.2f", Totalpagar));
    }

    private void LimparVenta() {
        txtIdIA.setText("");
        //txtDescripcionVenta.setText("");
        //txtCantidadVenta.setText("");
        txtNombreIA.setText("");
        // txtPrecioVenta.setText("");
    }

    private void LimpiarTableVenta() {
        tmp = (DefaultTableModel) TableCuentaIA.getModel();
        int fila = TableCuentaIA.getRowCount();
        for (int i = 0; i < fila; i++) {
            tmp.removeRow(0);
        }
    }

}
