/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author dev
 */
public class Conexion {
    // Connection con=null;
   
        public static Connection ConnectDB(){
             try{
           
          Class.forName("com.mysql.jdbc.Driver");
             //Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/coop_lazosdeamistad","JCoop","JC_22");
            // Connection con = DriverManager.getConnection("jdbc:mysql:/31.170.167.102:3306/u740329289_coop_lm?u740329289_root&Coop_2022");
            // jdbc:mysql://localhost:3306/projects?user=user1&password=123
             Connection con = DriverManager.getConnection("jdbc:mysql://192.168.1.100:3306/coop_lazosdeamistad?serverTimezone=UTC","JCoop","JC_22");
                return con;
            
        }catch(ClassNotFoundException | SQLException e){
            JOptionPane.showMessageDialog(null, e);
            return null;
        }       
        }
}

